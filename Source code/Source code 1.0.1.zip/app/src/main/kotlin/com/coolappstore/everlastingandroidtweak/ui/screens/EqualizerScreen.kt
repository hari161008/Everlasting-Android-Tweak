package com.coolappstore.everlastingandroidtweak.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.features.equalizer.EqualizerManager
import com.coolappstore.everlastingandroidtweak.ui.components.EverlastingTopBar
import com.coolappstore.everlastingandroidtweak.ui.components.SectionHeader
import kotlinx.coroutines.launch

@Composable
fun EqualizerScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val enabled by AppPreferences.get(AppPreferences.EQUALIZER_ENABLED, false).collectAsState(false)
    val savedLevels by AppPreferences.get(AppPreferences.EQ_BAND_LEVELS, "0,0,0,0,0").collectAsState("0,0,0,0,0")

    // Init EQ on first composition
    var eqInitialized by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        eqInitialized = EqualizerManager.init()
        if (eqInitialized) {
            EqualizerManager.applyFromString(savedLevels)
            EqualizerManager.setEnabled(enabled)
        }
    }

    val bandNames = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")
    val bandLevels = remember {
        mutableStateListOf(*savedLevels.split(",").map { it.trim().toFloatOrNull() ?: 0f }.toTypedArray())
    }

    val presets = listOf("Flat", "Bass Boost", "Treble Boost", "Vocal", "Rock", "Electronic")
    val presetValues = listOf(
        listOf(0f, 0f, 0f, 0f, 0f),
        listOf(6f, 4f, 0f, -2f, -2f),
        listOf(-2f, 0f, 2f, 4f, 6f),
        listOf(-2f, 2f, 4f, 2f, -2f),
        listOf(4f, 2f, -2f, 2f, 4f),
        listOf(2f, -2f, 4f, -2f, 2f),
    )
    var selectedPreset by remember { mutableStateOf(0) }

    Scaffold(topBar = { EverlastingTopBar("Equalizer", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!eqInitialized) {
                Card(Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text("⚠️ Equalizer not available on this device. The AudioEffect API may be blocked by your ROM.",
                        Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            ListItem(
                headlineContent = { Text("Enable Equalizer") },
                supportingContent = { Text("Apply EQ to system audio output") },
                trailingContent = {
                    Switch(checked = enabled, onCheckedChange = { isOn ->
                        scope.launch {
                            AppPreferences.set(AppPreferences.EQUALIZER_ENABLED, isOn)
                            EqualizerManager.setEnabled(isOn)
                        }
                    })
                }
            )
            HorizontalDivider()
            SectionHeader("Presets")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { i, name ->
                    FilterChip(selected = selectedPreset == i, onClick = {
                        selectedPreset = i
                        presetValues[i].forEachIndexed { j, v -> bandLevels[j] = v }
                        if (eqInitialized) EqualizerManager.applyAllBands(presetValues[i])
                        scope.launch {
                            AppPreferences.set(AppPreferences.EQ_BAND_LEVELS,
                                bandLevels.joinToString(","))
                        }
                    }, label = { Text(name, style = MaterialTheme.typography.labelSmall) })
                }
            }
            SectionHeader("Bands")
            bandNames.forEachIndexed { i, name ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(name, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(64.dp))
                    Slider(
                        value = bandLevels[i],
                        onValueChange = { newVal ->
                            bandLevels[i] = newVal
                            if (eqInitialized && enabled) EqualizerManager.applyAllBands(bandLevels.toList())
                        },
                        onValueChangeFinished = {
                            scope.launch {
                                AppPreferences.set(AppPreferences.EQ_BAND_LEVELS, bandLevels.joinToString(","))
                            }
                        },
                        valueRange = -12f..12f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${if (bandLevels[i] >= 0) "+" else ""}${bandLevels[i].toInt()} dB",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.width(52.dp), textAlign = TextAlign.End)
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("ℹ️ Uses Android's built-in AudioEffect API (session 0 = global). Some OEM audio effects may conflict.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
