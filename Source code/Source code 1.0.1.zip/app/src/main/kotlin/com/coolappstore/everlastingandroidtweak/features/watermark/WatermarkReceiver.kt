package com.coolappstore.everlastingandroidtweak.features.watermark

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*
import java.io.File

class WatermarkReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val uri = intent.data ?: return
        val path = uri.path ?: return
        if (!path.endsWith(".jpg", true) && !path.endsWith(".jpeg", true) &&
            !path.endsWith(".png", true)) return

        CoroutineScope(Dispatchers.IO).launch {
            val text = AppPreferences.get(AppPreferences.WATERMARK_TEXT, "© My Photo")
                .collect { text ->
                    val position = AppPreferences.get(AppPreferences.WATERMARK_POSITION, "Bottom Right")
                        .collect { pos -> applyWatermark(path, text, pos); return@collect }
                    return@collect
                }
        }
    }

    private fun applyWatermark(path: String, text: String, position: String) {
        try {
            val file = File(path)
            if (!file.exists()) return
            val original = BitmapFactory.decodeFile(path) ?: return
            val mutable = original.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(mutable)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                alpha = 200
                textSize = mutable.width * 0.035f
                setShadowLayer(6f, 2f, 2f, Color.BLACK)
            }
            val textWidth = paint.measureText(text)
            val margin = 40f
            val (x, y) = when (position) {
                "Bottom Left"  -> Pair(margin, mutable.height - margin)
                "Top Right"    -> Pair(mutable.width - textWidth - margin, paint.textSize + margin)
                "Top Left"     -> Pair(margin, paint.textSize + margin)
                "Center"       -> Pair((mutable.width - textWidth) / 2f, mutable.height / 2f)
                else           -> Pair(mutable.width - textWidth - margin, mutable.height - margin) // Bottom Right
            }
            canvas.drawText(text, x, y, paint)
            file.outputStream().use { mutable.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            original.recycle()
            mutable.recycle()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
