package com.coolappstore.everlastingandroidtweak.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.ui.components.EverlastingTopBar
import com.coolappstore.everlastingandroidtweak.ui.components.SectionHeader
import com.coolappstore.everlastingandroidtweak.utils.PermissionManager
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // Appearance prefs
    val dynamicColor by AppPreferences.get(AppPreferences.DYNAMIC_COLOR, true).collectAsState(true)
    val darkTheme by AppPreferences.get(AppPreferences.DARK_THEME, 0).collectAsState(0)

    // Permission states — re-checked every time screen resumes
    var grantedCamera by remember { mutableStateOf(PermissionManager.hasCamera(context)) }
    var grantedAudio by remember { mutableStateOf(PermissionManager.hasRecordAudio(context)) }
    var grantedNotifications by remember { mutableStateOf(PermissionManager.hasPostNotifications(context)) }
    var grantedMedia by remember { mutableStateOf(PermissionManager.hasReadMediaImages(context)) }
    var grantedAccessibility by remember { mutableStateOf(PermissionManager.isAccessibilityEnabled(context)) }
    var grantedOverlay by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    var grantedNotifListener by remember { mutableStateOf(PermissionManager.isNotificationListenerEnabled(context)) }
    var grantedUsageStats by remember { mutableStateOf(PermissionManager.hasUsageStatsPermission(context)) }
    var grantedAlarm by remember { mutableStateOf(PermissionManager.hasExactAlarmPermission(context)) }

    // Refresh all when coming back from Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                grantedCamera = PermissionManager.hasCamera(context)
                grantedAudio = PermissionManager.hasRecordAudio(context)
                grantedNotifications = PermissionManager.hasPostNotifications(context)
                grantedMedia = PermissionManager.hasReadMediaImages(context)
                grantedAccessibility = PermissionManager.isAccessibilityEnabled(context)
                grantedOverlay = PermissionManager.hasOverlayPermission(context)
                grantedNotifListener = PermissionManager.isNotificationListenerEnabled(context)
                grantedUsageStats = PermissionManager.hasUsageStatsPermission(context)
                grantedAlarm = PermissionManager.hasExactAlarmPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Runtime permission launcher (camera, mic, notifications, media)
    val runtimeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        grantedCamera = PermissionManager.hasCamera(context)
        grantedAudio = PermissionManager.hasRecordAudio(context)
        grantedNotifications = PermissionManager.hasPostNotifications(context)
        grantedMedia = PermissionManager.hasReadMediaImages(context)
    }

    Scaffold(topBar = { EverlastingTopBar("Settings", navController) }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {

            // ── APPEARANCE ───────────────────────────────────────────────────
            SectionHeader("Appearance")
            ListItem(
                headlineContent = { Text("Dynamic Color (Material You)") },
                supportingContent = { Text("Use wallpaper-based system colors") },
                trailingContent = {
                    Switch(checked = dynamicColor, onCheckedChange = {
                        scope.launch { AppPreferences.set(AppPreferences.DYNAMIC_COLOR, it) }
                    })
                }
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Theme Mode") },
                supportingContent = { Text("System / Light / Dark") },
                trailingContent = {
                    SegmentedButton(darkTheme, listOf("System", "Light", "Dark")) {
                        scope.launch { AppPreferences.set(AppPreferences.DARK_THEME, it) }
                    }
                }
            )
            HorizontalDivider()

            // ── PERMISSIONS ──────────────────────────────────────────────────
            SectionHeader("Permissions")

            // Basic runtime permissions — one button grants all at once
            PermissionRow(
                title = "Camera, Microphone & Media",
                subtitle = "Shake Torch, Music Light, Watermark, Custom Sounds",
                icon = Icons.Default.PermMedia,
                granted = grantedCamera && grantedAudio && grantedMedia && grantedNotifications,
                isSpecial = false,
                onGrant = {
                    val perms = mutableListOf(
                        Manifest.permission.CAMERA,
                        Manifest.permission.RECORD_AUDIO,
                    ).apply {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            add(Manifest.permission.POST_NOTIFICATIONS)
                            add(Manifest.permission.READ_MEDIA_IMAGES)
                            add(Manifest.permission.READ_MEDIA_AUDIO)
                        } else {
                            add(Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                    }
                    runtimeLauncher.launch(perms.toTypedArray())
                }
            )
            HorizontalDivider()

            PermissionRow(
                title = "Accessibility Service",
                subtitle = "Haptics, Custom Sounds, Screenshot Blocker, Nav Bar",
                icon = Icons.Default.Accessibility,
                granted = grantedAccessibility,
                isSpecial = true,
                onGrant = { PermissionManager.openAccessibilitySettings(context) }
            )
            HorizontalDivider()

            PermissionRow(
                title = "Display Over Other Apps",
                subtitle = "Custom Nav Bar, Volume Styles overlay",
                icon = Icons.Default.Layers,
                granted = grantedOverlay,
                isSpecial = true,
                onGrant = { PermissionManager.openOverlaySettings(context) }
            )
            HorizontalDivider()

            PermissionRow(
                title = "Notification Access",
                subtitle = "Music Reactive Light beat detection",
                icon = Icons.Default.Notifications,
                granted = grantedNotifListener,
                isSpecial = true,
                onGrant = { PermissionManager.openNotificationListenerSettings(context) }
            )
            HorizontalDivider()

            PermissionRow(
                title = "Usage Access",
                subtitle = "Task Manager accurate memory stats",
                icon = Icons.Default.BarChart,
                granted = grantedUsageStats,
                isSpecial = true,
                onGrant = { PermissionManager.openUsageAccessSettings(context) }
            )
            HorizontalDivider()

            PermissionRow(
                title = "Schedule Exact Alarms",
                subtitle = "Auto Reboot precise scheduling",
                icon = Icons.Default.Alarm,
                granted = grantedAlarm,
                isSpecial = true,
                onGrant = { PermissionManager.openExactAlarmSettings(context) }
            )
            HorizontalDivider()

            // ── ABOUT ─────────────────────────────────────────────────────────
            SectionHeader("About")
            ListItem(
                headlineContent = { Text("Everlasting Android Tweak") },
                supportingContent = { Text("Version 1.0.1 • com.coolappstore.everlastingandroidtweak") }
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PermissionRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    granted: Boolean,
    isSpecial: Boolean,
    onGrant: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            if (granted) Icons.Default.CheckCircle else icon,
            contentDescription = null,
            tint = if (granted) MaterialTheme.colorScheme.primary
                   else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(26.dp)
        )
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (granted) {
            Text("Granted", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary)
        } else {
            Button(
                onClick = onGrant,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(if (isSpecial) "Open →" else "Grant",
                    style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun SegmentedButton(selected: Int, options: List<String>, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(
                selected = selected == i,
                onClick = { onSelect(i) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
            )
        }
    }
}
