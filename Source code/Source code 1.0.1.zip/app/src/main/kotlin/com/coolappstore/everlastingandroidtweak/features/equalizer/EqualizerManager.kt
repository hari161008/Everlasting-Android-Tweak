package com.coolappstore.everlastingandroidtweak.features.equalizer

import android.media.audiofx.Equalizer
import android.util.Log

object EqualizerManager {

    private var equalizer: Equalizer? = null

    // Bug fix 1: Use priority 1000 so our EQ wins over others
    // Bug fix 2: Attach to session 0 (global mix) with proper release cycle
    fun init(): Boolean {
        return try {
            release() // Always release old instance first to avoid conflicts
            equalizer = Equalizer(1000, 0).apply {
                enabled = false
            }
            true
        } catch (e: Exception) {
            Log.e("EQ", "Failed to init: ${e.message}")
            false
        }
    }

    fun setEnabled(enabled: Boolean) {
        try {
            equalizer?.enabled = enabled
        } catch (e: Exception) {
            Log.e("EQ", "setEnabled failed: ${e.message}")
        }
    }

    fun getEnabled(): Boolean = try { equalizer?.enabled ?: false } catch (e: Exception) { false }

    // Bug fix 3: Disable EQ before changing bands → prevents the distortion pop/crackle
    // then re-enable after. This is the main cause of the distorted sound.
    fun setBandLevel(bandIndex: Short, levelDb: Float) {
        try {
            val eq = equalizer ?: return
            val wasEnabled = eq.enabled

            // Temporarily disable to avoid distortion when changing band levels
            if (wasEnabled) eq.enabled = false

            val levelMb = (levelDb * 100).toInt().toShort()
            // Bug fix 4: Access array by index instead of destructuring (ShortArray doesn't support it)
            val minLevel = eq.bandLevelRange[0]
            val maxLevel = eq.bandLevelRange[1]
            val clamped = levelMb.coerceIn(minLevel, maxLevel)
            eq.setBandLevel(bandIndex, clamped)

            if (wasEnabled) eq.enabled = true
        } catch (e: Exception) {
            Log.e("EQ", "setBandLevel failed: ${e.message}")
        }
    }

    // Apply ALL bands at once before re-enabling — far less distortion than one-by-one
    fun applyAllBands(levels: List<Float>) {
        try {
            val eq = equalizer ?: return
            val wasEnabled = eq.enabled
            if (wasEnabled) eq.enabled = false // Disable once

            val minLevel = eq.bandLevelRange[0]
            val maxLevel = eq.bandLevelRange[1]
            levels.forEachIndexed { i, levelDb ->
                val levelMb = (levelDb * 100).toInt().toShort().coerceIn(minLevel, maxLevel)
                eq.setBandLevel(i.toShort(), levelMb)
            }

            if (wasEnabled) eq.enabled = true // Re-enable once
        } catch (e: Exception) {
            Log.e("EQ", "applyAllBands failed: ${e.message}")
        }
    }

    fun getBandLevelDb(bandIndex: Short): Float =
        try { (equalizer?.getBandLevel(bandIndex) ?: 0) / 100f } catch (e: Exception) { 0f }

    fun getNumberOfBands(): Short =
        try { equalizer?.numberOfBands ?: 5 } catch (e: Exception) { 5 }

    fun applyFromString(levels: String) {
        val parsed = levels.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (parsed.isNotEmpty()) applyAllBands(parsed)
    }

    fun toBandLevelString(): String {
        return try {
            val count = getNumberOfBands()
            (0 until count).joinToString(",") { getBandLevelDb(it.toShort()).toString() }
        } catch (e: Exception) { "0,0,0,0,0" }
    }

    fun release() {
        try {
            equalizer?.enabled = false
            equalizer?.release()
            equalizer = null
        } catch (e: Exception) { }
    }
}
