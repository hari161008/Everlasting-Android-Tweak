package com.coolappstore.everlastingandroidtweak.services

import android.app.*
import android.content.*
import android.media.SoundPool
import android.net.Uri
import android.os.*
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.coolappstore.everlastingandroidtweak.EverlastingApp
import com.coolappstore.everlastingandroidtweak.R
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.features.camera.TwistCameraManager
import com.coolappstore.everlastingandroidtweak.features.musiclight.MusicLightManager
import com.coolappstore.everlastingandroidtweak.features.torch.ShakeTorchManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

// ─── FOREGROUND SERVICE ─────────────────────────────────────────────────────
class EverlastingForegroundService : Service() {

    private lateinit var shakeTorchManager: ShakeTorchManager
    private lateinit var twistCameraManager: TwistCameraManager
    private lateinit var musicLightManager: MusicLightManager
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        shakeTorchManager = ShakeTorchManager(this)
        twistCameraManager = TwistCameraManager(this)
        musicLightManager = MusicLightManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        observePreferences()
        return START_STICKY
    }

    private fun observePreferences() {
        scope.launch {
            AppPreferences.get(AppPreferences.SHAKE_TORCH_ENABLED, false).collect { enabled ->
                if (enabled) shakeTorchManager.start() else shakeTorchManager.stop()
            }
        }
        scope.launch {
            AppPreferences.get(AppPreferences.SHAKE_SENSITIVITY, 12f).collect { sensitivity ->
                shakeTorchManager.setSensitivity(sensitivity)
            }
        }
        scope.launch {
            AppPreferences.get(AppPreferences.TWIST_CAMERA_ENABLED, false).collect { enabled ->
                if (enabled) twistCameraManager.start() else twistCameraManager.stop()
            }
        }
        scope.launch {
            AppPreferences.get(AppPreferences.MUSIC_LIGHT_ENABLED, false).collect { lightEnabled ->
                val vibrateEnabled = AppPreferences.get(AppPreferences.MUSIC_VIBRATE_ENABLED, false).first()
                if (lightEnabled || vibrateEnabled) {
                    musicLightManager.lightEnabled = lightEnabled
                    musicLightManager.vibrationEnabled = vibrateEnabled
                    musicLightManager.start()
                } else {
                    musicLightManager.stop()
                }
            }
        }
        scope.launch {
            AppPreferences.get(AppPreferences.MUSIC_VIBRATE_ENABLED, false).collect { vibrateEnabled ->
                musicLightManager.vibrationEnabled = vibrateEnabled
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        shakeTorchManager.stop()
        twistCameraManager.stop()
        musicLightManager.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, EverlastingApp.CHANNEL_FOREGROUND)
            .setContentTitle("Everlasting Tweak Active")
            .setContentText("Gesture & feature monitoring running")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()

    companion object {
        private const val NOTIF_ID = 1001
        fun start(context: Context) {
            val intent = Intent(context, EverlastingForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else context.startService(intent)
        }
        fun stop(context: Context) {
            context.stopService(Intent(context, EverlastingForegroundService::class.java))
        }
    }
}

// ─── NOTIFICATION LISTENER ──────────────────────────────────────────────────
class EverlastingNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {}
    override fun onNotificationRemoved(sbn: StatusBarNotification) {}
}

// ─── BOOT RECEIVER ──────────────────────────────────────────────────────────
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            EverlastingForegroundService.start(context)
        }
    }
}
