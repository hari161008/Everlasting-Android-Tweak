package com.coolappstore.everlastingandroidtweak.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.services.EverlastingForegroundService
import com.coolappstore.everlastingandroidtweak.ui.components.EverlastingTopBar
import kotlinx.coroutines.launch

@Composable
fun TwistCameraScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.TWIST_CAMERA_ENABLED, false).collectAsState(false)

    LaunchedEffect(enabled) {
        if (enabled) EverlastingForegroundService.start(context)
    }

    Scaffold(topBar = { EverlastingTopBar("Twist for Camera", navController) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(colors = CardDefaults.cardColors(
                containerColor = if (enabled) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(20.dp)) {
                    Icon(Icons.Default.CameraAlt, null, Modifier.size(40.dp),
                        tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(if (enabled) "Active — Twist to Open Camera" else "Twist Wrist to Open Camera",
                            style = MaterialTheme.typography.titleMedium)
                        Text("Rotate your wrist twice quickly", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Card {
                Column {
                    ListItem(
                        headlineContent = { Text("Enable Twist Gesture") },
                        supportingContent = { Text("Double wrist twist opens camera") },
                        trailingContent = {
                            Switch(checked = enabled, onCheckedChange = {
                                scope.launch { AppPreferences.set(AppPreferences.TWIST_CAMERA_ENABLED, it) }
                            })
                        }
                    )
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("Uses the gyroscope sensor. Similar to Google Pixel & OnePlus quick camera gesture. The background service must be active (enabled via the toggle above).",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
