package com.coolappstore.everlastingandroidtweak.features.musiclight

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.*
import android.media.audiofx.Visualizer
import android.os.*
import kotlinx.coroutines.*
import kotlin.math.*

class MusicLightManager(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    else @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    private var job: Job? = null
    private var visualizer: Visualizer? = null
    private var torchCameraId: String? = null
    var lightEnabled = true
    var vibrationEnabled = true
    private var isRunning = false
    private var maxTorchLevel = 1

    // Beat detection state
    private var smoothedLevel = 0f
    private var beatThreshold = 0.35f
    private var lastBeatTime = 0L
    private val MIN_BEAT_GAP_MS = 120L

    init {
        torchCameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            torchCameraId?.let { id ->
                maxTorchLevel = cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
            }
        }
    }

    fun start() {
        if (isRunning) return
        isRunning = true

        // Bug fix: Use Visualizer API (session 0 = global mix) to capture ACTUAL playing audio,
        // not the microphone. VOICE_RECOGNITION / MIC only captures ambient sound,
        // which is why music reactive didn't react to music playing through the phone.
        try {
            visualizer = Visualizer(0).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1] // Max capture size
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer, waveform: ByteArray, samplingRate: Int) {
                        // Calculate RMS from waveform (each byte is -128..127 centered at 128)
                        var sum = 0.0
                        for (b in waveform) {
                            val centered = (b.toInt() and 0xFF) - 128
                            sum += centered * centered
                        }
                        val rms = sqrt(sum / waveform.size).toFloat()
                        // Normalize: waveform RMS typically 0–90 for loud audio
                        val normalized = (rms / 80f).coerceIn(0f, 1f)
                        processLevel(normalized)
                    }
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {}
                }, Visualizer.getMaxCaptureRate() / 2, true, false)
                enabled = true
            }
        } catch (e: Exception) {
            // Fallback to microphone if Visualizer fails (e.g. no audio session)
            job = CoroutineScope(Dispatchers.IO).launch { runMicFallback() }
        }
    }

    fun stop() {
        isRunning = false
        try {
            visualizer?.enabled = false
            visualizer?.release()
            visualizer = null
        } catch (_: Exception) {}
        job?.cancel()
        job = null
        try { torchCameraId?.let { cameraManager.setTorchMode(it, false) } } catch (_: Exception) {}
    }

    private fun processLevel(normalized: Float) {
        if (!isRunning) return
        // Smooth with faster attack, slower decay for punchy beat feel
        smoothedLevel = if (normalized > smoothedLevel)
            smoothedLevel * 0.3f + normalized * 0.7f  // Fast attack
        else
            smoothedLevel * 0.85f + normalized * 0.15f // Slow decay

        val now = System.currentTimeMillis()
        val isBeat = smoothedLevel > beatThreshold && (now - lastBeatTime) > MIN_BEAT_GAP_MS
        if (isBeat) lastBeatTime = now

        applyReaction(smoothedLevel, isBeat)
    }

    private fun applyReaction(level: Float, isBeat: Boolean) {
        // Torch — react on beats for punch, dim smoothly otherwise
        if (lightEnabled) {
            torchCameraId?.let { id ->
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxTorchLevel > 1) {
                        val strength = if (isBeat) maxTorchLevel
                                       else (level * maxTorchLevel * 0.6f).toInt().coerceAtLeast(0)
                        if (strength == 0) cameraManager.setTorchMode(id, false)
                        else cameraManager.turnOnTorchWithStrengthLevel(id, strength)
                    } else {
                        // Binary flash on beats only
                        cameraManager.setTorchMode(id, isBeat || level > 0.5f)
                    }
                } catch (_: Exception) {}
            }
        }

        // Vibrate on strong beats only
        if (vibrationEnabled && isBeat && level > beatThreshold) {
            val amplitude = (level * 220).toInt().coerceIn(20, 220)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(40, amplitude))
            } else {
                @Suppress("DEPRECATION") vibrator.vibrate(40)
            }
        }
    }

    // Fallback: mic capture when Visualizer unavailable
    private suspend fun runMicFallback() {
        val sampleRate = 44100
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val audioRecord = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize * 2)
        } catch (e: SecurityException) { return }

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) return
        audioRecord.startRecording()
        val buffer = ShortArray(bufferSize / 2)
        try {
            while (isRunning && currentCoroutineContext().isActive) {
                val read = audioRecord.read(buffer, 0, buffer.size)
                if (read > 0) {
                    var sum = 0.0
                    for (i in 0 until read) sum += buffer[i].toDouble().pow(2)
                    val rms = sqrt(sum / read).toFloat()
                    val normalized = (rms / 5000f).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main) { processLevel(normalized) }
                }
                delay(40)
            }
        } finally {
            audioRecord.stop()
            audioRecord.release()
            withContext(Dispatchers.Main) {
                try { torchCameraId?.let { cameraManager.setTorchMode(it, false) } } catch (_: Exception) {}
            }
        }
    }
}
