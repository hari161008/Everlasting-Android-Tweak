package com.coolappstore.everlastingandroidtweak.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ContentResolver
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.*
import android.view.accessibility.AccessibilityEvent
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*

class EverlastingAccessibilityService : AccessibilityService() {

    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
    }

    private var soundPool: SoundPool? = null
    private var tapSoundId: Int = 0
    private var tapSoundLoaded: Boolean = false
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var hapticsEnabled = false
    private var hapticsScrollEnabled = false
    private var hapticsIntensity = 100
    private var hapticsPattern = "Click"
    private var tapSoundEnabled = false
    private var tapSoundUri = ""
    private var lockSoundEnabled = false
    private var lockSoundUri = ""
    private var unlockSoundEnabled = false
    private var unlockSoundUri = ""

    override fun onServiceConnected() {
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 50
        }

        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()

        // Mark sound as loaded so we can play it
        soundPool?.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0 && sampleId == tapSoundId) tapSoundLoaded = true
        }

        observePreferences()
    }

    private fun observePreferences() {
        scope.launch { AppPreferences.get(AppPreferences.CUSTOM_HAPTICS_ENABLED, false).collect { hapticsEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_SCROLL_ENABLED, false).collect { hapticsScrollEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_INTENSITY, 100).collect { hapticsIntensity = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_PATTERN, "Click").collect { hapticsPattern = it } }
        scope.launch { AppPreferences.get(AppPreferences.TAP_SOUND_ENABLED, false).collect { tapSoundEnabled = it } }
        scope.launch {
            AppPreferences.get(AppPreferences.TAP_SOUND_URI, "").collect { uri ->
                tapSoundUri = uri
                reloadTapSound(uri)
            }
        }
        scope.launch { AppPreferences.get(AppPreferences.LOCK_SOUND_ENABLED, false).collect { lockSoundEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.LOCK_SOUND_URI, "").collect { lockSoundUri = it } }
        scope.launch { AppPreferences.get(AppPreferences.UNLOCK_SOUND_ENABLED, false).collect { unlockSoundEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.UNLOCK_SOUND_URI, "").collect { unlockSoundUri = it } }
    }

    // Bug fix: content:// URIs from the file picker can't use .path directly with SoundPool.
    // Must use ContentResolver to open a FileDescriptor instead.
    private fun reloadTapSound(uri: String) {
        if (uri.isBlank()) return
        tapSoundLoaded = false
        tapSoundId = 0
        scope.launch(Dispatchers.Main) {
            try {
                val parsedUri = Uri.parse(uri)
                val sp = soundPool ?: return@launch
                tapSoundId = if (parsedUri.scheme == "content") {
                    val afd = contentResolver.openAssetFileDescriptor(parsedUri, "r") ?: return@launch
                    sp.load(afd.fileDescriptor, afd.startOffset, afd.length, 1).also { afd.close() }
                } else {
                    sp.load(parsedUri.path, 1)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                if (hapticsEnabled) performHaptic()
                if (tapSoundEnabled && tapSoundLoaded && tapSoundId != 0) {
                    soundPool?.play(tapSoundId, 1f, 1f, 1, 0, 1f)
                }
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (hapticsScrollEnabled) performScrollHaptic()
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {}
        }
    }

    private fun performHaptic() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            @Suppress("DEPRECATION") vibrator.vibrate(15)
            return
        }
        val amp = (hapticsIntensity * 255 / 200).coerceIn(1, 255)
        val effect = when (hapticsPattern) {
            "Tick"         -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
            "Heavy Click"  -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK)
            "Double Click" -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK)
            "Soft"         -> VibrationEffect.createOneShot(8, (amp * 0.4f).toInt().coerceIn(1, 255))
            "Custom"       -> VibrationEffect.createOneShot(20, amp)
            else           -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
        }
        vibrator.vibrate(effect)
    }

    private fun performScrollHaptic() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        } else {
            @Suppress("DEPRECATION") vibrator.vibrate(5)
        }
    }

    // Bug fix: Use context + URI overload so content:// URIs work correctly
    fun playSound(uri: String) {
        if (uri.isBlank()) return
        scope.launch(Dispatchers.Main) {
            try {
                val parsedUri = Uri.parse(uri)
                MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                    if (parsedUri.scheme == "content") {
                        setDataSource(applicationContext, parsedUri)
                    } else {
                        setDataSource(uri)
                    }
                    prepare()
                    setOnCompletionListener { release() }
                    start()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        soundPool?.release()
        soundPool = null
    }
}
