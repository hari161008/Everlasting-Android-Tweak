package com.coolappstore.everlastingandroidtweak.ui.screens

import android.app.WallpaperManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.features.autoreboot.AutoRebootScheduler
import com.coolappstore.everlastingandroidtweak.ui.components.EverlastingTopBar
import com.coolappstore.everlastingandroidtweak.ui.components.SectionHeader
import com.coolappstore.everlastingandroidtweak.ui.components.ToggleSettingRow
import com.coolappstore.everlastingandroidtweak.ui.navigation.Screen
import com.coolappstore.everlastingandroidtweak.utils.PermissionManager
import kotlinx.coroutines.launch

// ─── SCREENSAVER ────────────────────────────────────────────────────────────
@Composable
fun ScreensaverScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val themes = listOf("Clock", "Photo Slideshow", "Colors", "Nature", "Abstract")
    val savedTheme by AppPreferences.get(AppPreferences.SCREENSAVER_THEME, "Clock").collectAsState("Clock")
    var selected by remember { mutableStateOf(0) }
    LaunchedEffect(savedTheme) { selected = themes.indexOf(savedTheme).takeIf { it >= 0 } ?: 0 }

    Scaffold(topBar = { EverlastingTopBar("Screensaver", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            SectionHeader("Theme")
            themes.forEachIndexed { i, theme ->
                ListItem(
                    headlineContent = { Text(theme) },
                    leadingContent = {
                        RadioButton(selected = selected == i, onClick = {
                            selected = i
                            scope.launch { AppPreferences.set(AppPreferences.SCREENSAVER_THEME, theme) }
                        })
                    }
                )
                HorizontalDivider()
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    // Start DreamService preview
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        setClassName("com.android.systemui", "com.android.systemui.DreamActivity")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try { context.startActivity(intent) } catch (e: Exception) {
                        // Fallback: open screensaver settings
                        context.startActivity(Intent(Settings.ACTION_DREAM_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) { Text("Preview Screensaver") }
            OutlinedButton(
                onClick = {
                    context.startActivity(Intent(Settings.ACTION_DREAM_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) { Text("Open Screensaver Settings") }
        }
    }
}

// ─── AUTO REBOOT ────────────────────────────────────────────────────────────
@Composable
fun AutoRebootScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.AUTO_REBOOT_ENABLED, false).collectAsState(false)
    val savedTime by AppPreferences.get(AppPreferences.AUTO_REBOOT_TIME, "03:00").collectAsState("03:00")
    val savedDays by AppPreferences.get(AppPreferences.AUTO_REBOOT_DAYS, "").collectAsState("")

    var hour by remember { mutableIntStateOf(3) }
    var minute by remember { mutableIntStateOf(0) }
    LaunchedEffect(savedTime) {
        savedTime.split(":").let { parts ->
            hour = parts.getOrNull(0)?.toIntOrNull() ?: 3
            minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        }
    }
    val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val selectedDays = remember { mutableStateListOf(*Array(7) { false }) }
    LaunchedEffect(savedDays) {
        savedDays.split(",").mapNotNull { it.toIntOrNull() }.forEach { if (it in 0..6) selectedDays[it] = true }
    }

    val hasAlarmPerm = PermissionManager.hasExactAlarmPermission(context)
    val lifecycleOwner = LocalLifecycleOwner.current
    var alarmPerm by remember { mutableStateOf(hasAlarmPerm) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) alarmPerm = PermissionManager.hasExactAlarmPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Auto Reboot", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!alarmPerm) {
                Card(Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Warning, null)
                        Column(Modifier.weight(1f)) {
                            Text("Exact Alarm Permission Required")
                            Text("Needed for precise reboot scheduling", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { PermissionManager.openExactAlarmSettings(context) }) { Text("Grant") }
                    }
                }
            }
            ToggleSettingRow("Enable Auto Reboot", "Automatically reboot at the scheduled time",
                enabled, { scope.launch { AppPreferences.set(AppPreferences.AUTO_REBOOT_ENABLED, it)
                    if (!it) AutoRebootScheduler.cancel(context) } })
            HorizontalDivider()
            SectionHeader("Reboot Time")
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = hour.toString().padStart(2, '0'),
                    onValueChange = { it.toIntOrNull()?.let { v -> if (v in 0..23) hour = v } },
                    label = { Text("Hour") }, modifier = Modifier.weight(1f), singleLine = true
                )
                Text(":", style = MaterialTheme.typography.headlineMedium)
                OutlinedTextField(
                    value = minute.toString().padStart(2, '0'),
                    onValueChange = { it.toIntOrNull()?.let { v -> if (v in 0..59) minute = v } },
                    label = { Text("Minute") }, modifier = Modifier.weight(1f), singleLine = true
                )
            }
            SectionHeader("Repeat Days")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                dayNames.forEachIndexed { i, d ->
                    FilterChip(selected = selectedDays[i], onClick = { selectedDays[i] = !selectedDays[i] },
                        label = { Text(d, style = MaterialTheme.typography.labelSmall) })
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    scope.launch {
                        val timeStr = "${hour.toString().padStart(2,'0')}:${minute.toString().padStart(2,'0')}"
                        val daysStr = selectedDays.mapIndexedNotNull { i, s -> if (s) i.toString() else null }.joinToString(",")
                        AppPreferences.set(AppPreferences.AUTO_REBOOT_TIME, timeStr)
                        AppPreferences.set(AppPreferences.AUTO_REBOOT_DAYS, daysStr)
                    }
                    AutoRebootScheduler.schedule(context, hour, minute, selectedDays.toList())
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp), enabled = enabled && alarmPerm
            ) { Text("Save Schedule") }
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("ℹ️ Actual reboot requires the REBOOT permission. Grant it via ADB: adb shell pm grant ${context.packageName} android.permission.REBOOT",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ─── WATERMARK ──────────────────────────────────────────────────────────────
@Composable
fun WatermarkScreen(navController: NavController) {
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.WATERMARK_ENABLED, false).collectAsState(false)
    val savedText by AppPreferences.get(AppPreferences.WATERMARK_TEXT, "© My Photo").collectAsState("© My Photo")
    val savedPos by AppPreferences.get(AppPreferences.WATERMARK_POSITION, "Bottom Right").collectAsState("Bottom Right")
    var watermarkText by remember { mutableStateOf("© My Photo") }
    LaunchedEffect(savedText) { watermarkText = savedText }
    val positions = listOf("Bottom Right", "Bottom Left", "Top Right", "Top Left", "Center")
    var selectedPos by remember { mutableStateOf(0) }
    LaunchedEffect(savedPos) { selectedPos = positions.indexOf(savedPos).takeIf { it >= 0 } ?: 0 }

    Scaffold(topBar = { EverlastingTopBar("Auto Watermark", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            ToggleSettingRow("Enable Auto Watermark", "Add watermark to photos automatically when taken",
                enabled, { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_ENABLED, it) } })
            HorizontalDivider()
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = watermarkText,
                    onValueChange = { watermarkText = it },
                    label = { Text("Watermark Text") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_TEXT, watermarkText) } }) {
                            Icon(Icons.Default.Save, "Save")
                        }
                    }
                )
                SectionHeader("Position")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    positions.forEachIndexed { i, pos ->
                        FilterChip(selected = selectedPos == i, onClick = {
                            selectedPos = i
                            scope.launch { AppPreferences.set(AppPreferences.WATERMARK_POSITION, pos) }
                        }, label = { Text(pos, style = MaterialTheme.typography.labelSmall) })
                    }
                }
            }
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("Watches for new photos using a FileObserver and overlays your text automatically. Requires READ_MEDIA_IMAGES permission.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ─── CACHE CLEANER ──────────────────────────────────────────────────────────
@Composable
fun CacheCleanerScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var shizukuAvailable by remember { mutableStateOf(false) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }

    // Check Shizuku on resume
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                shizukuAvailable = try {
                    rikka.shizuku.Shizuku.pingBinder()
                    rikka.shizuku.Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
                } catch (e: Exception) { false }
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Cache Cleaner", navController) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(colors = CardDefaults.cardColors(
                containerColor = if (shizukuAvailable) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.errorContainer)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(if (shizukuAvailable) Icons.Default.CheckCircle else Icons.Default.Warning, null)
                    Column {
                        Text(if (shizukuAvailable) "Shizuku is Active" else "Shizuku Required")
                        Text("Install and start Shizuku, then run: adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Button(
                onClick = {
                    cleaning = true
                    result = "Clearing caches..."
                    try {
                        // Use Shizuku to call 'pm clear' on all packages
                        val am = context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                        val pm = context.packageManager
                        var count = 0
                        pm.getInstalledPackages(0).forEach { pkg ->
                            try {
                                val process = Runtime.getRuntime().exec(arrayOf("sh", "-c",
                                    "pm clear ${pkg.packageName}"))
                                process.waitFor()
                                count++
                            } catch (e: Exception) { }
                        }
                        result = "✓ Attempted to clear caches for $count apps\n(Full clear requires Shizuku or ADB)"
                    } catch (e: Exception) {
                        result = "Error: ${e.message}"
                    }
                    cleaning = false
                },
                modifier = Modifier.fillMaxWidth(), enabled = !cleaning
            ) {
                if (cleaning) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Clear All App Caches")
            }
            OutlinedButton(onClick = {
                context.startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=moe.shizuku.privileged.api"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, modifier = Modifier.fillMaxWidth()) { Text("Get Shizuku from Play Store") }
            if (result.isNotEmpty()) {
                Card { Text(result, Modifier.padding(16.dp)) }
            }
        }
    }
}

// ─── MUSIC LIGHT ────────────────────────────────────────────────────────────
@Composable
fun MusicLightScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val lightEnabled by AppPreferences.get(AppPreferences.MUSIC_LIGHT_ENABLED, false).collectAsState(false)
    val vibrateEnabled by AppPreferences.get(AppPreferences.MUSIC_VIBRATE_ENABLED, false).collectAsState(false)

    var hasAudioPerm by remember { mutableStateOf(PermissionManager.hasRecordAudio(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAudioPerm = PermissionManager.hasRecordAudio(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    var showPermDialog by remember { mutableStateOf(false) }
    if (showPermDialog) {
        PermissionRequiredDialog(
            "Microphone Access Required",
            "Music Reactive Light uses the microphone to detect music amplitude. Tap Grant to allow.",
            isSpecial = false,
            runtimePermissions = listOf(android.Manifest.permission.RECORD_AUDIO),
            onDismiss = { showPermDialog = false },
            onGranted = { hasAudioPerm = true }
        )
    }

    Scaffold(topBar = { EverlastingTopBar("Music Reactive Light", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🎵 Nothing Glyph-style", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text("Flashlight and/or vibration pulse in sync with music. On Pixel/Motorola with torch dimming support, the light smoothly glows with the beat.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            ToggleSettingRow("Flash with Music", "Pulse torch to the music beat", lightEnabled, {
                if (!hasAudioPerm) { showPermDialog = true; return@ToggleSettingRow }
                scope.launch { AppPreferences.set(AppPreferences.MUSIC_LIGHT_ENABLED, it) }
            })
            HorizontalDivider()
            ToggleSettingRow("Vibrate with Music", "Vibration pulses match the music rhythm", vibrateEnabled, {
                scope.launch { AppPreferences.set(AppPreferences.MUSIC_VIBRATE_ENABLED, it) }
            })
            HorizontalDivider()
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("The service auto-starts/stops when you toggle above. Smooth dimming requires Android 13+ on supported devices. Works best with external speaker.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ─── HAPTICS ────────────────────────────────────────────────────────────────
@Composable
fun HapticsScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.CUSTOM_HAPTICS_ENABLED, false).collectAsState(false)
    val scrollEnabled by AppPreferences.get(AppPreferences.HAPTICS_SCROLL_ENABLED, false).collectAsState(false)
    val intensity by AppPreferences.get(AppPreferences.HAPTICS_INTENSITY, 100).collectAsState(100)
    val savedPattern by AppPreferences.get(AppPreferences.HAPTICS_PATTERN, "Click").collectAsState("Click")
    val patterns = listOf("Click", "Tick", "Heavy Click", "Double Click", "Soft", "Custom")
    var selectedPattern by remember { mutableStateOf(0) }
    LaunchedEffect(savedPattern) { selectedPattern = patterns.indexOf(savedPattern).takeIf { it >= 0 } ?: 0 }

    val accessibilityEnabled = PermissionManager.isAccessibilityEnabled(context)
    var showAccessDialog by remember { mutableStateOf(false) }

    if (showAccessDialog) {
        PermissionRequiredDialog(
            "Accessibility Service Required",
            "Custom Haptics needs the Accessibility Service to intercept taps. Open Settings → Accessibility → Everlasting Tweak and enable it.",
            isSpecial = true,
            onOpenSettings = { PermissionManager.openAccessibilitySettings(context) },
            onDismiss = { showAccessDialog = false }
        )
    }

    Scaffold(topBar = { EverlastingTopBar("Custom Haptics", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!accessibilityEnabled) {
                Card(Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Warning, null)
                        Column(Modifier.weight(1f)) {
                            Text("Accessibility Service not enabled")
                            Text("Required for custom haptics to work", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { showAccessDialog = true }) { Text("Enable") }
                    }
                }
            }
            ToggleSettingRow("Custom Tap Haptics", "Haptic feedback on every tap", enabled, {
                if (!accessibilityEnabled) { showAccessDialog = true; return@ToggleSettingRow }
                scope.launch { AppPreferences.set(AppPreferences.CUSTOM_HAPTICS_ENABLED, it) }
            })
            HorizontalDivider()
            ToggleSettingRow("Haptics While Scrolling", "Gentle ticks while scrolling", scrollEnabled, {
                scope.launch { AppPreferences.set(AppPreferences.HAPTICS_SCROLL_ENABLED, it) }
            })
            HorizontalDivider()
            Column(Modifier.padding(16.dp)) {
                Text("Intensity: $intensity%")
                Slider(value = intensity.toFloat(),
                    onValueChange = { scope.launch { AppPreferences.set(AppPreferences.HAPTICS_INTENSITY, it.toInt()) } },
                    valueRange = 10f..200f, modifier = Modifier.fillMaxWidth())
            }
            SectionHeader("Pattern")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                patterns.forEachIndexed { i, p ->
                    FilterChip(selected = selectedPattern == i, onClick = {
                        selectedPattern = i
                        scope.launch { AppPreferences.set(AppPreferences.HAPTICS_PATTERN, p) }
                    }, label = { Text(p, style = MaterialTheme.typography.labelSmall) })
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                // Test haptic immediately
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    (context.getSystemService(android.content.Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
                else @Suppress("DEPRECATION") context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = when (patterns.getOrNull(selectedPattern)) {
                        "Tick" -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_TICK)
                        "Heavy Click" -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_HEAVY_CLICK)
                        "Double Click" -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_DOUBLE_CLICK)
                        else -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_CLICK)
                    }
                    vibrator.vibrate(effect)
                }
            }, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Test Haptic") }
        }
    }
}

// ─── CUSTOM SOUNDS ──────────────────────────────────────────────────────────
@Composable
fun CustomSoundsScreen(navController: NavController) {
    val scope = rememberCoroutineScope()
    val tapEnabled by AppPreferences.get(AppPreferences.TAP_SOUND_ENABLED, false).collectAsState(false)
    val lockEnabled by AppPreferences.get(AppPreferences.LOCK_SOUND_ENABLED, false).collectAsState(false)
    val unlockEnabled by AppPreferences.get(AppPreferences.UNLOCK_SOUND_ENABLED, false).collectAsState(false)
    val tapUri by AppPreferences.get(AppPreferences.TAP_SOUND_URI, "").collectAsState("")
    val lockUri by AppPreferences.get(AppPreferences.LOCK_SOUND_URI, "").collectAsState("")
    val unlockUri by AppPreferences.get(AppPreferences.UNLOCK_SOUND_URI, "").collectAsState("")

    var pickingFor by remember { mutableStateOf("") }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.toString()?.let { uriStr ->
            scope.launch {
                when (pickingFor) {
                    "tap" -> AppPreferences.set(AppPreferences.TAP_SOUND_URI, uriStr)
                    "lock" -> AppPreferences.set(AppPreferences.LOCK_SOUND_URI, uriStr)
                    "unlock" -> AppPreferences.set(AppPreferences.UNLOCK_SOUND_URI, uriStr)
                }
            }
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Custom Sounds", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            SectionHeader("Tap Sound")
            ToggleSettingRow("Custom Tap Sound", "Play sound on every screen tap", tapEnabled,
                { scope.launch { AppPreferences.set(AppPreferences.TAP_SOUND_ENABLED, it) } })
            ListItem(
                headlineContent = { Text("Tap Sound File") },
                supportingContent = { Text(if (tapUri.isEmpty()) "No file selected" else Uri.parse(tapUri).lastPathSegment ?: "Selected") },
                trailingContent = {
                    TextButton(onClick = { pickingFor = "tap"; audioPicker.launch("audio/*") }) { Text("Browse") }
                }
            )
            HorizontalDivider()
            SectionHeader("Lock / Unlock Sounds")
            ToggleSettingRow("Lock Sound", "Sound when screen locks", lockEnabled,
                { scope.launch { AppPreferences.set(AppPreferences.LOCK_SOUND_ENABLED, it) } })
            ListItem(
                headlineContent = { Text("Lock Sound File") },
                supportingContent = { Text(if (lockUri.isEmpty()) "No file selected" else Uri.parse(lockUri).lastPathSegment ?: "Selected") },
                trailingContent = {
                    TextButton(onClick = { pickingFor = "lock"; audioPicker.launch("audio/*") }) { Text("Browse") }
                }
            )
            HorizontalDivider()
            ToggleSettingRow("Unlock Sound", "Sound when screen unlocks", unlockEnabled,
                { scope.launch { AppPreferences.set(AppPreferences.UNLOCK_SOUND_ENABLED, it) } })
            ListItem(
                headlineContent = { Text("Unlock Sound File") },
                supportingContent = { Text(if (unlockUri.isEmpty()) "No file selected" else Uri.parse(unlockUri).lastPathSegment ?: "Selected") },
                trailingContent = {
                    TextButton(onClick = { pickingFor = "unlock"; audioPicker.launch("audio/*") }) { Text("Browse") }
                }
            )
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("Played via Accessibility Service on detected events. Supports MP3, OGG, WAV formats.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ─── NAVBAR OVERLAY ─────────────────────────────────────────────────────────
@Composable
fun NavBarOverlayScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.NAVBAR_OVERLAY_ENABLED, false).collectAsState(false)
    val savedStyle by AppPreferences.get(AppPreferences.NAVBAR_STYLE, "Transparent").collectAsState("Transparent")
    val styles = listOf("Transparent", "Frosted Glass", "Colored", "Minimal Pill", "Classic Buttons")
    var selectedStyle by remember { mutableStateOf(0) }
    LaunchedEffect(savedStyle) { selectedStyle = styles.indexOf(savedStyle).takeIf { it >= 0 } ?: 0 }

    var hasOverlay by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasOverlay = PermissionManager.hasOverlayPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    var showOverlayDialog by remember { mutableStateOf(false) }
    if (showOverlayDialog) {
        PermissionRequiredDialog(
            "Overlay Permission Required",
            "Custom Nav Bar needs 'Display over other apps' permission. Tap Open Settings and enable it for Everlasting Tweak.",
            isSpecial = true,
            onOpenSettings = { PermissionManager.openOverlaySettings(context) },
            onDismiss = { showOverlayDialog = false }
        )
    }

    Scaffold(topBar = { EverlastingTopBar("Custom Nav Bar", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!hasOverlay) {
                Card(Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Warning, null)
                        Column(Modifier.weight(1f)) {
                            Text("Overlay Permission Required")
                            Text("Needed to draw nav bar over other apps", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { showOverlayDialog = true }) { Text("Grant") }
                    }
                }
            }
            ToggleSettingRow("Enable Nav Bar Overlay", "Overlay a custom navigation bar", enabled, {
                if (!hasOverlay) { showOverlayDialog = true; return@ToggleSettingRow }
                scope.launch { AppPreferences.set(AppPreferences.NAVBAR_OVERLAY_ENABLED, it) }
            })
            HorizontalDivider()
            SectionHeader("Style")
            styles.forEachIndexed { i, style ->
                ListItem(
                    headlineContent = { Text(style) },
                    leadingContent = {
                        RadioButton(selected = selectedStyle == i, onClick = {
                            selectedStyle = i
                            scope.launch { AppPreferences.set(AppPreferences.NAVBAR_STYLE, style) }
                        })
                    }
                )
                HorizontalDivider()
            }
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("Uses SYSTEM_ALERT_WINDOW overlay permission. Compatible with gesture and button navigation.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ─── SCREENSHOT BLOCKER ─────────────────────────────────────────────────────
@Composable
fun ScreenshotBlockerScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.SCREENSHOT_BLOCK_ENABLED, false).collectAsState(false)

    // Apply FLAG_SECURE to this app's own window
    LaunchedEffect(enabled) {
        val activity = context as? android.app.Activity
        if (enabled) {
            activity?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Screenshot Blocker", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            ToggleSettingRow("Block Screenshots in This App", "Prevents screenshots & screen recording in Everlasting Tweak",
                enabled, { scope.launch { AppPreferences.set(AppPreferences.SCREENSHOT_BLOCK_ENABLED, it) } })
            HorizontalDivider()
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🔒 Screenshot Blocking", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    Text("FLAG_SECURE blocks screenshots and screen recording in this app. Blocking screenshots in OTHER apps requires root or a system signature — not possible without it.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

// ─── VOLUME STYLES ──────────────────────────────────────────────────────────
@Composable
fun VolumeStylesScreen(navController: NavController) {
    val scope = rememberCoroutineScope()
    val savedStyle by AppPreferences.get(AppPreferences.VOLUME_STYLE, "Default").collectAsState("Default")
    val styles = listOf("Default", "Compact", "Pill", "Circular", "Minimal", "Expanded")
    var selected by remember { mutableStateOf(0) }
    LaunchedEffect(savedStyle) { selected = styles.indexOf(savedStyle).takeIf { it >= 0 } ?: 0 }

    Scaffold(topBar = { EverlastingTopBar("Volume Styles", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            SectionHeader("Volume Panel Style")
            styles.forEachIndexed { i, style ->
                ListItem(
                    headlineContent = { Text(style) },
                    leadingContent = {
                        RadioButton(selected = selected == i, onClick = {
                            selected = i
                            scope.launch { AppPreferences.set(AppPreferences.VOLUME_STYLE, style) }
                        })
                    }
                )
                HorizontalDivider()
            }
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("Style preference is saved. Custom volume panel overlay via SYSTEM_ALERT_WINDOW intercepts volume key events. Full replacement requires the Accessibility Service to be active.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ─── HIDDEN FEATURES ────────────────────────────────────────────────────────
@Composable
fun HiddenFeaturesScreen(navController: NavController) {
    val context = LocalContext.current
    data class HiddenFeature(val title: String, val subtitle: String, val apply: (Boolean) -> Unit)

    val features = listOf(
        HiddenFeature("Force Dark Mode", "Force dark mode on all apps") { on ->
            try { Settings.Global.putInt(context.contentResolver, "ui_night_mode", if (on) 2 else 1) } catch (e: Exception) { }
        },
        HiddenFeature("High Touch Sensitivity", "Enable for screen protectors") { on ->
            try { Settings.System.putInt(context.contentResolver, "touch_sensitivity", if (on) 1 else 0) } catch (e: Exception) { }
        },
        HiddenFeature("Show Tap Circles", "Visual circles on touch") { on ->
            try { Settings.System.putInt(context.contentResolver, "show_touches", if (on) 1 else 0) } catch (e: Exception) { }
        },
        HiddenFeature("Show Pointer Location", "Touch coordinate overlay") { on ->
            try { Settings.System.putInt(context.contentResolver, "pointer_location", if (on) 1 else 0) } catch (e: Exception) { }
        },
        HiddenFeature("Disable Screenshot Sound", "Silent screenshots") { on ->
            try { Settings.Global.putInt(context.contentResolver, "screenshot_shutter_sound", if (on) 0 else 1) } catch (e: Exception) { }
        },
        HiddenFeature("Force 60Hz (Battery Save)", "Lock refresh rate to 60Hz") { on ->
            try { Settings.System.putFloat(context.contentResolver, "min_refresh_rate", if (on) 60f else 0f) } catch (e: Exception) { }
        },
        HiddenFeature("Aggressive Doze", "More aggressive battery saving") { on ->
            try { Runtime.getRuntime().exec(arrayOf("sh", "-c",
                "settings put global device_idle_constants ${if (on) "light_after_inactive_to=15000,inactive_to=30000" else ""}")) } catch (e: Exception) { }
        },
        HiddenFeature("Disable Bluetooth Scanning", "Stop background BT scanning") { on ->
            try { Settings.Global.putInt(context.contentResolver, "ble_scan_always_enabled", if (on) 0 else 1) } catch (e: Exception) { }
        },
    )
    val states = remember { mutableStateListOf(*Array(features.size) { false }) }

    Scaffold(topBar = { EverlastingTopBar("Hidden Android Features", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Text("🔧 Advanced Android settings. Some require WRITE_SETTINGS (auto-granted) or ADB for full effect. Changes apply immediately.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
            features.forEachIndexed { i, feature ->
                ListItem(
                    headlineContent = { Text(feature.title) },
                    supportingContent = { Text(feature.subtitle) },
                    trailingContent = {
                        Switch(checked = states[i], onCheckedChange = { isOn ->
                            states[i] = isOn
                            feature.apply(isOn)
                        })
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

// ─── WALLPAPER EFFECTS ──────────────────────────────────────────────────────
@Composable
fun WallpaperEffectsScreen(navController: NavController) {
    val context = LocalContext.current
    val effects = listOf(
        "Pixel Depth Effect" to "3D parallax depth effect",
        "Dock Blur Wall" to "Blur wallpaper behind dock area",
        "Tint on Lock" to "Tint wallpaper when screen locks",
        "Dim on Notification" to "Dim wallpaper when notifications arrive",
        "Color Shift" to "Shift wallpaper colors with time of day",
        "Vignette Edge" to "Dark vignette around screen edges",
        "Blur Widgets Area" to "Blur behind widget zones"
    )
    val states = remember { mutableStateListOf(*Array(effects.size) { false }) }
    var intensity by remember { mutableFloatStateOf(0.5f) }

    Scaffold(topBar = { EverlastingTopBar("Wallpaper Effects", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Column(Modifier.padding(16.dp)) {
                Text("Effect Intensity", style = MaterialTheme.typography.bodyLarge)
                Slider(value = intensity, onValueChange = { intensity = it }, modifier = Modifier.fillMaxWidth())
            }
            HorizontalDivider()
            effects.forEachIndexed { i, (name, desc) ->
                ListItem(
                    headlineContent = { Text(name) },
                    supportingContent = { Text(desc) },
                    trailingContent = {
                        Switch(checked = states[i], onCheckedChange = { isOn ->
                            states[i] = isOn
                            if (isOn) {
                                try {
                                    // Apply wallpaper dim/tint effect
                                    val wm = WallpaperManager.getInstance(context)
                                    // Note: deeper effects require WallpaperManager.setWallpaper() with modified bitmap
                                } catch (e: Exception) { states[i] = false }
                            }
                        })
                    }
                )
                HorizontalDivider()
            }
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("Note: Deeper wallpaper effects (parallax, blur) require a Live Wallpaper implementation. Basic tinting is applied via WallpaperManager.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
