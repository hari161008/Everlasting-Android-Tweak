package com.coolappstore.everlastingandroidtweak.ui.screens

import android.app.Activity
import android.app.TimePickerDialog
import android.app.WallpaperManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.features.autoreboot.AutoRebootScheduler
import com.coolappstore.everlastingandroidtweak.features.cache.CacheCleanerHelper
import com.coolappstore.everlastingandroidtweak.features.navbar.NavBarOverlayService
import com.coolappstore.everlastingandroidtweak.ui.components.*
import com.coolappstore.everlastingandroidtweak.ui.navigation.Screen
import com.coolappstore.everlastingandroidtweak.utils.PermissionManager
import kotlinx.coroutines.launch

// ─── COLOR PICKER ROW HELPER ─────────────────────────────────────────────────
@Composable
private fun ColorPickerRow(label: String, colorHex: String, onColorChange: (String) -> Unit) {
    val presets = listOf("#FFFFFF", "#000000", "#FF5722", "#2196F3", "#4CAF50", "#FFC107", "#9C27B0", "#00BCD4")
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEach { hex ->
                val color = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.White }
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(color)
                        .border(
                            width = if (colorHex.equals(hex, true)) 3.dp else 1.dp,
                            color = if (colorHex.equals(hex, true)) MaterialTheme.colorScheme.primary else Color.Gray,
                            shape = CircleShape
                        )
                        .clickable { onColorChange(hex) }
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        var customText by remember { mutableStateOf(colorHex) }
        OutlinedTextField(
            value = customText,
            onValueChange = { customText = it; if (it.matches(Regex("#[0-9A-Fa-f]{6}"))) onColorChange(it) },
            label = { Text("Custom hex (e.g. #FF5722)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
    }
}

// ─── SCREENSAVER ─────────────────────────────────────────────────────────────
@Composable
fun ScreensaverScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val themes = listOf("Clock", "Photo Slideshow", "Colors", "Nature", "Abstract")
    val savedTheme by AppPreferences.get(AppPreferences.SCREENSAVER_THEME, "Clock").collectAsState("Clock")
    var selected by remember { mutableStateOf(0) }
    LaunchedEffect(savedTheme) { selected = themes.indexOf(savedTheme).takeIf { it >= 0 } ?: 0 }

    Scaffold(topBar = { EverlastingTopBar("Screensaver", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            FeatureSection("Theme") {
                themes.forEachIndexed { i, theme ->
                    ListItem(
                        headlineContent = { Text(theme) },
                        leadingContent = { RadioButton(selected = selected == i, onClick = {
                            selected = i
                            scope.launch { AppPreferences.set(AppPreferences.SCREENSAVER_THEME, theme) }
                        }) }
                    )
                    if (i < themes.lastIndex) HorizontalDivider()
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                try {
                    context.startActivity(Intent(Intent.ACTION_MAIN).apply {
                        setClassName("com.android.systemui", "com.android.systemui.DreamActivity")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (_: Exception) {
                    context.startActivity(Intent(Settings.ACTION_DREAM_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Preview Screensaver") }
            OutlinedButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_DREAM_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { Text("Open Screensaver Settings") }
        }
    }
}

// ─── AUTO REBOOT ─────────────────────────────────────────────────────────────
@Composable
fun AutoRebootScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.AUTO_REBOOT_ENABLED, false).collectAsState(false)
    val savedTime by AppPreferences.get(AppPreferences.AUTO_REBOOT_TIME, "03:00").collectAsState("03:00")
    val savedDays by AppPreferences.get(AppPreferences.AUTO_REBOOT_DAYS, "").collectAsState("")
    var hour by remember { mutableIntStateOf(3) }
    var minute by remember { mutableIntStateOf(0) }
    LaunchedEffect(savedTime) {
        savedTime.split(":").let { parts ->
            hour = parts.getOrNull(0)?.toIntOrNull() ?: 3
            minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        }
    }
    val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val selectedDays = remember { mutableStateListOf(*Array(7) { false }) }
    LaunchedEffect(savedDays) {
        savedDays.split(",").mapNotNull { it.toIntOrNull() }.forEach { if (it in 0..6) selectedDays[it] = true }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    var alarmPerm by remember { mutableStateOf(PermissionManager.hasExactAlarmPermission(context)) }
    var accessibilityEnabled by remember { mutableStateOf(PermissionManager.isAccessibilityEnabled(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) alarmPerm = PermissionManager.hasExactAlarmPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Auto Reboot", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!alarmPerm) {
                InfoCard(
                    icon = Icons.Default.Warning,
                    title = "Exact Alarm Permission Required",
                    subtitle = "Needed for precise reboot scheduling",
                    isError = true,
                    actionLabel = "Grant",
                    onAction = { PermissionManager.openExactAlarmSettings(context) }
                )
            }
            if (!accessibilityEnabled) {
                InfoCard(
                    icon = Icons.Default.Accessibility,
                    title = "Accessibility Service Recommended",
                    subtitle = "Enables graceful reboot via accessibility action",
                    isError = false,
                    actionLabel = "Enable",
                    onAction = { PermissionManager.openAccessibilitySettings(context) }
                )
            }

            FeatureSection("Schedule") {
                ToggleSettingRow("Enable Auto Reboot", "Automatically reboot at scheduled time", enabled,
                    { scope.launch { AppPreferences.set(AppPreferences.AUTO_REBOOT_ENABLED, it); if (!it) AutoRebootScheduler.cancel(context) } })
                HorizontalDivider()
                // Android clock time picker
                ListItem(
                    headlineContent = { Text("Reboot Time") },
                    supportingContent = { Text("${hour.toString().padStart(2,'0')}:${minute.toString().padStart(2,'0')}") },
                    trailingContent = {
                        OutlinedButton(onClick = {
                            TimePickerDialog(context, { _, h, m ->
                                hour = h; minute = m
                            }, hour, minute, true).show()
                        }) { Text("Set Time") }
                    }
                )
                HorizontalDivider()
                // Day chips
                Column(Modifier.padding(16.dp)) {
                    Text("Repeat Days", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        dayNames.forEachIndexed { i, d ->
                            FilterChip(
                                selected = selectedDays[i],
                                onClick = { selectedDays[i] = !selectedDays[i] },
                                label = { Text(d, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                scope.launch {
                    val timeStr = "${hour.toString().padStart(2,'0')}:${minute.toString().padStart(2,'0')}"
                    val daysStr = selectedDays.mapIndexedNotNull { i, s -> if (s) i.toString() else null }.joinToString(",")
                    AppPreferences.set(AppPreferences.AUTO_REBOOT_TIME, timeStr)
                    AppPreferences.set(AppPreferences.AUTO_REBOOT_DAYS, daysStr)
                }
                AutoRebootScheduler.schedule(context, hour, minute, selectedDays.toList())
            }, modifier = Modifier.fillMaxWidth().padding(16.dp), enabled = enabled && alarmPerm) { Text("Save Schedule") }

            InfoCard(
                icon = Icons.Default.Info,
                title = "ADB required for actual reboot",
                subtitle = "adb shell pm grant ${context.packageName} android.permission.REBOOT",
                isError = false
            )
        }
    }
}

// ─── WATERMARK ───────────────────────────────────────────────────────────────
@Composable
fun WatermarkScreen(navController: NavController) {
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.WATERMARK_ENABLED, false).collectAsState(false)
    val savedText by AppPreferences.get(AppPreferences.WATERMARK_TEXT, "© My Photo").collectAsState("© My Photo")
    val savedPos by AppPreferences.get(AppPreferences.WATERMARK_POSITION, "Bottom Right").collectAsState("Bottom Right")
    val savedFontSize by AppPreferences.get(AppPreferences.WATERMARK_FONT_SIZE, 3.5f).collectAsState(3.5f)
    val savedColor by AppPreferences.get(AppPreferences.WATERMARK_COLOR, "#FFFFFF").collectAsState("#FFFFFF")
    val savedOpacity by AppPreferences.get(AppPreferences.WATERMARK_OPACITY, 0.78f).collectAsState(0.78f)
    val savedBold by AppPreferences.get(AppPreferences.WATERMARK_BOLD, false).collectAsState(false)
    val savedShadow by AppPreferences.get(AppPreferences.WATERMARK_SHADOW, true).collectAsState(true)

    var watermarkText by remember { mutableStateOf("© My Photo") }
    LaunchedEffect(savedText) { watermarkText = savedText }
    var fontSize by remember { mutableFloatStateOf(3.5f) }
    LaunchedEffect(savedFontSize) { fontSize = savedFontSize }
    var opacity by remember { mutableFloatStateOf(0.78f) }
    LaunchedEffect(savedOpacity) { opacity = savedOpacity }
    val positions = listOf("Bottom Right","Bottom Left","Bottom Center","Top Right","Top Left","Top Center","Center")
    var selectedPos by remember { mutableStateOf(0) }
    LaunchedEffect(savedPos) { selectedPos = positions.indexOf(savedPos).takeIf { it >= 0 } ?: 0 }

    Scaffold(topBar = { EverlastingTopBar("Auto Watermark", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            FeatureSection("Watermark") {
                ToggleSettingRow("Enable Auto Watermark", "Add watermark to photos automatically", enabled,
                    { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_ENABLED, it) } })
                HorizontalDivider()
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = watermarkText, onValueChange = { watermarkText = it },
                        label = { Text("Watermark Text") }, modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_TEXT, watermarkText) } }) {
                                Icon(Icons.Default.Save, "Save")
                            }
                        }
                    )
                }
            }
            FeatureSection("Position") {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        positions.take(4).forEachIndexed { i, pos ->
                            FilterChip(selected = selectedPos == i, onClick = {
                                selectedPos = i
                                scope.launch { AppPreferences.set(AppPreferences.WATERMARK_POSITION, pos) }
                            }, label = { Text(pos, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        positions.drop(4).forEachIndexed { i, pos ->
                            val idx = i + 4
                            FilterChip(selected = selectedPos == idx, onClick = {
                                selectedPos = idx
                                scope.launch { AppPreferences.set(AppPreferences.WATERMARK_POSITION, pos) }
                            }, label = { Text(pos, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                }
            }
            FeatureSection("Style") {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Font Size: ${"%.1f".format(fontSize)}%", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = fontSize, onValueChange = { fontSize = it; scope.launch { AppPreferences.set(AppPreferences.WATERMARK_FONT_SIZE, it) } }, valueRange = 1f..8f, modifier = Modifier.fillMaxWidth())
                    Text("Opacity: ${(opacity * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = opacity, onValueChange = { opacity = it; scope.launch { AppPreferences.set(AppPreferences.WATERMARK_OPACITY, it) } }, valueRange = 0.1f..1f, modifier = Modifier.fillMaxWidth())
                }
                ColorPickerRow("Text Color", savedColor) { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_COLOR, it) } }
                HorizontalDivider()
                ToggleSettingRow("Bold Text", "Use bold font weight", savedBold,
                    { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_BOLD, it) } })
                HorizontalDivider()
                ToggleSettingRow("Drop Shadow", "Add shadow behind text for readability", savedShadow,
                    { scope.launch { AppPreferences.set(AppPreferences.WATERMARK_SHADOW, it) } })
            }
        }
    }
}

// ─── CACHE CLEANER ───────────────────────────────────────────────────────────
@Composable
fun CacheCleanerScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var shizukuAvailable by remember { mutableStateOf(false) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }

    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                shizukuAvailable = CacheCleanerHelper.isShizukuReady()
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Cache Cleaner", navController) }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (shizukuAvailable)
                        MaterialTheme.colorScheme.primaryContainer
                    else
                        MaterialTheme.colorScheme.errorContainer
                ),
                shape = MaterialTheme.shapes.large
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(if (shizukuAvailable) Icons.Default.CheckCircle else Icons.Default.Warning, null)
                    Column {
                        Text(if (shizukuAvailable) "Shizuku is Active" else "Shizuku Required",
                            style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (shizukuAvailable) "Ready to clear caches"
                            else "Run: adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Button(
                onClick = {
                    cleaning = true
                    result = ""
                    scope.launch {
                        try {
                            val cleared = CacheCleanerHelper.clearAllCache(context)
                            result = if (cleared > 0) "✓ Cleared caches for $cleared apps" else "⚠ No caches cleared (root/Shizuku needed)"
                            Toast.makeText(
                                context,
                                if (cleared > 0) "✓ Cleared $cleared app caches" else "⚠ Cache clear failed — Shizuku needed",
                                Toast.LENGTH_SHORT
                            ).show()
                        } catch (e: Exception) {
                            result = "Error: ${e.message}"
                            Toast.makeText(context, "Error clearing cache: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            cleaning = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !cleaning
            ) {
                if (cleaning) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text(if (cleaning) "Clearing…" else "Clear All App Caches")
            }

            OutlinedButton(
                onClick = {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Get Shizuku from Play Store") }

            if (result.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (result.startsWith("✓"))
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = MaterialTheme.shapes.large
                ) {
                    Text(result, Modifier.padding(16.dp))
                }
            }
        }
    }
}

// ─── MUSIC LIGHT ─────────────────────────────────────────────────────────────
@Composable
fun MusicLightScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val lightEnabled   by AppPreferences.get(AppPreferences.MUSIC_LIGHT_ENABLED, false).collectAsState(false)
    val vibrateEnabled by AppPreferences.get(AppPreferences.MUSIC_VIBRATE_ENABLED, false).collectAsState(false)
    val savedSensitivity by AppPreferences.get(AppPreferences.MUSIC_LIGHT_SENSITIVITY, 0.35f).collectAsState(0.35f)
    val savedSpeed       by AppPreferences.get(AppPreferences.MUSIC_SPEED_SENSITIVITY, 1.0f).collectAsState(1.0f)
    var sensitivity by remember { mutableFloatStateOf(0.35f) }
    var speed       by remember { mutableFloatStateOf(1.0f) }
    LaunchedEffect(savedSensitivity) { sensitivity = savedSensitivity }
    LaunchedEffect(savedSpeed)       { speed       = savedSpeed }

    var hasAudioPerm by remember { mutableStateOf(PermissionManager.hasRecordAudio(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAudioPerm = PermissionManager.hasRecordAudio(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    var showPermDialog by remember { mutableStateOf(false) }
    if (showPermDialog) {
        PermissionRequiredDialog(
            "Microphone Access Required",
            "Music Reactive Light uses the microphone to detect audio. Tap Grant to allow.",
            isSpecial = false,
            runtimePermissions = listOf(android.Manifest.permission.RECORD_AUDIO),
            onDismiss = { showPermDialog = false },
            onGranted  = { hasAudioPerm = true }
        )
    }

    Scaffold(topBar = { EverlastingTopBar("Music Reactive Light", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("🎵 Glyph-style Reactive Light", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text("Flashlight and/or vibration pulses in sync with music.", style = MaterialTheme.typography.bodySmall)
                }
            }
            FeatureSection("Controls") {
                ToggleSettingRow("Flash with Music", "Pulse torch to the music beat", lightEnabled, {
                    if (!hasAudioPerm) { showPermDialog = true; return@ToggleSettingRow }
                    scope.launch { AppPreferences.set(AppPreferences.MUSIC_LIGHT_ENABLED, it) }
                })
                HorizontalDivider()
                ToggleSettingRow("Vibrate with Music", "Vibration pulses match the music rhythm", vibrateEnabled,
                    { scope.launch { AppPreferences.set(AppPreferences.MUSIC_VIBRATE_ENABLED, it) } })
            }
            FeatureSection("Sensitivity — Reacts to Sound") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    val pct = ((1f - sensitivity) * 100).toInt()
                    Text(
                        "Level: $pct% — ${if (pct > 70) "Very Reactive" else if (pct > 40) "Balanced" else "Only Loud Beats"}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(4.dp))
                    Slider(
                        value = 1f - sensitivity,
                        onValueChange = {
                            sensitivity = 1f - it
                            scope.launch { AppPreferences.set(AppPreferences.MUSIC_LIGHT_SENSITIVITY, 1f - it) }
                        },
                        valueRange = 0f..0.9f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Low = reacts to quiet audio   |   High = only reacts to loud beats",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            FeatureSection("Speed — Flash/Vibrate Rate") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    val speedLabel = when {
                        speed < 0.5f -> "Very Slow"
                        speed < 0.9f -> "Slow"
                        speed < 1.3f -> "Normal"
                        speed < 1.7f -> "Fast"
                        else         -> "Very Fast"
                    }
                    Text("Speed: ${speedLabel} (${String.format("%.1f", speed)}×)",
                        style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Slider(
                        value = speed,
                        onValueChange = {
                            speed = it
                            scope.launch { AppPreferences.set(AppPreferences.MUSIC_SPEED_SENSITIVITY, it) }
                        },
                        valueRange = 0.2f..2.0f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Low = slow blink   |   High = rapid flash matching beat",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ─── HAPTICS ─────────────────────────────────────────────────────────────────
@Composable
fun HapticsScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled       by AppPreferences.get(AppPreferences.CUSTOM_HAPTICS_ENABLED, false).collectAsState(false)
    val scrollEnabled by AppPreferences.get(AppPreferences.HAPTICS_SCROLL_ENABLED, false).collectAsState(false)
    val intensity     by AppPreferences.get(AppPreferences.HAPTICS_INTENSITY, 100).collectAsState(100)
    val savedPattern  by AppPreferences.get(AppPreferences.HAPTICS_PATTERN, "Click").collectAsState("Click")
    val patterns = listOf("Click", "Tick", "Heavy Click", "Double Click", "Soft", "Custom")
    var selectedPattern by remember { mutableStateOf(0) }
    LaunchedEffect(savedPattern) { selectedPattern = patterns.indexOf(savedPattern).takeIf { it >= 0 } ?: 0 }
    var accessibilityEnabled by remember { mutableStateOf(PermissionManager.isAccessibilityEnabled(context)) }
    var showAccessDialog by remember { mutableStateOf(false) }
    if (showAccessDialog) {
        PermissionRequiredDialog("Accessibility Service Required",
            "Custom Haptics needs the Accessibility Service. Open Settings → Accessibility → Everlasting Tweak and enable it.",
            isSpecial = true, onOpenSettings = { PermissionManager.openAccessibilitySettings(context) }, onDismiss = { showAccessDialog = false })
    }

    val lifecycleOwnerHapticsScreen = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwnerHapticsScreen) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                accessibilityEnabled = PermissionManager.isAccessibilityEnabled(context)
            }
        }
        lifecycleOwnerHapticsScreen.lifecycle.addObserver(obs)
        onDispose { lifecycleOwnerHapticsScreen.lifecycle.removeObserver(obs) }
    }
    Scaffold(topBar = { EverlastingTopBar("Custom Haptics", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!accessibilityEnabled) {
                InfoCard(Icons.Default.Warning, "Accessibility Service not enabled", "Required for custom haptics",
                    isError = true, actionLabel = "Enable", onAction = { showAccessDialog = true })
            }
            FeatureSection("Haptic Feedback") {
                ToggleSettingRow("Custom Tap Haptics", "Haptic feedback on every tap", enabled, {
                    if (!accessibilityEnabled) { showAccessDialog = true; return@ToggleSettingRow }
                    scope.launch { AppPreferences.set(AppPreferences.CUSTOM_HAPTICS_ENABLED, it) }
                })
                HorizontalDivider()
                ToggleSettingRow("Haptics While Scrolling", "Gentle ticks while scrolling", scrollEnabled,
                    { scope.launch { AppPreferences.set(AppPreferences.HAPTICS_SCROLL_ENABLED, it) } })
                HorizontalDivider()
                Column(Modifier.padding(16.dp)) {
                    Text("Intensity: $intensity%")
                    Slider(value = intensity.toFloat(), onValueChange = { scope.launch { AppPreferences.set(AppPreferences.HAPTICS_INTENSITY, it.toInt()) } },
                        valueRange = 10f..200f, modifier = Modifier.fillMaxWidth())
                }
            }
            FeatureSection("Pattern") {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    patterns.forEachIndexed { i, p ->
                        FilterChip(selected = selectedPattern == i, onClick = {
                            selectedPattern = i
                            scope.launch { AppPreferences.set(AppPreferences.HAPTICS_PATTERN, p) }
                        }, label = { Text(p, style = MaterialTheme.typography.labelSmall) })
                    }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = {
                    val vibrator = (context.getSystemService(android.content.Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(when (patterns.getOrNull(selectedPattern)) {
                            "Tick"         -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_TICK)
                            "Heavy Click"  -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_HEAVY_CLICK)
                            "Double Click" -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_DOUBLE_CLICK)
                            else           -> android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_CLICK)
                        })
                    }
                }, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Test Haptic") }
            }
        }
    }
}

// ─── CUSTOM SOUNDS ───────────────────────────────────────────────────────────
@Composable
fun CustomSoundsScreen(navController: NavController) {
    val scope = rememberCoroutineScope()
    val tapEnabled    by AppPreferences.get(AppPreferences.TAP_SOUND_ENABLED, false).collectAsState(false)
    val lockEnabled   by AppPreferences.get(AppPreferences.LOCK_SOUND_ENABLED, false).collectAsState(false)
    val unlockEnabled by AppPreferences.get(AppPreferences.UNLOCK_SOUND_ENABLED, false).collectAsState(false)
    val chargeEnabled by AppPreferences.get(AppPreferences.CHARGING_SOUND_ENABLED, false).collectAsState(false)
    val tapUri    by AppPreferences.get(AppPreferences.TAP_SOUND_URI, "").collectAsState("")
    val lockUri   by AppPreferences.get(AppPreferences.LOCK_SOUND_URI, "").collectAsState("")
    val unlockUri by AppPreferences.get(AppPreferences.UNLOCK_SOUND_URI, "").collectAsState("")
    val chargeUri by AppPreferences.get(AppPreferences.CHARGING_SOUND_URI, "").collectAsState("")
    var pickingFor by remember { mutableStateOf("") }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.toString()?.let { uriStr ->
            scope.launch {
                when (pickingFor) {
                    "tap"    -> AppPreferences.set(AppPreferences.TAP_SOUND_URI, uriStr)
                    "lock"   -> AppPreferences.set(AppPreferences.LOCK_SOUND_URI, uriStr)
                    "unlock" -> AppPreferences.set(AppPreferences.UNLOCK_SOUND_URI, uriStr)
                    "charge" -> AppPreferences.set(AppPreferences.CHARGING_SOUND_URI, uriStr)
                }
            }
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Custom Sounds", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("🔊 Custom Sounds", style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Assign custom audio files to tap, lock, unlock and charging events.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }

            // Helper composable for sound rows
            @Composable
            fun SoundCard(
                sectionTitle: String,
                toggleLabel: String,
                toggleSub: String,
                enabled: Boolean,
                onToggle: (Boolean) -> Unit,
                fileUri: String,
                onBrowse: () -> Unit,
                iconEmoji: String
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(iconEmoji + "  " + sectionTitle, style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp, top = 8.dp))
                    Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        elevation = CardDefaults.cardElevation(0.dp)) {
                        Column {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(toggleLabel, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                    Text(toggleSub, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = enabled, onCheckedChange = onToggle)
                            }
                            HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Sound File", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Text(
                                        if (fileUri.isEmpty()) "No file selected — tap Browse"
                                        else android.net.Uri.parse(fileUri).lastPathSegment ?: "File selected",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (fileUri.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                                                else MaterialTheme.colorScheme.primary,
                                        maxLines = 1
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                FilledTonalButton(onClick = onBrowse) {
                                    Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Browse")
                                }
                            }
                        }
                    }
                }
            }

            SoundCard("Tap Sound", "Custom Tap Sound", "Play sound on every screen tap",
                tapEnabled, { scope.launch { AppPreferences.set(AppPreferences.TAP_SOUND_ENABLED, it) } },
                tapUri, { pickingFor = "tap"; audioPicker.launch("audio/*") }, "👆")

            SoundCard("Lock Sound", "Screen Lock Sound", "Sound when screen locks",
                lockEnabled, { scope.launch { AppPreferences.set(AppPreferences.LOCK_SOUND_ENABLED, it) } },
                lockUri, { pickingFor = "lock"; audioPicker.launch("audio/*") }, "🔒")

            SoundCard("Unlock Sound", "Unlock Sound", "After PIN/biometric unlock",
                unlockEnabled, { scope.launch { AppPreferences.set(AppPreferences.UNLOCK_SOUND_ENABLED, it) } },
                unlockUri, { pickingFor = "unlock"; audioPicker.launch("audio/*") }, "🔓")

            SoundCard("Charging Sound", "Charging Connect Sound", "Plays when charger is plugged in",
                chargeEnabled, { scope.launch { AppPreferences.set(AppPreferences.CHARGING_SOUND_ENABLED, it) } },
                chargeUri, { pickingFor = "charge"; audioPicker.launch("audio/*") }, "⚡")

            Spacer(Modifier.height(8.dp))
            InfoCard(Icons.Default.Info, "How it works",
                "Tap/unlock sounds use the Accessibility Service. Lock/charge sounds use broadcast receivers. Unlock fires only after successful biometric or PIN auth.",
                isError = false)
        }
    }
}

// ─── NAVBAR OVERLAY ──────────────────────────────────────────────────────────
@Composable
fun NavBarOverlayScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val enabled        by AppPreferences.get(AppPreferences.NAVBAR_OVERLAY_ENABLED, false).collectAsState(false)
    val savedStyle     by AppPreferences.get(AppPreferences.NAVBAR_STYLE, "Minimal Pill").collectAsState("Minimal Pill")
    val savedPillColor by AppPreferences.get(AppPreferences.NAVBAR_PILL_COLOR, "#FFFFFF").collectAsState("#FFFFFF")
    val savedOpacity   by AppPreferences.get(AppPreferences.NAVBAR_PILL_OPACITY, 0.8f).collectAsState(0.8f)
    val savedHeight    by AppPreferences.get(AppPreferences.NAVBAR_HEIGHT, 48f).collectAsState(48f)
    val savedXPos      by AppPreferences.get(AppPreferences.NAVBAR_X_POSITION, 0f).collectAsState(0f)
    val savedYPos      by AppPreferences.get(AppPreferences.NAVBAR_Y_POSITION, 0f).collectAsState(0f)

    // Styles — Transparent and Frosted Glass removed; Blurred Pill added
    val styles = listOf(
        "Minimal Pill"        to "Small gesture pill at the bottom",
        "Blurred Pill"        to "Frosted blur effect behind the pill",
        "Colored"             to "Solid colored bar across full width",
        "Classic Buttons"     to "Back • Home • Recents buttons",
        "Gradient"            to "Fades out at the edges",
        "Neon Glow"           to "Glowing line effect",
        "Dot Indicators"      to "Three dots navigation style"
    )
    var selectedStyle by remember { mutableStateOf(0) }
    LaunchedEffect(savedStyle) { selectedStyle = styles.indexOfFirst { it.first == savedStyle }.takeIf { it >= 0 } ?: 0 }
    var opacity by remember { mutableFloatStateOf(0.8f) }
    LaunchedEffect(savedOpacity) { opacity = savedOpacity }
    var height  by remember { mutableFloatStateOf(48f) }
    LaunchedEffect(savedHeight) { height = savedHeight }
    var xPos    by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(savedXPos)  { xPos = savedXPos }
    var yPos    by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(savedYPos)  { yPos = savedYPos }
    var hasOverlay by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME)
                hasOverlay = PermissionManager.hasOverlayPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs); onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Custom Nav Bar", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {

            if (!hasOverlay) {
                InfoCard(Icons.Default.Layers, "Overlay Permission Required",
                    "Custom Nav Bar needs the Display Over Other Apps permission.",
                    isError = true, actionLabel = "Grant",
                    onAction = { PermissionManager.openOverlaySettings(context) })
            }

            // Enable toggle
            FeatureSection("Nav Bar Overlay") {
                ToggleSettingRow("Enable Nav Bar Overlay", "Draw a custom navigation bar overlay", enabled, {
                    scope.launch { AppPreferences.set(AppPreferences.NAVBAR_OVERLAY_ENABLED, it) }
                    if (it) NavBarOverlayService.start(context) else NavBarOverlayService.stop(context)
                })
            }

            // Style picker
            FeatureSection("Style") {
                styles.forEachIndexed { i, (style, desc) ->
                    ListItem(
                        headlineContent = { Text(style) },
                        supportingContent = { Text(desc, style = MaterialTheme.typography.bodySmall) },
                        leadingContent = {
                            RadioButton(selected = selectedStyle == i, onClick = {
                                selectedStyle = i
                                scope.launch { AppPreferences.set(AppPreferences.NAVBAR_STYLE, style) }
                                if (enabled) NavBarOverlayService.start(context)
                            })
                        }
                    )
                    if (i < styles.lastIndex) HorizontalDivider()
                }
            }

            // Color picker
            FeatureSection("Pill / Bar Color") {
                ColorPickerRow("Color", savedPillColor) {
                    scope.launch { AppPreferences.set(AppPreferences.NAVBAR_PILL_COLOR, it) }
                    if (enabled) NavBarOverlayService.start(context)
                }
            }

            // Size & opacity sliders
            FeatureSection("Size & Opacity") {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Opacity: ${(opacity * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = opacity, onValueChange = {
                        opacity = it; scope.launch { AppPreferences.set(AppPreferences.NAVBAR_PILL_OPACITY, it) }
                    }, valueRange = 0.1f..1f, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("Height: ${height.toInt()}dp", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = height, onValueChange = {
                        height = it; scope.launch { AppPreferences.set(AppPreferences.NAVBAR_HEIGHT, it) }
                    }, valueRange = 24f..120f, modifier = Modifier.fillMaxWidth())
                }
            }

            // X / Y position sliders
            FeatureSection("Position") {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("X Offset: ${xPos.toInt()}px  (← left  |  right →)",
                        style = MaterialTheme.typography.bodyMedium)
                    Slider(value = xPos, onValueChange = {
                        xPos = it; scope.launch { AppPreferences.set(AppPreferences.NAVBAR_X_POSITION, it) }
                        if (enabled) NavBarOverlayService.start(context)
                    }, valueRange = -500f..500f, modifier = Modifier.fillMaxWidth())

                    Spacer(Modifier.height(4.dp))
                    Text("Y Offset: ${yPos.toInt()}px  (↑ up  |  down ↓)",
                        style = MaterialTheme.typography.bodyMedium)
                    Slider(value = yPos, onValueChange = {
                        yPos = it; scope.launch { AppPreferences.set(AppPreferences.NAVBAR_Y_POSITION, it) }
                        if (enabled) NavBarOverlayService.start(context)
                    }, valueRange = -300f..300f, modifier = Modifier.fillMaxWidth())

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        xPos = 0f; yPos = 0f
                        scope.launch {
                            AppPreferences.set(AppPreferences.NAVBAR_X_POSITION, 0f)
                            AppPreferences.set(AppPreferences.NAVBAR_Y_POSITION, 0f)
                        }
                        if (enabled) NavBarOverlayService.start(context)
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CenterFocusStrong, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Reset to Center")
                    }
                }
            }
        }
    }
}

// ─── SCREENSHOT BLOCKER ──────────────────────────────────────────────────────
@Composable
fun ScreenshotBlockerScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.SCREENSHOT_BLOCK_ENABLED, false).collectAsState(false)
    var hasOverlay by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasOverlay = PermissionManager.hasOverlayPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs); onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // Apply FLAG_SECURE globally via the activity — covers the entire app
    LaunchedEffect(enabled) {
        val activity = context as? Activity
        if (activity != null) {
            if (enabled) {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Screenshot Blocker", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            FeatureSection("Screenshot Protection") {
                ToggleSettingRow(
                    "Block Screenshots in This App",
                    "Prevents screenshots & screen recording system-wide via FLAG_SECURE",
                    enabled,
                    { scope.launch { AppPreferences.set(AppPreferences.SCREENSHOT_BLOCK_ENABLED, it) } }
                )
            }
            FeatureSection("How It Works") {
                Column(Modifier.padding(16.dp)) {
                    Text("FLAG_SECURE is applied to the activity window when enabled. This blocks screenshots in all currently-visible activities. The overlay permission extends protection to any overlay windows drawn on top.", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (!hasOverlay) {
                InfoCard(Icons.Default.Info, "Optional: Overlay Permission",
                    "Grant 'Display over other apps' to extend screenshot blocking to overlay windows too.",
                    isError = false, actionLabel = "Grant",
                    onAction = { PermissionManager.openOverlaySettings(context) })
            }
        }
    }
}

// ─── VOLUME STYLES ───────────────────────────────────────────────────────────
@Composable
fun VolumeStylesScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val volumeStylesEnabled by AppPreferences.get(AppPreferences.VOLUME_STYLES_ENABLED, false).collectAsState(false)
    val savedStyle  by AppPreferences.get(AppPreferences.VOLUME_STYLE, "Default").collectAsState("Default")
    val savedColor  by AppPreferences.get(AppPreferences.VOLUME_COLOR, "#1C1C1E").collectAsState("#1C1C1E")
    val savedCorner by AppPreferences.get(AppPreferences.VOLUME_CORNER_RADIUS, 24f).collectAsState(24f)
    val savedOpacity by AppPreferences.get(AppPreferences.VOLUME_OPACITY, 0.92f).collectAsState(0.92f)
    val styles = listOf("Default", "Compact", "Pill", "Circular", "Minimal", "Expanded")
    var selected by remember { mutableStateOf(0) }
    LaunchedEffect(savedStyle) { selected = styles.indexOf(savedStyle).takeIf { it >= 0 } ?: 0 }
    var cornerRadius by remember { mutableFloatStateOf(24f) }
    LaunchedEffect(savedCorner) { cornerRadius = savedCorner }
    var opacity by remember { mutableFloatStateOf(0.92f) }
    LaunchedEffect(savedOpacity) { opacity = savedOpacity }

    var hasOverlay by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    var accessibilityEnabled by remember { mutableStateOf(PermissionManager.isAccessibilityEnabled(context)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasOverlay = PermissionManager.hasOverlayPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs); onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Volume Styles", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!hasOverlay || !accessibilityEnabled) {
                Card(
                    Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚠️ Permissions Needed for Custom Volume Panel",
                            style = MaterialTheme.typography.titleSmall)
                        if (!hasOverlay) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("• Display Over Other Apps", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                Button(onClick = { PermissionManager.openOverlaySettings(context) }) { Text("Grant") }
                            }
                        }
                        if (!accessibilityEnabled) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("• Accessibility Service (intercept volume keys)", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                Button(onClick = { PermissionManager.openAccessibilitySettings(context) }) { Text("Enable") }
                            }
                        }
                    }
                }
            }
            FeatureSection("Volume Panel Override") {
                ToggleSettingRow("Enable Custom Volume Styles", "Override Android's default volume panel", volumeStylesEnabled,
                    { scope.launch { AppPreferences.set(AppPreferences.VOLUME_STYLES_ENABLED, it) } })
                HorizontalDivider()
            }
            FeatureSection("Style") {
                styles.forEachIndexed { i, style ->
                    ListItem(
                        headlineContent = { Text(style) },
                        supportingContent = { Text(when (style) {
                            "Default"  -> "Uses Android's built-in volume panel"
                            "Compact"  -> "Slim vertical bar on the right edge"
                            "Pill"     -> "Rounded pill with smooth fill animation"
                            "Circular" -> "Compact circular indicator"
                            "Minimal"  -> "Ultra-minimal bar, icon only"
                            "Expanded" -> "Full-width bar with seek slider"
                            else -> ""
                        }) },
                        leadingContent = { RadioButton(selected = selected == i, onClick = {
                            selected = i
                            scope.launch { AppPreferences.set(AppPreferences.VOLUME_STYLE, style) }
                        }) }
                    )
                    if (i < styles.lastIndex) HorizontalDivider()
                }
            }
            FeatureSection("Appearance") {
                ColorPickerRow("Panel Background Color", savedColor) { scope.launch { AppPreferences.set(AppPreferences.VOLUME_COLOR, it) } }
                HorizontalDivider()
                Column(Modifier.padding(16.dp)) {
                    Text("Corner Radius: ${cornerRadius.toInt()}dp", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = cornerRadius, onValueChange = {
                        cornerRadius = it; scope.launch { AppPreferences.set(AppPreferences.VOLUME_CORNER_RADIUS, it) }
                    }, valueRange = 0f..64f, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    // Visible opacity label + colored track so it's always visible
                    Text("Opacity: ${(opacity * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Slider(
                        value = opacity,
                        onValueChange = { opacity = it; scope.launch { AppPreferences.set(AppPreferences.VOLUME_OPACITY, it) } },
                        valueRange = 0.2f..1f,
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    }
}

// ─── KEEP SCREEN ON ──────────────────────────────────────────────────────────
@Composable
fun KeepScreenOnScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.KEEP_SCREEN_ON_ENABLED, false).collectAsState(false)
    val canWriteSettings = Settings.System.canWrite(context)

    Scaffold(topBar = { EverlastingTopBar("Keep Screen On", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!canWriteSettings) {
                InfoCard(Icons.Default.Warning, "WRITE_SETTINGS Permission Required",
                    "Needed to control screen timeout",
                    isError = true, actionLabel = "Grant",
                    onAction = {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
            }
            FeatureSection("Screen Control") {
                ToggleSettingRow("Keep Screen On", "Prevent screen from turning off automatically", enabled, {
                    scope.launch { AppPreferences.set(AppPreferences.KEEP_SCREEN_ON_ENABLED, it) }
                    // Wake lock is managed by foreground service — no Settings.System needed
                })
            }
            InfoCard(Icons.Default.Lightbulb, "Quick Settings Tile",
                "Add 'Keep Screen On' to your Quick Settings panel. Swipe down → Edit tiles → drag it in.",
                isError = false)
        }
    }
}

// ─── DOUBLE TAP BACK ─────────────────────────────────────────────────────────
@Composable
fun DoubleTapBackScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled       by AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_ENABLED, false).collectAsState(false)
    val savedAction   by AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_ACTION, "torch").collectAsState("torch")
    val savedApp      by AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_APP, "").collectAsState("")
    val savedAppName  by AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_APP_NAME, "").collectAsState("")
    var selectedAction by remember { mutableStateOf("torch") }
    LaunchedEffect(savedAction) { selectedAction = savedAction }
    var accessibilityEnabled by remember { mutableStateOf(PermissionManager.isAccessibilityEnabled(context)) }

    val installedApps = remember {
        context.packageManager.getInstalledApplications(0)
            .filter { context.packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { context.packageManager.getApplicationLabel(it).toString() }
    }
    var showAppPicker by remember { mutableStateOf(false) }

    if (showAppPicker) {
        AlertDialog(onDismissRequest = { showAppPicker = false },
            title = { Text("Pick an App") },
            text = {
                Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                    installedApps.forEach { app ->
                        val label = context.packageManager.getApplicationLabel(app).toString()
                        ListItem(headlineContent = { Text(label) },
                            supportingContent = { Text(app.packageName, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.clickable {
                                scope.launch {
                                    AppPreferences.set(AppPreferences.DOUBLE_TAP_BACK_APP, app.packageName)
                                    AppPreferences.set(AppPreferences.DOUBLE_TAP_BACK_APP_NAME, label)
                                }
                                showAppPicker = false
                            })
                        HorizontalDivider()
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAppPicker = false }) { Text("Cancel") } }
        )
    }


    val lifecycleOwnerDoubleTapBackScreen = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwnerDoubleTapBackScreen) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                accessibilityEnabled = PermissionManager.isAccessibilityEnabled(context)
            }
        }
        lifecycleOwnerDoubleTapBackScreen.lifecycle.addObserver(obs)
        onDispose { lifecycleOwnerDoubleTapBackScreen.lifecycle.removeObserver(obs) }
    }
    Scaffold(topBar = { EverlastingTopBar("Double Tap Back", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            if (!accessibilityEnabled) {
                InfoCard(Icons.Default.Warning, "Accessibility Service Required",
                    "Double tap back uses the accessibility service to intercept back key events",
                    isError = true, actionLabel = "Enable",
                    onAction = { PermissionManager.openAccessibilitySettings(context) })
            }
            FeatureSection("Double Tap Back") {
                ToggleSettingRow("Enable Double Tap Back", "Double-tap the back button to trigger an action", enabled, {
                    if (!accessibilityEnabled) { PermissionManager.openAccessibilitySettings(context); return@ToggleSettingRow }
                    scope.launch { AppPreferences.set(AppPreferences.DOUBLE_TAP_BACK_ENABLED, it) }
                })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Toggle Flashlight") },
                    supportingContent = { Text("Quickly toggle the torch on/off") },
                    leadingContent = {
                        RadioButton(selected = selectedAction == "torch", onClick = {
                            selectedAction = "torch"
                            scope.launch { AppPreferences.set(AppPreferences.DOUBLE_TAP_BACK_ACTION, "torch") }
                        })
                    },
                    trailingContent = { Icon(Icons.Default.FlashOn, null) }
                )
                HorizontalDivider()
                ListItem(headlineContent = { Text("Launch App") },
                    supportingContent = { Text(if (savedAppName.isNotEmpty()) "App: $savedAppName" else "No app selected") },
                    leadingContent = {
                        RadioButton(selected = selectedAction == "app", onClick = {
                            selectedAction = "app"
                            scope.launch { AppPreferences.set(AppPreferences.DOUBLE_TAP_BACK_ACTION, "app") }
                            if (savedApp.isEmpty()) showAppPicker = true
                        })
                    },
                    trailingContent = {
                        if (selectedAction == "app") {
                            TextButton(onClick = { showAppPicker = true }) { Text("Choose App") }
                        }
                    }
                )
            }
        }
    }
}

// ─── HIDDEN FEATURES ─────────────────────────────────────────────────────────
@Composable
fun HiddenFeaturesScreen(navController: NavController) {
    val context = LocalContext.current
    data class HiddenFeature(val title: String, val subtitle: String, val apply: (Boolean) -> Unit)
    val features = listOf(
        HiddenFeature("Force Dark Mode", "Force dark mode on all apps") { on ->
            try { Settings.Global.putInt(context.contentResolver, "ui_night_mode", if (on) 2 else 1) } catch (_: Exception) {}
        },
        HiddenFeature("High Touch Sensitivity", "Enable for screen protectors") { on ->
            try { Settings.System.putInt(context.contentResolver, "touch_sensitivity", if (on) 1 else 0) } catch (_: Exception) {}
        },
        HiddenFeature("Show Tap Circles", "Visual circles on touch") { on ->
            try { Settings.System.putInt(context.contentResolver, "show_touches", if (on) 1 else 0) } catch (_: Exception) {}
        },
        HiddenFeature("Show Pointer Location", "Touch coordinate overlay") { on ->
            try { Settings.System.putInt(context.contentResolver, "pointer_location", if (on) 1 else 0) } catch (_: Exception) {}
        },
        HiddenFeature("Disable Screenshot Sound", "Silent screenshots") { on ->
            try { Settings.Global.putInt(context.contentResolver, "screenshot_shutter_sound", if (on) 0 else 1) } catch (_: Exception) {}
        },
        HiddenFeature("Force 60Hz (Battery Save)", "Lock refresh rate to 60Hz") { on ->
            try { Settings.System.putFloat(context.contentResolver, "min_refresh_rate", if (on) 60f else 0f) } catch (_: Exception) {}
        },
        HiddenFeature("Aggressive Doze", "More aggressive battery saving") { on ->
            try { Runtime.getRuntime().exec(arrayOf("sh", "-c", "settings put global device_idle_constants ${if (on) "light_after_inactive_to=15000,inactive_to=30000" else ""}")) } catch (_: Exception) {}
        },
        HiddenFeature("Disable Bluetooth Scanning", "Stop background BT scanning") { on ->
            try { Settings.Global.putInt(context.contentResolver, "ble_scan_always_enabled", if (on) 0 else 1) } catch (_: Exception) {}
        },
    )
    val states = remember { mutableStateListOf(*Array(features.size) { false }) }
    Scaffold(topBar = { EverlastingTopBar("Hidden Android Features", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            InfoCard(Icons.Default.Build, "Advanced Settings",
                "Some settings require WRITE_SETTINGS or ADB. Changes may be overridden by system.",
                isError = false)
            FeatureSection("Hidden Settings") {
                features.forEachIndexed { i, feature ->
                    ListItem(headlineContent = { Text(feature.title) },
                        supportingContent = { Text(feature.subtitle) },
                        trailingContent = { Switch(checked = states[i], onCheckedChange = { isOn -> states[i] = isOn; feature.apply(isOn) }) })
                    if (i < features.lastIndex) HorizontalDivider()
                }
            }
        }
    }
}

// ─── WALLPAPER EFFECTS ───────────────────────────────────────────────────────
@Composable
fun WallpaperEffectsScreen(navController: NavController) {
    val context = LocalContext.current
    val effects = listOf(
        "Pixel Depth Effect" to "3D parallax depth effect",
        "Dock Blur Wall" to "Blur wallpaper behind dock area",
        "Tint on Lock" to "Tint wallpaper when screen locks",
        "Dim on Notification" to "Dim wallpaper when notifications arrive",
        "Color Shift" to "Shift wallpaper colors with time of day",
        "Vignette Edge" to "Dark vignette around screen edges",
        "Blur Widgets Area" to "Blur behind widget zones"
    )
    val states = remember { mutableStateListOf(*Array(effects.size) { false }) }
    var intensity by remember { mutableFloatStateOf(0.5f) }
    Scaffold(topBar = { EverlastingTopBar("Wallpaper Effects", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            FeatureSection("Effect Intensity") {
                Column(Modifier.padding(16.dp)) {
                    Text("Intensity: ${(intensity * 100).toInt()}%", style = MaterialTheme.typography.bodyLarge)
                    Slider(value = intensity, onValueChange = { intensity = it }, modifier = Modifier.fillMaxWidth())
                }
            }
            FeatureSection("Effects") {
                effects.forEachIndexed { i, (name, desc) ->
                    ListItem(headlineContent = { Text(name) }, supportingContent = { Text(desc) },
                        trailingContent = { Switch(checked = states[i], onCheckedChange = { states[i] = it }) })
                    if (i < effects.lastIndex) HorizontalDivider()
                }
            }
            InfoCard(Icons.Default.Info, "Note",
                "Deeper effects like parallax and blur require a Live Wallpaper.", isError = false)
        }
    }
}
