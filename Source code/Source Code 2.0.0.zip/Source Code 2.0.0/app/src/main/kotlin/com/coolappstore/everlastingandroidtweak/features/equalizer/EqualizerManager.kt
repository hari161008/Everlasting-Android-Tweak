package com.coolappstore.everlastingandroidtweak.features.equalizer

import android.media.audiofx.Equalizer
import android.util.Log
import kotlinx.coroutines.*

object EqualizerManager {

    private const val TAG = "EqualizerManager"

    private var equalizer: Equalizer? = null
    private var isInitialized = false

    // Try multiple session IDs — session 0 fails on many devices
    private val SESSION_IDS_TO_TRY = listOf(0, 1, 2)

    /**
     * Call this before any other method. Returns true on success.
     * On Android 12+ (minSdk 31) session 0 is the global audio output mix.
     * If that fails we fall back to trying active sessions.
     */
    fun init(): Boolean {
        release()
        for (sessionId in SESSION_IDS_TO_TRY) {
            try {
                val eq = Equalizer(0, sessionId)
                // Verify it actually works by querying a property
                val bands = eq.numberOfBands
                if (bands <= 0) { eq.release(); continue }
                eq.enabled = false
                equalizer = eq
                isInitialized = true
                Log.d(TAG, "Equalizer initialized on session $sessionId, bands=$bands")
                return true
            } catch (e: Exception) {
                Log.w(TAG, "Session $sessionId failed: ${e.message}")
            }
        }
        Log.e(TAG, "All session IDs failed — Equalizer unavailable on this device")
        isInitialized = false
        return false
    }

    fun setEnabled(enabled: Boolean): Boolean {
        if (!ensureInitialized()) return false
        return try {
            equalizer?.enabled = enabled
            true
        } catch (e: Exception) {
            Log.e(TAG, "setEnabled($enabled) failed: ${e.message}")
            // EQ died — try re-initialising
            if (init()) {
                try { equalizer?.enabled = enabled; true } catch (_: Exception) { false }
            } else false
        }
    }

    fun getEnabled(): Boolean = try { equalizer?.enabled ?: false } catch (_: Exception) { false }

    fun getNumberOfBands(): Short = try { equalizer?.numberOfBands ?: 5 } catch (_: Exception) { 5 }

    fun getBandLevelRange(): Pair<Short, Short> = try {
        val range = equalizer?.bandLevelRange ?: shortArrayOf(-1500, 1500)
        Pair(range[0], range[1])
    } catch (_: Exception) { Pair(-1500, 1500) }

    /**
     * Get band level in dB (-15 .. +15 typically).
     */
    fun getBandLevelDb(bandIndex: Short): Float =
        try { (equalizer?.getBandLevel(bandIndex) ?: 0) / 100f } catch (_: Exception) { 0f }

    /**
     * Set a single band. Temporarily disables EQ to avoid crackle.
     */
    fun setBandLevel(bandIndex: Short, levelDb: Float) {
        if (!ensureInitialized()) return
        try {
            val eq = equalizer ?: return
            val wasEnabled = eq.enabled
            if (wasEnabled) eq.enabled = false

            val levelMb = (levelDb * 100).toInt().toShort()
            val range = eq.bandLevelRange
            val clamped = levelMb.coerceIn(range[0], range[1])
            eq.setBandLevel(bandIndex, clamped)

            if (wasEnabled) eq.enabled = true
        } catch (e: Exception) {
            Log.e(TAG, "setBandLevel failed: ${e.message}")
        }
    }

    /**
     * Apply all bands in one shot — far less distortion than individual calls.
     */
    fun applyAllBands(levels: List<Float>) {
        if (!ensureInitialized()) return
        try {
            val eq = equalizer ?: return
            val wasEnabled = eq.enabled
            if (wasEnabled) eq.enabled = false           // Disable once

            val range = eq.bandLevelRange
            levels.forEachIndexed { i, levelDb ->
                val levelMb = (levelDb * 100).toInt().toShort().coerceIn(range[0], range[1])
                eq.setBandLevel(i.toShort(), levelMb)
            }

            if (wasEnabled) eq.enabled = true            // Re-enable once
        } catch (e: Exception) {
            Log.e(TAG, "applyAllBands failed: ${e.message}")
            // Re-init and retry once
            if (init()) applyAllBands(levels)
        }
    }

    fun applyFromString(levels: String) {
        val parsed = levels.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (parsed.isNotEmpty()) applyAllBands(parsed)
    }

    fun toBandLevelString(): String = try {
        val count = getNumberOfBands()
        (0 until count).joinToString(",") { getBandLevelDb(it.toShort()).toString() }
    } catch (_: Exception) { "0,0,0,0,0" }

    fun getCenterFreqHz(bandIndex: Short): Int =
        try { (equalizer?.getCenterFreq(bandIndex) ?: 0) / 1000 } catch (_: Exception) { 0 }

    fun release() {
        try {
            equalizer?.enabled = false
            equalizer?.release()
        } catch (_: Exception) {}
        equalizer = null
        isInitialized = false
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    private fun ensureInitialized(): Boolean {
        if (isInitialized && equalizer != null) return true
        return init()
    }
}
