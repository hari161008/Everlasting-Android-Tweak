package com.coolappstore.everlastingandroidtweak.services

import android.app.*
import android.content.*
import android.os.*
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.coolappstore.everlastingandroidtweak.EverlastingApp
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.features.camera.TwistCameraManager
import com.coolappstore.everlastingandroidtweak.features.charging.ChargingSoundManager
import com.coolappstore.everlastingandroidtweak.features.chargelimit.ChargeLimitManager
import com.coolappstore.everlastingandroidtweak.features.notiflight.NotifLightManager
import com.coolappstore.everlastingandroidtweak.features.flipdnd.FlipToDndManager
import com.coolappstore.everlastingandroidtweak.features.keepon.KeepScreenOnTileService
import com.coolappstore.everlastingandroidtweak.features.musiclight.MusicLightManager
import com.coolappstore.everlastingandroidtweak.features.musicleveler.MusicLevelerOverlayService
import com.coolappstore.everlastingandroidtweak.features.securitymotion.SecurityMotionManager
import com.coolappstore.everlastingandroidtweak.features.torch.ShakeTorchManager
import com.coolappstore.everlastingandroidtweak.features.volumebooster.VolumeBoosterManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

// ─── FOREGROUND SERVICE ─────────────────────────────────────────────────────
class EverlastingForegroundService : Service() {

    private lateinit var shakeTorchManager: ShakeTorchManager
    private lateinit var twistCameraManager: TwistCameraManager
    private lateinit var musicLightManager: MusicLightManager
    private lateinit var chargingSoundManager: ChargingSoundManager
    private lateinit var flipToDndManager: FlipToDndManager
    private lateinit var volumeBoosterManager: VolumeBoosterManager
    private lateinit var securityMotionManager: SecurityMotionManager
    private lateinit var chargeLimitManager: ChargeLimitManager

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        shakeTorchManager    = ShakeTorchManager(this)
        twistCameraManager   = TwistCameraManager(this)
        musicLightManager    = MusicLightManager(this)
        chargingSoundManager = ChargingSoundManager(this)
        flipToDndManager     = FlipToDndManager(this)
        volumeBoosterManager = VolumeBoosterManager(this)
        securityMotionManager = SecurityMotionManager(this)
        chargeLimitManager = ChargeLimitManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        observePreferences()
        return START_STICKY
    }

    private fun observePreferences() {
        // Shake torch
        scope.launch { AppPreferences.get(AppPreferences.SHAKE_TORCH_ENABLED, false).collect { if (it) shakeTorchManager.start() else shakeTorchManager.stop() } }
        scope.launch { AppPreferences.get(AppPreferences.SHAKE_SENSITIVITY, 12f).collect { shakeTorchManager.setSensitivity(it) } }
        scope.launch { AppPreferences.get(AppPreferences.SHAKE_PROXIMITY_ENABLED, false).collect { shakeTorchManager.setProximityEnabled(it) } }

        // Twist camera
        scope.launch { AppPreferences.get(AppPreferences.TWIST_CAMERA_ENABLED, false).collect { if (it) twistCameraManager.start() else twistCameraManager.stop() } }
        scope.launch { AppPreferences.get(AppPreferences.TWIST_SENSITIVITY, 3.5f).collect { twistCameraManager.setSensitivity(it) } }
        scope.launch { AppPreferences.get(AppPreferences.TWIST_PROXIMITY_ENABLED, false).collect { twistCameraManager.setProximityEnabled(it) } }

        // Music reactive light
        scope.launch {
            AppPreferences.get(AppPreferences.MUSIC_LIGHT_ENABLED, false).collect { lightEnabled ->
                val vibrateEnabled = AppPreferences.get(AppPreferences.MUSIC_VIBRATE_ENABLED, false).first()
                if (lightEnabled || vibrateEnabled) {
                    musicLightManager.lightEnabled     = lightEnabled
                    musicLightManager.vibrationEnabled = vibrateEnabled
                    musicLightManager.start()
                } else musicLightManager.stop()
            }
        }
        scope.launch { AppPreferences.get(AppPreferences.MUSIC_VIBRATE_ENABLED, false).collect { musicLightManager.vibrationEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.MUSIC_LIGHT_SENSITIVITY, 0.35f).collect { musicLightManager.sensitivity = it } }
        scope.launch { AppPreferences.get(AppPreferences.MUSIC_BLINK_SPEED, 1.0f).collect { musicLightManager.blinkSpeed = it } }
        scope.launch { AppPreferences.get(AppPreferences.MUSIC_SPEED_SENSITIVITY, 1.0f).collect { musicLightManager.blinkSpeed = it } }
        scope.launch { AppPreferences.get(AppPreferences.MUSIC_VIBRATION_INTENSITY, 160).collect { musicLightManager.vibrationIntensity = it } }

        // Keep screen on
        scope.launch {
            AppPreferences.get(AppPreferences.KEEP_SCREEN_ON_ENABLED, false).collect { enabled ->
                if (enabled) KeepScreenOnTileService.acquireWakeLock(applicationContext)
                else         KeepScreenOnTileService.releaseWakeLock()
            }
        }

        // Charging sound
        scope.launch {
            AppPreferences.get(AppPreferences.CHARGING_SOUND_ENABLED, false).collect { enabled ->
                if (enabled) chargingSoundManager.start() else chargingSoundManager.stop()
            }
        }

        // Flip to DND
        scope.launch {
            AppPreferences.get(AppPreferences.FLIP_DND_ENABLED, false).collect { enabled ->
                if (enabled) flipToDndManager.start() else flipToDndManager.stop()
            }
        }

        // Volume booster
        scope.launch {
            AppPreferences.get(AppPreferences.VOLUME_BOOST_ENABLED, false).collect { enabled ->
                val level = AppPreferences.get(AppPreferences.VOLUME_BOOST_LEVEL, 300).first()
                volumeBoosterManager.setBoost(enabled, level)
            }
        }
        scope.launch {
            AppPreferences.get(AppPreferences.VOLUME_BOOST_LEVEL, 300).collect { level ->
                val enabled = AppPreferences.get(AppPreferences.VOLUME_BOOST_ENABLED, false).first()
                if (enabled) volumeBoosterManager.setBoost(true, level)
            }
        }

        // Security motion
        scope.launch {
            AppPreferences.get(AppPreferences.SECURITY_MOTION_ENABLED, false).collect { enabled ->
                if (enabled) {
                    val sens = AppPreferences.get(AppPreferences.SECURITY_MOTION_SENSITIVITY, 0.5f).first()
                    securityMotionManager.sensitivity = sens
                    securityMotionManager.onMotionDetected = {
                        val nm = getSystemService(NotificationManager::class.java)
                        nm?.notify(SECURITY_NOTIF_ID,
                            NotificationCompat.Builder(applicationContext, EverlastingApp.CHANNEL_ALERTS)
                                .setContentTitle("⚠️ Motion Detected!")
                                .setContentText("Device was moved or tampered with.")
                                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                .setAutoCancel(true)
                                .build()
                        )
                    }
                    securityMotionManager.start()
                } else {
                    securityMotionManager.stop()
        chargeLimitManager.stop()
                }
            }
        }

        // Charge limit alarm
        scope.launch {
            AppPreferences.get(AppPreferences.CHARGE_LIMIT_ENABLED, false).collect { enabled ->
                if (enabled) chargeLimitManager.start() else chargeLimitManager.stop()
            }
        }

        // Music leveler overlay — restart when pref changes
        scope.launch {
            AppPreferences.get(AppPreferences.MUSIC_LEVELER_ENABLED, false).collect { enabled ->
                if (enabled) MusicLevelerOverlayService.start(applicationContext)
                else         MusicLevelerOverlayService.stop(applicationContext) // sends ACTION_STOP
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        shakeTorchManager.stop()
        twistCameraManager.stop()
        musicLightManager.stop()
        chargingSoundManager.stop()
        flipToDndManager.stop()
        volumeBoosterManager.release()
        securityMotionManager.stop()
        chargeLimitManager.stop()
        KeepScreenOnTileService.releaseWakeLock()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, EverlastingApp.CHANNEL_FOREGROUND)
            .setContentTitle("Everlasting Tweak Active")
            .setContentText("Gesture & feature monitoring running")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()

    companion object {
        private const val NOTIF_ID = 1001
        private const val SECURITY_NOTIF_ID = 1002

        fun start(context: Context) {
            val intent = Intent(context, EverlastingForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, EverlastingForegroundService::class.java))
        }
    }
}

// ─── NOTIFICATION LISTENER ──────────────────────────────────────────────────
class EverlastingNotificationListener : NotificationListenerService() {
    private var notifLightManager: NotifLightManager? = null
    override fun onCreate() { super.onCreate(); notifLightManager = NotifLightManager(this) }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        notifLightManager?.onNotificationPosted(sbn)
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification) {}
    override fun onDestroy() { super.onDestroy(); notifLightManager?.release() }
}

// ─── BOOT RECEIVER ──────────────────────────────────────────────────────────
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            EverlastingForegroundService.start(context)
        }
    }
}
