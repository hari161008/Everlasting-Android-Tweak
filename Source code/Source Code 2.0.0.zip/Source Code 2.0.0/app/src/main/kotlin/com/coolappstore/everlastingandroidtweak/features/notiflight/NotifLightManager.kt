package com.coolappstore.everlastingandroidtweak.features.notiflight

import android.content.Context
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import android.service.notification.StatusBarNotification
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Handles both features:
 * 1. Flashlight pulse on incoming notification
 * 2. Edge lighting overlay (drawn as a window overlay around screen edges)
 */
class NotifLightManager(private val context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var torchCameraId: String? = null

    init {
        torchCameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    }

    fun onNotificationPosted(sbn: StatusBarNotification) {
        scope.launch {
            val flashEnabled = AppPreferences.get(AppPreferences.FLASH_NOTIF_ENABLED, false).first()
            if (flashEnabled) pulseFlashlight()
        }
    }

    private fun pulseFlashlight() {
        val id = torchCameraId ?: return
        // 3 quick flashes
        val pattern = listOf(0L, 120L, 80L, 120L, 80L, 120L)
        var delay = 0L
        var torchState = false
        pattern.forEachIndexed { idx, duration ->
            if (idx > 0) {
                torchState = !torchState
                handler.postDelayed({
                    try { cameraManager.setTorchMode(id, torchState) } catch (_: Exception) {}
                }, delay)
            }
            delay += duration
        }
        // Ensure torch is off at end
        handler.postDelayed({
            try { cameraManager.setTorchMode(id, false) } catch (_: Exception) {}
        }, delay + 50)
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        try { torchCameraId?.let { cameraManager.setTorchMode(it, false) } } catch (_: Exception) {}
    }
}
