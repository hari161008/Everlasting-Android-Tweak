package com.coolappstore.everlastingandroidtweak.features.camera

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.VibratorManager
import kotlin.math.abs

class TwistCameraManager(private val context: Context) : SensorEventListener {

    private val sensorManager  = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroscope       = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private val vibrator = (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    private val handler = Handler(Looper.getMainLooper())

    private var lastTwistTime = 0L
    private var twistCount = 0
    private var isRunning = false
    private var _proximityEnabled = false
    private var proximityRegistered = false
    private var proximityOpen = false
    private var sensitivity = 3.5f

    private val TWIST_WINDOW_MS = 700L
    private val REQUIRED_TWISTS = 2

    private val proximityListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_PROXIMITY)
                proximityOpen = event.values[0] >= event.sensor.maximumRange
        }
        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    }

    private fun checkProximityThenCamera() {
        if (!_proximityEnabled || proximitySensor == null) { triggerCamera(); return }
        proximityOpen = false
        sensorManager.registerListener(proximityListener, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
        proximityRegistered = true
        handler.postDelayed({
            if (proximityRegistered) { sensorManager.unregisterListener(proximityListener); proximityRegistered = false }
            if (proximityOpen) triggerCamera()
            proximityOpen = false
        }, 200L)
    }

    fun setSensitivity(value: Float) { sensitivity = value }
    fun setProximityEnabled(enabled: Boolean) { _proximityEnabled = enabled }

    fun start() {
        if (isRunning) return
        gyroscope?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME); isRunning = true }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        if (proximityRegistered) { sensorManager.unregisterListener(proximityListener); proximityRegistered = false }
        handler.removeCallbacksAndMessages(null)
        isRunning = false; twistCount = 0
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_GYROSCOPE) return
        val rotZ = event.values[2]
        val now = System.currentTimeMillis()
        if (abs(rotZ) > sensitivity) {
            if (now - lastTwistTime > TWIST_WINDOW_MS) twistCount = 1 else twistCount++
            lastTwistTime = now
            // Vibrate on each detected twist
            runCatching {
                vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            }
            if (twistCount >= REQUIRED_TWISTS) { twistCount = 0; checkProximityThenCamera() }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}

    private fun triggerCamera() {
        // Strong vibration when camera opens
        runCatching {
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 60, 80, 120), -1))
        }
        try {
            context.startActivity(Intent("android.media.action.STILL_IMAGE_CAMERA")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { e.printStackTrace() }
    }
}
