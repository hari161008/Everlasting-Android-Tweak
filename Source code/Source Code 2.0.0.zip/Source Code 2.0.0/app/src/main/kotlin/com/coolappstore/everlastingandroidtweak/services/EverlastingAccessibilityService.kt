package com.coolappstore.everlastingandroidtweak.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.*
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class EverlastingAccessibilityService : AccessibilityService() {

    private val vibrator: Vibrator by lazy {
        (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    }
    private val cameraManager by lazy { getSystemService(CAMERA_SERVICE) as CameraManager }
    private val audioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    private var soundPool: SoundPool? = null
    private var tapSoundId: Int = 0
    private var tapSoundLoaded: Boolean = false

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val mainScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var hapticsEnabled         = false
    private var hapticsScrollEnabled   = false
    private var hapticsTapIntensity    = 150
    private var hapticsScrollIntensity = 80
    private var hapticsPattern         = "Click"
    private var tapSoundEnabled        = false
    private var tapSoundUri            = ""
    private var keepScreenOn           = false
    private var doubleTapBackEnabled   = false
    private var doubleTapBackAction    = "torch"
    private var doubleTapBackApp       = ""
    private var lockSoundEnabled       = false
    private var unlockSoundEnabled     = false
    private var lockSoundUri           = ""
    private var unlockSoundUri         = ""
    private var torchOn                = false

    private var lastBackTime = 0L
    private val DOUBLE_TAP_WINDOW_MS = 400L
    private var backDelayJob: Job? = null

    // ── Screen on/off receiver ─────────────────────────────────────────────
    // ACTION_USER_PRESENT fires ONLY after successful authentication (PIN/biometric),
    // not on plain screen-on. This is the correct trigger for "unlock sound".
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF  -> if (lockSoundEnabled)   playLockSound(lockSoundUri)
                Intent.ACTION_USER_PRESENT -> if (unlockSoundEnabled) playLockSound(unlockSoundUri)
            }
        }
    }

    override fun onServiceConnected() {
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            notificationTimeout = 50
        }

        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        soundPool?.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0 && sampleId == tapSoundId) tapSoundLoaded = true
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)  // fires only after successful unlock/auth
        }
        registerReceiver(screenReceiver, filter)
        observePreferences()
    }

    private fun observePreferences() {
        scope.launch { AppPreferences.get(AppPreferences.CUSTOM_HAPTICS_ENABLED, false).collect { hapticsEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_SCROLL_ENABLED, false).collect { hapticsScrollEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_TAP_INTENSITY, 150).collect { hapticsTapIntensity = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_SCROLL_INTENSITY, 80).collect { hapticsScrollIntensity = it } }
        scope.launch { AppPreferences.get(AppPreferences.HAPTICS_PATTERN, "Click").collect { hapticsPattern = it } }
        scope.launch { AppPreferences.get(AppPreferences.TAP_SOUND_ENABLED, false).collect { tapSoundEnabled = it } }
        scope.launch {
            AppPreferences.get(AppPreferences.TAP_SOUND_URI, "").collect { uri ->
                tapSoundUri = uri
                mainScope.launch { reloadTapSound(uri) }
            }
        }
        scope.launch { AppPreferences.get(AppPreferences.LOCK_SOUND_ENABLED, false).collect { lockSoundEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.UNLOCK_SOUND_ENABLED, false).collect { unlockSoundEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.LOCK_SOUND_URI, "").collect { lockSoundUri = it } }
        scope.launch { AppPreferences.get(AppPreferences.UNLOCK_SOUND_URI, "").collect { unlockSoundUri = it } }
        scope.launch { AppPreferences.get(AppPreferences.KEEP_SCREEN_ON_ENABLED, false).collect { keepScreenOn = it } }
        scope.launch { AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_ENABLED, false).collect { doubleTapBackEnabled = it } }
        scope.launch { AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_ACTION, "torch").collect { doubleTapBackAction = it } }
        scope.launch { AppPreferences.get(AppPreferences.DOUBLE_TAP_BACK_APP, "").collect { doubleTapBackApp = it } }
    }

    // ─── Double-tap back ──────────────────────────────────────────────────

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!doubleTapBackEnabled) return false
        if (event.keyCode != KeyEvent.KEYCODE_BACK) return false

        if (event.action == KeyEvent.ACTION_UP) {
            val now = System.currentTimeMillis()
            if (now - lastBackTime < DOUBLE_TAP_WINDOW_MS) {
                lastBackTime = 0L
                backDelayJob?.cancel()
                backDelayJob = null
                handleDoubleTapBack()
                return true
            }

            lastBackTime = now
            backDelayJob?.cancel()
            backDelayJob = mainScope.launch {
                delay(DOUBLE_TAP_WINDOW_MS)
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            return true
        }
        return false
    }

    private fun handleDoubleTapBack() {
        vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
        when (doubleTapBackAction) {
            "torch"     -> toggleTorch()
            "app"       -> launchApp(doubleTapBackApp)
            "home"      -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents"   -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    private fun toggleTorch() {
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cameraManager.setTorchMode(cameraId, torchOn)
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun launchApp(packageName: String) {
        if (packageName.isBlank()) return
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } ?: return
            startActivity(intent)
        } catch (e: Exception) { e.printStackTrace() }
    }

    // ─── Accessibility events ─────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                if (hapticsEnabled) performTapHaptic()
                if (tapSoundEnabled && tapSoundLoaded && tapSoundId != 0) {
                    soundPool?.play(tapSoundId, 1f, 1f, 1, 0, 1f)
                }
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (hapticsScrollEnabled) performScrollHaptic()
            }
            else -> {}
        }
    }

    // ─── Haptics ──────────────────────────────────────────────────────────

    private fun performTapHaptic() {
        val amp = hapticsTapIntensity.coerceIn(1, 255)
        val effect = when (hapticsPattern) {
            "Tick"         -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
            "Heavy Click"  -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK)
            "Double Click" -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK)
            "Soft"         -> VibrationEffect.createOneShot(8, (amp * 0.4f).toInt().coerceIn(1, 255))
            "Custom"       -> VibrationEffect.createOneShot(20, amp)
            else           -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
        }
        vibrator.vibrate(effect)
    }

    private fun performScrollHaptic() {
        val amp = hapticsScrollIntensity.coerceIn(1, 255)
        vibrator.vibrate(VibrationEffect.createOneShot(6, amp))
    }

    // ─── Sound ────────────────────────────────────────────────────────────

    private fun reloadTapSound(uri: String) {
        if (uri.isBlank()) { tapSoundId = 0; tapSoundLoaded = false; return }
        tapSoundLoaded = false
        tapSoundId = 0
        try {
            val parsedUri = Uri.parse(uri)
            val sp = soundPool ?: return
            tapSoundId = if (parsedUri.scheme == "content") {
                val afd = contentResolver.openAssetFileDescriptor(parsedUri, "r") ?: return
                sp.load(afd.fileDescriptor, afd.startOffset, afd.length, 1).also { afd.close() }
            } else {
                sp.load(parsedUri.path, 1)
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun playLockSound(uri: String) {
        if (uri.isBlank()) return
        mainScope.launch {
            try {
                val parsedUri = Uri.parse(uri)
                val vol = (audioManager.getStreamVolume(AudioManager.STREAM_RING)
                    .toFloat() / audioManager.getStreamMaxVolume(AudioManager.STREAM_RING)).coerceIn(0f, 1f)
                MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    if (parsedUri.scheme == "content")
                        setDataSource(applicationContext, parsedUri)
                    else
                        setDataSource(uri)
                    setVolume(vol, vol)
                    prepare()
                    setOnCompletionListener { release() }
                    start()
                }
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    fun playSound(uri: String) = playLockSound(uri)

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        scope.cancel()
        mainScope.cancel()
        soundPool?.release()
        soundPool = null
    }
}
