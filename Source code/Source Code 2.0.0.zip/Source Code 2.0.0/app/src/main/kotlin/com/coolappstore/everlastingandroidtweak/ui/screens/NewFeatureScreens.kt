package com.coolappstore.everlastingandroidtweak.ui.screens

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.VibratorManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.features.musicleveler.MusicLevelerOverlayService
import com.coolappstore.everlastingandroidtweak.features.navbar.NavBarOverlayService
import com.coolappstore.everlastingandroidtweak.ui.components.*
import com.coolappstore.everlastingandroidtweak.utils.PermissionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import kotlin.math.*
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Contacts

// ─── FLIP TO DND ─────────────────────────────────────────────────────────────
@Composable
fun FlipToDndScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.FLIP_DND_ENABLED, false).collectAsState(false)
    val nm = context.getSystemService(android.app.NotificationManager::class.java)
    val hasDnd = nm?.isNotificationPolicyAccessGranted == true

    Scaffold(topBar = { EverlastingTopBar("Flip to DND", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("📵 Flip to Silence", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Place your phone face-down to automatically activate Do Not Disturb. Flip it back to restore normal mode.", style = MaterialTheme.typography.bodySmall)
                }
            }

            if (!hasDnd) {
                InfoCard(Icons.Default.Warning, "Do Not Disturb Access Required",
                    "Tap Grant to allow this app to manage DND mode.",
                    isError = true, actionLabel = "Grant",
                    onAction = {
                        context.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
            }

            FeatureSection("Flip to DND") {
                ToggleSettingRow("Enable Flip to DND", "Flip face-down → DND on, flip back → DND off", enabled, {
                    if (!hasDnd) return@ToggleSettingRow
                    scope.launch { AppPreferences.set(AppPreferences.FLIP_DND_ENABLED, it) }
                })
            }

            FeatureSection("How it Works") {
                Column(Modifier.padding(16.dp)) {
                    Text("The accelerometer detects when the Z-axis reads below -7 m/s² (face-down). DND is activated immediately. When you flip the phone back up, DND is disabled automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ─── CHARGING SOUND ──────────────────────────────────────────────────────────
@Composable
fun ChargingSoundScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.CHARGING_SOUND_ENABLED, false).collectAsState(false)
    val soundUri by AppPreferences.get(AppPreferences.CHARGING_SOUND_URI, "").collectAsState("")
    var pickingSound by remember { mutableStateOf(false) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.toString()?.let { scope.launch { AppPreferences.set(AppPreferences.CHARGING_SOUND_URI, it) } }
    }

    Scaffold(topBar = { EverlastingTopBar("Charging Sound", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("🔋 Custom Charging Sound", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Play a custom audio file whenever your phone is plugged in to charge.", style = MaterialTheme.typography.bodySmall)
                }
            }
            FeatureSection("Charging Sound") {
                ToggleSettingRow("Enable Charging Sound", "Play sound when charger is connected", enabled,
                    { scope.launch { AppPreferences.set(AppPreferences.CHARGING_SOUND_ENABLED, it) } })
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text("Sound File") },
                    supportingContent = {
                        Text(if (soundUri.isEmpty()) "No file selected — tap Browse to pick audio"
                             else Uri.parse(soundUri).lastPathSegment ?: "File selected")
                    },
                    trailingContent = {
                        TextButton(onClick = { audioPicker.launch("audio/*") }) { Text("Browse") }
                    }
                )
            }
            OutlinedButton(onClick = {
                scope.launch {
                    val uri = if (soundUri.isNotEmpty()) android.net.Uri.parse(soundUri)
                              else return@launch
                    try {
                        val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        val vol = am.getStreamVolume(android.media.AudioManager.STREAM_NOTIFICATION).toFloat() / am.getStreamMaxVolume(android.media.AudioManager.STREAM_NOTIFICATION)
                        android.media.MediaPlayer().apply {
                            setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).build())
                            setDataSource(context, uri); setVolume(vol, vol); prepare()
                            setOnCompletionListener { release() }; start()
                        }
                    } catch (_: Exception) {}
                }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
               enabled = soundUri.isNotEmpty()) {
                Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Preview Charging Sound")
            }
            InfoCard(Icons.Default.Info, "System Volume",
                "The charging sound plays at your current notification volume level.", isError = false)
        }
    }
}

// ─── VOLUME BOOSTER ──────────────────────────────────────────────────────────
@Composable
fun VolumeBoosterScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by AppPreferences.get(AppPreferences.VOLUME_BOOST_ENABLED, false).collectAsState(false)
    val level by AppPreferences.get(AppPreferences.VOLUME_BOOST_LEVEL, 300).collectAsState(300)
    var sliderVal by remember { mutableFloatStateOf(300f) }
    LaunchedEffect(level) { sliderVal = level.toFloat() }

    Scaffold(topBar = { EverlastingTopBar("Volume Booster", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("🔊 Volume Booster", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Uses Android's LoudnessEnhancer audio effect to amplify media output beyond the system maximum.", style = MaterialTheme.typography.bodySmall)
                }
            }
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Enable Volume Boost", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Pushes volume to max + amplifies further", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = enabled, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.VOLUME_BOOST_ENABLED, it) }
                        })
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    Column(Modifier.padding(16.dp)) {
                        val dB = (sliderVal / 100).toInt()
                        val label = when {
                            dB == 0    -> "No boost (0 dB)"
                            dB <= 3    -> "Subtle (+${dB} dB)"
                            dB <= 6    -> "Noticeable (+${dB} dB)"
                            dB <= 10   -> "Strong (+${dB} dB) ⚠️"
                            else       -> "EXTREME (+${dB} dB) 🔊"
                        }
                        Text("Boost Level: $label", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Slider(
                            value = sliderVal,
                            onValueChange = { sliderVal = it
                                scope.launch { AppPreferences.set(AppPreferences.VOLUME_BOOST_LEVEL, it.toInt()) }
                            },
                            valueRange = 0f..15000f,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("None", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Max (+1500 dB)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            InfoCard(Icons.Default.Warning, "Speaker Safety Warning",
                "Extremely high boost levels can permanently damage speakers and earphones. Increase gradually and test at low volumes first.", isError = true)
        }
    }
}

// ─── MUSIC LEVELER ───────────────────────────────────────────────────────────
@Composable
fun MusicLevelerScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled   by AppPreferences.get(AppPreferences.MUSIC_LEVELER_ENABLED, false).collectAsState(false)
    val colorHex  by AppPreferences.get(AppPreferences.MUSIC_LEVELER_COLOR, "#8BCAFF").collectAsState("#8BCAFF")
    val position  by AppPreferences.get(AppPreferences.MUSIC_LEVELER_POSITION, "Bottom").collectAsState("Bottom")
    val autoHide  by AppPreferences.get(AppPreferences.MUSIC_LEVELER_AUTO_HIDE, true).collectAsState(true)
    val savedH    by AppPreferences.get(AppPreferences.MUSIC_LEVELER_HEIGHT, 56f).collectAsState(56f)
    val savedOp   by AppPreferences.get(AppPreferences.MUSIC_LEVELER_OPACITY, 1f).collectAsState(1f)
    var barHeight by remember { mutableFloatStateOf(56f) }
    var opacity   by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(savedH)  { barHeight = savedH }
    LaunchedEffect(savedOp) { opacity = savedOp }

    var hasOverlay by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasOverlay = PermissionManager.hasOverlayPermission(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs); onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val presetColors = listOf(
        "#8BCAFF" to "Blue", "#FF5722" to "Red", "#4CAF50" to "Green",
        "#FFC107" to "Amber", "#9C27B0" to "Purple", "#00BCD4" to "Cyan",
        "#FF4081" to "Pink", "#FFFFFF" to "White", "#000000" to "Black",
        "#FF6F00" to "Orange", "#1DE9B6" to "Teal", "#FFD600" to "Gold"
    )

    Scaffold(topBar = { EverlastingTopBar("Music Leveler", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            // Header
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("🎵", style = MaterialTheme.typography.displaySmall)
                        Column {
                            Text("Music Leveler", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(if (enabled) "● ACTIVE — auto-hides when silent" else "Tap toggle to activate",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (enabled) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                        }
                    }
                }
            }

            if (!hasOverlay) {
                InfoCard(Icons.Default.Layers, "Overlay Permission Required",
                    "Display Over Other Apps must be granted first.",
                    isError = true, actionLabel = "Grant",
                    onAction = { PermissionManager.openOverlaySettings(context) })
            }

            // Control card
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column {
                    // Enable toggle
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Show Music Leveler", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Animated 32-bar equalizer overlay", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = enabled, onCheckedChange = {
                            if (!hasOverlay) { PermissionManager.openOverlaySettings(context); return@Switch }
                            scope.launch { AppPreferences.set(AppPreferences.MUSIC_LEVELER_ENABLED, it) }
                            if (it) MusicLevelerOverlayService.start(context) else MusicLevelerOverlayService.stop(context)
                        })
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    // Auto-hide toggle
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Auto-Hide When Silent", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Hides when no audio is playing", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = autoHide, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.MUSIC_LEVELER_AUTO_HIDE, it) }
                            if (enabled) { MusicLevelerOverlayService.stop(context); MusicLevelerOverlayService.start(context) }
                        })
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    // Position
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Position", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Top", "Bottom").forEach { pos ->
                                FilterChip(selected = position == pos, onClick = {
                                    scope.launch { AppPreferences.set(AppPreferences.MUSIC_LEVELER_POSITION, pos) }
                                    if (enabled) { MusicLevelerOverlayService.stop(context); MusicLevelerOverlayService.start(context) }
                                }, label = { Text(pos) })
                            }
                        }
                    }
                }
            }

            // Size & Opacity
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Size & Opacity", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Bar Height: ${barHeight.toInt()}dp", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = barHeight, onValueChange = {
                        barHeight = it
                        scope.launch { AppPreferences.set(AppPreferences.MUSIC_LEVELER_HEIGHT, it) }
                        if (enabled) { MusicLevelerOverlayService.stop(context); MusicLevelerOverlayService.start(context) }
                    }, valueRange = 24f..120f, modifier = Modifier.fillMaxWidth())

                    Text("Opacity: ${(opacity * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = opacity, onValueChange = {
                        opacity = it
                        scope.launch { AppPreferences.set(AppPreferences.MUSIC_LEVELER_OPACITY, it) }
                        if (enabled) { MusicLevelerOverlayService.stop(context); MusicLevelerOverlayService.start(context) }
                    }, valueRange = 0.1f..1f, modifier = Modifier.fillMaxWidth())
                }
            }

            // Color palette
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Bar Color", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    presetColors.chunked(6).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { (hex, name) ->
                                val color = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.White }
                                val selected = colorHex.equals(hex, true)
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        Modifier.size(40.dp).clip(CircleShape).background(color)
                                            .clickable {
                                                scope.launch { AppPreferences.set(AppPreferences.MUSIC_LEVELER_COLOR, hex) }
                                                if (enabled) { MusicLevelerOverlayService.stop(context); MusicLevelerOverlayService.start(context) }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (selected) Icon(Icons.Default.Check, null,
                                            tint = if (hex == "#FFFFFF" || hex == "#FFD600") Color.Black else Color.White,
                                            modifier = Modifier.size(20.dp))
                                    }
                                    Text(name, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }

            // Apply button
            Button(onClick = {
                if (enabled) { MusicLevelerOverlayService.stop(context); MusicLevelerOverlayService.start(context) }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                enabled = enabled) {
                Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Apply Changes")
            }
        }
    }
}

// ─── SECURITY MOTION ─────────────────────────────────────────────────────────
@Composable
fun SecurityMotionScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled     by AppPreferences.get(AppPreferences.SECURITY_MOTION_ENABLED, false).collectAsState(false)
    val sensitivity by AppPreferences.get(AppPreferences.SECURITY_MOTION_SENSITIVITY, 0.5f).collectAsState(0.5f)
    val soundEnabled by AppPreferences.get(AppPreferences.SECURITY_MOTION_SOUND_ENABLED, true).collectAsState(true)
    val alarmUri    by AppPreferences.get(AppPreferences.SECURITY_MOTION_ALARM_URI, "").collectAsState("")
    var sliderVal   by remember { mutableFloatStateOf(0.5f) }
    LaunchedEffect(sensitivity) { sliderVal = sensitivity }
    var alarmActive by remember { mutableStateOf(false) }
    var countdown   by remember { mutableIntStateOf(0) }
    var mediaPlayer by remember { mutableStateOf<android.media.MediaPlayer?>(null) }

    DisposableEffect(Unit) { onDispose { mediaPlayer?.release() } }

    fun playAlarm() {
        if (!soundEnabled) return
        try {
            val uri = if (alarmUri.isNotEmpty()) android.net.Uri.parse(alarmUri)
                      else android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
                           ?: return
            mediaPlayer?.release()
            mediaPlayer = android.media.MediaPlayer().apply {
                setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM).build())
                setDataSource(context, uri)
                isLooping = true; prepare(); start()
            }
        } catch (e: Exception) { e.printStackTrace() }
    }
    fun stopAlarm() { try { mediaPlayer?.stop(); mediaPlayer?.release(); mediaPlayer = null } catch (_: Exception) {} }

    val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.toString()?.let { scope.launch { AppPreferences.set(AppPreferences.SECURITY_MOTION_ALARM_URI, it) } }
    }

    LaunchedEffect(enabled) {
        if (enabled) {
            countdown = 5
            while (countdown > 0) { delay(1000); countdown-- }
            alarmActive = true
        } else {
            alarmActive = false; countdown = 0; stopAlarm()
        }
    }

    // Wire alarm to Services SecurityMotionManager
    LaunchedEffect(alarmActive) {
        if (alarmActive) playAlarm() else stopAlarm()
    }

    Scaffold(topBar = { EverlastingTopBar("Security Motion Alert", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            // Status card
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        alarmActive -> MaterialTheme.colorScheme.errorContainer
                        countdown > 0 -> MaterialTheme.colorScheme.tertiaryContainer
                        else -> MaterialTheme.colorScheme.primaryContainer
                    }),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(when {
                        alarmActive -> "🚨"
                        countdown > 0 -> "⏱️"
                        else -> "🔐"
                    }, style = MaterialTheme.typography.displaySmall)
                    Spacer(Modifier.height(8.dp))
                    Text(when {
                        countdown > 0 -> "Arming in ${countdown}s — place your device"
                        alarmActive -> "🔴 ALARM — Device was moved!"
                        else -> "Motion Guard — Ready to Arm"
                    }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center)
                    if (alarmActive) {
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { scope.launch { AppPreferences.set(AppPreferences.SECURITY_MOTION_ENABLED, false) }; alarmActive = false; stopAlarm() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                            Icon(Icons.Default.Close, null); Spacer(Modifier.width(4.dp)); Text("Stop Alarm")
                        }
                    }
                }
            }

            // Enable toggle
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Enable Motion Guard", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Sound alarm if device is moved", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = enabled, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.SECURITY_MOTION_ENABLED, it) }
                        })
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    Column(Modifier.padding(16.dp)) {
                        val label = when {
                            sliderVal < 0.3f -> "Low — only large movements"
                            sliderVal < 0.6f -> "Medium — balanced"
                            sliderVal < 0.8f -> "High — sensitive"
                            else -> "Max — any slight movement"
                        }
                        Text("Sensitivity: $label", style = MaterialTheme.typography.bodyMedium)
                        Slider(value = sliderVal, onValueChange = {
                            sliderVal = it; scope.launch { AppPreferences.set(AppPreferences.SECURITY_MOTION_SENSITIVITY, it) }
                        }, valueRange = 0.1f..1f, modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            // Alarm sound settings
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Alarm Sound", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Play loud alarm when motion detected", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = soundEnabled, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.SECURITY_MOTION_SOUND_ENABLED, it) }
                        })
                    }
                    if (soundEnabled) {
                        HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Custom Sound", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(if (alarmUri.isEmpty()) "Default alarm ringtone"
                                     else android.net.Uri.parse(alarmUri).lastPathSegment ?: "Custom file",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (alarmUri.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                                            else MaterialTheme.colorScheme.primary)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (alarmUri.isNotEmpty()) {
                                    OutlinedButton(onClick = {
                                        scope.launch { AppPreferences.set(AppPreferences.SECURITY_MOTION_ALARM_URI, "") }
                                    }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) { Text("Reset") }
                                }
                                FilledTonalButton(onClick = { soundPicker.launch("audio/*") },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) {
                                    Icon(Icons.Default.MusicNote, null, Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp)); Text("Browse")
                                }
                            }
                        }
                        HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                        OutlinedButton(onClick = { playAlarm() }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Test Alarm Sound")
                        }
                    }
                }
            }

            InfoCard(Icons.Default.Info, "5-Second Arm Delay",
                "After enabling, you have 5 seconds to place the device. The alarm will sound and your screen will alert you if motion is detected.", isError = false)
        }
    }
}

// ─── WALKIE TALKIE ───────────────────────────────────────────────────────────
data class ChatMessage(val text: String, val isMine: Boolean, val time: String)

@Composable
fun WalkieTalkieScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isTalking    by remember { mutableStateOf(false) }
    var isConnected  by remember { mutableStateOf(false) }
    var myIp         by remember { mutableStateOf("") }
    var targetIp     by remember { mutableStateOf("") }
    var chatText     by remember { mutableStateOf("") }
    var chatMessages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var activeTab    by remember { mutableStateOf(0) } // 0=Talk, 1=Chat, 2=Setup
    var hasAudio by remember { mutableStateOf(PermissionManager.hasRecordAudio(context)) }
    val audioPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasAudio = granted
    }

    // Get device IP
    LaunchedEffect(Unit) {
        try {
            val ifaces = java.net.NetworkInterface.getNetworkInterfaces()
            while (ifaces.hasMoreElements()) {
                val iface = ifaces.nextElement()
                val addrs = iface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                        myIp = addr.hostAddress ?: ""
                    }
                }
            }
        } catch (_: Exception) {}
    }

    val sdf = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }

    Scaffold(topBar = { EverlastingTopBar("Walkie Talkie", navController) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {

            // Tab bar
            TabRow(selectedTabIndex = activeTab, modifier = Modifier.fillMaxWidth()) {
                listOf("🎙️ Talk", "💬 Chat", "⚙️ Setup").forEachIndexed { i, title ->
                    Tab(selected = activeTab == i, onClick = { activeTab = i },
                        text = { Text(title, style = MaterialTheme.typography.labelMedium) })
                }
            }

            when (activeTab) {
                // ── TALK TAB ──────────────────────────────────────────────
                0 -> {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {

                        // Status card
                        Card(Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isTalking   -> MaterialTheme.colorScheme.errorContainer
                                    isConnected -> MaterialTheme.colorScheme.primaryContainer
                                    else        -> MaterialTheme.colorScheme.surfaceVariant
                                }),
                            shape = MaterialTheme.shapes.extraLarge) {
                            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(when { isTalking -> "🔴" ; isConnected -> "🟢" ; else -> "⚫" }, style = MaterialTheme.typography.displaySmall)
                                Text(when { isTalking -> "Transmitting…" ; isConnected -> "Connected — Ready" ; else -> "Not Connected" },
                                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (myIp.isNotEmpty()) Text("Your IP: $myIp", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        if (!hasAudio) {
                            Button(onClick = { audioPerm.launch(android.Manifest.permission.RECORD_AUDIO) },
                                modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text("Grant Microphone Access")
                            }
                        }

                        // Big PTT button
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Button(
                                onClick = {
                                    if (!hasAudio) return@Button
                                    isTalking = !isTalking
                                },
                                modifier = Modifier.size(140.dp).clip(CircleShape),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isTalking) MaterialTheme.colorScheme.error
                                                     else MaterialTheme.colorScheme.primary),
                                enabled = hasAudio && (isConnected || targetIp.isNotEmpty())
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(if (isTalking) Icons.Default.MicOff else Icons.Default.Mic,
                                        null, Modifier.size(40.dp))
                                    Text(if (isTalking) "Release" else "Hold & Talk",
                                        style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }

                        Text(
                            if (!hasAudio) "⚠️ Microphone permission required"
                            else if (targetIp.isEmpty()) "👆 Go to Setup tab to enter the other device's IP"
                            else "Press and hold the button to talk. Release to listen.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // ── CHAT TAB ──────────────────────────────────────────────
                1 -> {
                    Column(Modifier.fillMaxSize()) {
                        // Messages list
                        LazyColumn(
                            Modifier.weight(1f).padding(horizontal = 12.dp),
                            reverseLayout = false,
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            if (chatMessages.isEmpty()) {
                                item {
                                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("💬", style = MaterialTheme.typography.displaySmall)
                                            Text("No messages yet. Send a message below!", style = MaterialTheme.typography.bodyMedium,
                                                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            } else {
                                items(chatMessages.size) { i ->
                                    val msg = chatMessages[i]
                                    Row(Modifier.fillMaxWidth(),
                                        horizontalArrangement = if (msg.isMine) Arrangement.End else Arrangement.Start) {
                                        Card(
                                            shape = MaterialTheme.shapes.large,
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (msg.isMine) MaterialTheme.colorScheme.primary
                                                                 else MaterialTheme.colorScheme.surfaceVariant),
                                            modifier = Modifier.widthIn(max = 280.dp)
                                        ) {
                                            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                                Text(msg.text, color = if (msg.isMine) MaterialTheme.colorScheme.onPrimary
                                                                        else MaterialTheme.colorScheme.onSurface)
                                                Text(msg.time, style = MaterialTheme.typography.labelSmall,
                                                    color = if (msg.isMine) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f)
                                                            else MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Input bar
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth().padding(8.dp).imePadding(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = chatText,
                                onValueChange = { chatText = it },
                                placeholder = { Text("Type a message…") },
                                modifier = Modifier.weight(1f),
                                maxLines = 3,
                                shape = MaterialTheme.shapes.extraLarge
                            )
                            FloatingActionButton(
                                onClick = {
                                    if (chatText.isNotBlank()) {
                                        val time = sdf.format(java.util.Date())
                                        chatMessages = chatMessages + ChatMessage(chatText.trim(), true, time)
                                        // TODO: send over UDP when actually connected
                                        chatText = ""
                                    }
                                },
                                modifier = Modifier.size(48.dp),
                                containerColor = MaterialTheme.colorScheme.primary
                            ) { Icon(Icons.Default.Send, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(20.dp)) }
                        }
                    }
                }

                // ── SETUP TAB ─────────────────────────────────────────────
                2 -> {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {

                        Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Column(Modifier.padding(20.dp)) {
                                Text("📡 How to Connect", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                listOf(
                                    "1️⃣ Connect both phones to the same Wi-Fi",
                                    "2️⃣ Share your IP address with the other person",
                                    "3️⃣ Enter their IP address below",
                                    "4️⃣ Go to Talk tab and hold the big button to speak"
                                ).forEach {
                                    Text(it, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(vertical = 2.dp))
                                }
                            }
                        }

                        Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Devices, null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Your IP Address", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                }
                                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.background) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (myIp.isEmpty()) "Getting IP…" else myIp,
                                            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary)
                                        IconButton(onClick = {
                                            val cb = context.getSystemService(android.content.ClipboardManager::class.java)
                                            cb?.setPrimaryClip(android.content.ClipData.newPlainText("IP", myIp))
                                            android.widget.Toast.makeText(context, "IP copied!", android.widget.Toast.LENGTH_SHORT).show()
                                        }) { Icon(Icons.Default.ContentCopy, null) }
                                    }
                                }
                                Text("Share this with the other person", style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Wifi, null, tint = MaterialTheme.colorScheme.secondary)
                                    Text("Other Device's IP", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                }
                                OutlinedTextField(
                                    value = targetIp, onValueChange = { targetIp = it },
                                    label = { Text("Enter their IP (e.g. 192.168.1.5)") },
                                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                                    leadingIcon = { Icon(Icons.Default.Wifi, null) }
                                )
                                Button(onClick = {
                                    isConnected = targetIp.isNotEmpty()
                                    android.widget.Toast.makeText(context,
                                        if (isConnected) "Ready! Go to Talk tab 🎙️" else "Enter an IP first",
                                        android.widget.Toast.LENGTH_SHORT).show()
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isConnected) "✓ Connected to $targetIp" else "Save & Connect")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ─── COMPASS ─────────────────────────────────────────────────────────────────
@Composable
fun CompassScreen(navController: NavController) {
    val context = LocalContext.current
    var azimuth       by remember { mutableFloatStateOf(0f) }
    var pitch         by remember { mutableFloatStateOf(0f) }
    var roll          by remember { mutableFloatStateOf(0f) }
    var magStrength   by remember { mutableFloatStateOf(0f) }
    var compassTheme  by remember { mutableStateOf("Classic") }
    val compassThemes = listOf("Classic", "Neon", "Minimal", "Military", "Space", "Ocean")

    val animAzimuth by animateFloatAsState(
        targetValue = azimuth,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessVeryLow),
        label = "az"
    )

    val sm = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val gravity = remember { FloatArray(3) }
    val geomag  = remember { FloatArray(3) }

    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(ev: SensorEvent) {
                when (ev.sensor.type) {
                    Sensor.TYPE_ACCELEROMETER  -> gravity.indices.forEach { gravity[it] = ev.values[it] }
                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        geomag.indices.forEach { geomag[it] = ev.values[it] }
                        magStrength = kotlin.math.sqrt(geomag[0]*geomag[0] + geomag[1]*geomag[1] + geomag[2]*geomag[2])
                    }
                }
                val r = FloatArray(9); val inc = FloatArray(9)
                if (SensorManager.getRotationMatrix(r, inc, gravity, geomag)) {
                    val ori = FloatArray(3); SensorManager.getOrientation(r, ori)
                    azimuth = Math.toDegrees(ori[0].toDouble()).toFloat().let { if (it < 0) it + 360 else it }
                    pitch   = Math.toDegrees(ori[1].toDouble()).toFloat()
                    roll    = Math.toDegrees(ori[2].toDouble()).toFloat()
                }
            }
            override fun onAccuracyChanged(s: Sensor, a: Int) {}
        }
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let  { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
        sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)?.let { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
        onDispose { sm.unregisterListener(listener) }
    }

    val dir = when {
        azimuth < 22.5  || azimuth >= 337.5 -> "N"
        azimuth < 67.5  -> "NE";  azimuth < 112.5 -> "E";  azimuth < 157.5 -> "SE"
        azimuth < 202.5 -> "S";   azimuth < 247.5 -> "SW"; azimuth < 292.5 -> "W"
        else -> "NW"
    }

    // Theme colors
    val (bgCol, primaryCol, northCol, ringCol) = when (compassTheme) {
        "Neon"     -> listOf(Color(0xFF0D0D0D), Color(0xFF00FF88), Color(0xFFFF0040), Color(0xFF00FFFF))
        "Military" -> listOf(Color(0xFF1A2A1A), Color(0xFF7CBF5E), Color(0xFFFF6600), Color(0xFF4A6A4A))
        "Space"    -> listOf(Color(0xFF050520), Color(0xFFBB86FC), Color(0xFFFF4081), Color(0xFF3700B3))
        "Ocean"    -> listOf(Color(0xFF001A33), Color(0xFF00B4D8), Color(0xFFFF6B35), Color(0xFF0077B6))
        "Minimal"  -> listOf(Color.Transparent, MaterialTheme.colorScheme.onSurface, MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.outline)
        else       -> listOf(Color.Transparent, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.primary)
    }

    val magLevel = (magStrength / 100f).coerceIn(0f, 1f)
    val magLabel = when {
        magStrength < 25  -> "Low — may be near electronics"
        magStrength < 65  -> "Normal — good accuracy"
        magStrength < 100 -> "High — possible interference"
        else              -> "Very High — metal nearby!"
    }

    Scaffold(topBar = { EverlastingTopBar("Compass", navController) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxWidth().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Theme selector
            androidx.compose.foundation.lazy.LazyRow(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(compassThemes.size) { i ->
                    FilterChip(selected = compassTheme == compassThemes[i],
                        onClick = { compassTheme = compassThemes[i] },
                        label = { Text(compassThemes[i]) })
                }
            }

            // Compass rose canvas
            Card(
                Modifier.padding(16.dp).fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(
                    containerColor = if (compassTheme == "Minimal") MaterialTheme.colorScheme.surfaceVariant
                                     else bgCol.takeIf { it != Color.Transparent } ?: MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Fixed size square box centered in its parent
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawThemedCompass(animAzimuth, primaryCol, northCol, ringCol, compassTheme, size.minDimension)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(dir, style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Black, color = primaryCol)
                    Text("${azimuth.toInt()}°", style = MaterialTheme.typography.headlineSmall,
                        color = primaryCol.copy(alpha = 0.8f))
                }
            }

            // Stats row
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatCard("Pitch",   "${pitch.toInt()}°",   Icons.Default.RotateLeft,  Modifier.weight(1f))
                StatCard("Roll",    "${roll.toInt()}°",    Icons.Default.RotateRight, Modifier.weight(1f))
                StatCard("Bearing", "${azimuth.toInt()}°", Icons.Default.Explore,     Modifier.weight(1f))
                StatCard("🧲 Field", "${magStrength.toInt()}µT", Icons.Default.Explore, Modifier.weight(1f))
            }


            InfoCard(Icons.Default.Info, "Calibration",
                "Move your phone in a figure-8 pattern to calibrate. Keep away from metal objects for accurate readings.", isError = false)
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun DrawScope.drawThemedCompass(azimuth: Float, primary: Color, north: Color, ring: Color, theme: String, sz: Float) {
    val cx = sz / 2f; val cy = sz / 2f; val radius = sz * 0.40f
    val glowAlpha = if (theme == "Neon" || theme == "Space") 0.25f else 0.12f

    drawCircle(color = ring.copy(alpha = glowAlpha), radius = radius + 14f, center = Offset(cx, cy))
    drawCircle(color = ring.copy(alpha = 0.5f), radius = radius + 14f, center = Offset(cx, cy),
        style = androidx.compose.ui.graphics.drawscope.Stroke(if (theme == "Neon") 4f else 2f))

    for (i in 0 until 360 step 5) {
        val isCardinal = i % 90 == 0; val is45 = i % 45 == 0
        val tickLen = if (isCardinal) 28f else if (is45) 18f else 8f
        val rad = Math.toRadians(i.toDouble()).toFloat()
        val sa = rad - Math.toRadians(azimuth.toDouble()).toFloat()
        val sinA = sin(sa); val cosA = cos(sa)
        drawLine(color = if (isCardinal) primary else ring.copy(alpha = 0.4f),
            start = Offset(cx + radius * sinA, cy - radius * cosA),
            end   = Offset(cx + (radius - tickLen) * sinA, cy - (radius - tickLen) * cosA),
            strokeWidth = if (isCardinal) 3.5f else 1f)
    }

    val nAngle = -Math.toRadians(azimuth.toDouble()).toFloat()
    // North needle
    drawLine(color = north, start = Offset(cx, cy),
        end = Offset(cx + sin(nAngle) * radius * 0.68f, cy - cos(nAngle) * radius * 0.68f),
        strokeWidth = 7f)
    // South needle  
    val sAngle = nAngle + Math.PI.toFloat()
    drawLine(color = primary.copy(alpha = 0.45f), start = Offset(cx, cy),
        end = Offset(cx + sin(sAngle) * radius * 0.5f, cy - cos(sAngle) * radius * 0.5f),
        strokeWidth = 5f)
    // Center
    drawCircle(color = ring,    radius = 14f, center = Offset(cx, cy))
    drawCircle(color = north,   radius = 7f,  center = Offset(cx, cy))
}

@Composable
private fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ─── FAKE CALL ───────────────────────────────────────────────────────────────
@Composable
fun FakeCallScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var callerName   by remember { mutableStateOf("Mom") }
    var callerNumber by remember { mutableStateOf("+91 98765 43210") }
    var callerAvatar by remember { mutableStateOf("👩") }
    var delaySeconds by remember { mutableIntStateOf(5) }
    var ringtoneType by remember { mutableStateOf("Default") }
    var isScheduled  by remember { mutableStateOf(false) }
    var countdown    by remember { mutableIntStateOf(0) }

    val avatarOptions = listOf("👩","👨","👧","👦","👴","👵","🧑","👮","👩‍⚕️","👨‍💼","🤖","👻","🐱","🐶")
    val ringtoneOptions = listOf("Default", "Vibrate Only")

    var hasOverlay by remember { mutableStateOf(android.provider.Settings.canDrawOverlays(context)) }
    val lifecycleOwnerFC = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwnerFC) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME)
                hasOverlay = android.provider.Settings.canDrawOverlays(context)
        }
        lifecycleOwnerFC.lifecycle.addObserver(obs)
        onDispose { lifecycleOwnerFC.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(isScheduled) {
        if (isScheduled) {
            countdown = delaySeconds
            while (countdown > 0) { delay(1000L); countdown-- }
            isScheduled = false
            com.coolappstore.everlastingandroidtweak.features.fakecall.FakeCallOverlayService.start(
                context, callerName, callerNumber, callerAvatar, ringtoneType
            )
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Fake Call", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            // Header
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("📞", style = MaterialTheme.typography.displaySmall)
                        Column {
                            Text("Fake Call", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Simulates a full-screen incoming call overlay. No Telecom setup needed.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                        }
                    }
                }
            }

            // Permission check - only needs overlay
            if (!hasOverlay) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error)
                            Text("Display Over Other Apps required", fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall)
                        }
                        Text("This allows the fake call screen to appear over other apps.",
                            style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            context.startActivity(android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:${context.packageName}")
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Layers, null); Spacer(Modifier.width(6.dp)); Text("Grant Permission")
                        }
                    }
                }
            } else {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                    shape = MaterialTheme.shapes.large) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text("Ready! Just configure and press the button.", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // Contact picker
            val contactPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
            val hasContactPerm = remember { mutableStateOf(
                androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            )}
            val contactPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { uri ->
                uri?.let {
                    try {
                        val cursor = context.contentResolver.query(uri, null, null, null, null)
                        cursor?.use { c ->
                            if (c.moveToFirst()) {
                                val nameIdx = c.getColumnIndex(android.provider.ContactsContract.Contacts.DISPLAY_NAME)
                                val idIdx = c.getColumnIndex(android.provider.ContactsContract.Contacts._ID)
                                if (nameIdx >= 0) callerName = c.getString(nameIdx) ?: callerName
                                val id = if (idIdx >= 0) c.getString(idIdx) else null
                                if (id != null) {
                                    val phones = context.contentResolver.query(
                                        android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                        null, "${android.provider.ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?", arrayOf(id), null
                                    )
                                    phones?.use { p ->
                                        if (p.moveToFirst()) {
                                            val numIdx = p.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
                                            if (numIdx >= 0) callerNumber = p.getString(numIdx) ?: callerNumber
                                        }
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }

            // Caller setup
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Caller Details", style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        FilledTonalButton(onClick = {
                            if (hasContactPerm.value) contactPicker.launch(null)
                            else contactPerm.launch(android.Manifest.permission.READ_CONTACTS)
                        }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                            Icon(Icons.Default.Contacts, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Pick Contact")
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(avatarOptions.size) { i ->
                            Surface(onClick = { callerAvatar = avatarOptions[i] },
                                shape = CircleShape,
                                color = if (callerAvatar == avatarOptions[i]) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surface,
                                modifier = Modifier.size(48.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(avatarOptions[i], style = MaterialTheme.typography.titleLarge)
                                }
                            }
                        }
                    }
                    OutlinedTextField(value = callerName, onValueChange = { callerName = it },
                        label = { Text("Caller Name") }, modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Person, null) }, singleLine = true)
                    OutlinedTextField(value = callerNumber, onValueChange = { callerNumber = it },
                        label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Phone, null) }, singleLine = true)
                }
            }

            // Ringtone
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Ringtone", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ringtoneOptions.forEach { opt ->
                            FilterChip(selected = ringtoneType == opt, onClick = { ringtoneType = opt },
                                label = { Text(opt) })
                        }
                    }
                }
            }

            // Delay
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Delay: ${if (delaySeconds == 0) "Instant" else "${delaySeconds}s"}",
                        style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Slider(value = delaySeconds.toFloat(), onValueChange = { delaySeconds = it.toInt() },
                        valueRange = 0f..60f, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Instant", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("60 sec", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            if (isScheduled) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📲 Incoming call in ${countdown}s…",
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { if (delaySeconds > 0) 1f - countdown.toFloat() / delaySeconds else 1f },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape)
                        )
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { isScheduled = false }) {
                            Icon(Icons.Default.Close, null); Spacer(Modifier.width(4.dp)); Text("Cancel")
                        }
                    }
                }
            } else {
                Button(
                    onClick = { if (hasOverlay) isScheduled = true },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    enabled = callerNumber.isNotBlank() && hasOverlay
                ) {
                    Icon(Icons.Default.Call, null); Spacer(Modifier.width(8.dp))
                    Text(if (delaySeconds == 0) "Trigger Fake Call Now" else "Schedule Fake Call (${delaySeconds}s)")
                }
            }

            InfoCard(Icons.Default.Info, "How It Works",
                "Draws a full-screen call UI over all other apps using the overlay permission. Appears exactly like a real incoming call with accept and decline buttons.",
                isError = false)
        }
    }
}

// ─── VIBRATION PATTERNS ──────────────────────────────────────────────────────
@Composable
fun VibrationPatternsScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val callPattern  by AppPreferences.get(AppPreferences.CALL_VIBRATION_PATTERN, "Classic Ring").collectAsState("Classic Ring")
    val alarmPattern by AppPreferences.get(AppPreferences.ALARM_VIBRATION_PATTERN, "Urgent").collectAsState("Urgent")
    val notifPattern by AppPreferences.get(AppPreferences.NOTIF_VIBRATION_PATTERN, "Gentle Pulse").collectAsState("Gentle Pulse")

    val allPatterns = listOf(
        VibPatternData("Short Tap",      "·",   "Single quick tap",              longArrayOf(0, 60)),
        VibPatternData("Long Press",     "—",   "Long single buzz",              longArrayOf(0, 600)),
        VibPatternData("Double Tap",     "··",  "Two quick taps",                longArrayOf(0, 80, 80, 80)),
        VibPatternData("Triple Tap",     "···", "Three quick taps",              longArrayOf(0, 70, 60, 70, 60, 70)),
        VibPatternData("Classic Ring",   "∿",   "Old-school phone ring",         longArrayOf(0, 300, 200, 300, 200, 300)),
        VibPatternData("Heartbeat",      "♥",   "Ba-dum heartbeat",              longArrayOf(0, 80, 60, 120, 500)),
        VibPatternData("Double Heart",   "♥♥",  "Double heartbeat rhythm",       longArrayOf(0, 80, 60, 120, 120, 80, 60, 120, 500)),
        VibPatternData("SOS",            "···—···", "Morse code SOS",            longArrayOf(0,100,100,100,100,100,300,300,100,300,100,300,300,100,100,100,100,100)),
        VibPatternData("Rapid Fire",     "≡",   "Quick rapid bursts",            longArrayOf(0, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40)),
        VibPatternData("Slow Pulse",     "○",   "Slow rhythmic pulse",           longArrayOf(0, 400, 400, 400, 400)),
        VibPatternData("Escalating",     "↑",   "Gets stronger over time",       longArrayOf(0, 50, 100, 100, 200, 150, 300)),
        VibPatternData("Descending",     "↓",   "Gets weaker over time",         longArrayOf(0, 300, 150, 200, 100, 100, 50)),
        VibPatternData("Drumroll",       "⊕",   "Fast drumroll effect",          longArrayOf(0,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30)),
        VibPatternData("Gentle Pulse",   "~",   "Soft gentle notification",      longArrayOf(0, 150, 300, 150)),
        VibPatternData("Urgent",         "!!",  "Strong urgent alert",           longArrayOf(0, 500, 100, 500)),
        VibPatternData("Tick Tock",      "⏱",   "Clock-like tick pattern",       longArrayOf(0, 80, 920, 80, 920)),
        VibPatternData("Knock Knock",    "✊",   "Two knocks like a door",        longArrayOf(0, 200, 150, 200)),
        VibPatternData("Buzz Buzz",      "⚡",   "Electric buzz feeling",         longArrayOf(0, 120, 80, 120, 80, 120)),
        VibPatternData("Wave",           "≈",   "Smooth wave motion",            longArrayOf(0, 100, 50, 200, 50, 300, 50, 200, 50, 100)),
        VibPatternData("Syncopated",     "♪",   "Off-beat musical rhythm",       longArrayOf(0, 100, 200, 50, 150, 200, 100)),
        VibPatternData("Alarm Clock",    "⏰",   "Traditional alarm pattern",     longArrayOf(0,200,100,200,100,200,400,200,100,200,100,200)),
        VibPatternData("Incoming Call",  "📞",  "Traditional phone ring",        longArrayOf(0,500,500,500,500,500,500)),
        VibPatternData("Military",       "▣",   "Three sharp bursts",            longArrayOf(0, 200, 150, 200, 150, 200)),
        VibPatternData("Morse Hi",       "—·",  "Dash-dot Morse",                longArrayOf(0, 300, 100, 100)),
        VibPatternData("Silent",         "∅",   "No vibration",                  longArrayOf(0))
    )

    val vibrator = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (context.getSystemService(android.content.Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
    }

    fun testPattern(patternName: String) {
        val pat = allPatterns.find { it.name == patternName }?.waveform ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.cancel()
            vibrator.vibrate(VibrationEffect.createWaveform(pat, -1))
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Vibration Patterns", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            // Header card
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("📳", fontSize = 36.sp)
                        Column {
                            Text("Custom Vibration Patterns", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("${allPatterns.size} unique patterns • Tap any chip to test it live",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                        }
                    }
                }
            }

            val callEnabled  by AppPreferences.get(AppPreferences.CALL_VIBRATION_ENABLED, true).collectAsState(true)
            val alarmEnabled by AppPreferences.get(AppPreferences.ALARM_VIBRATION_ENABLED, true).collectAsState(true)
            val notifEnabled by AppPreferences.get(AppPreferences.NOTIF_VIBRATION_ENABLED, true).collectAsState(true)

            PatternSection2("📞  Incoming Calls", callPattern, allPatterns, { testPattern(it) },
                isEnabled = callEnabled, onToggle = { scope.launch { AppPreferences.set(AppPreferences.CALL_VIBRATION_ENABLED, it) } }
            ) { scope.launch { AppPreferences.set(AppPreferences.CALL_VIBRATION_PATTERN, it) } }

            PatternSection2("⏰  Alarms", alarmPattern, allPatterns, { testPattern(it) },
                isEnabled = alarmEnabled, onToggle = { scope.launch { AppPreferences.set(AppPreferences.ALARM_VIBRATION_ENABLED, it) } }
            ) { scope.launch { AppPreferences.set(AppPreferences.ALARM_VIBRATION_PATTERN, it) } }

            PatternSection2("🔔  Notifications", notifPattern, allPatterns, { testPattern(it) },
                isEnabled = notifEnabled, onToggle = { scope.launch { AppPreferences.set(AppPreferences.NOTIF_VIBRATION_ENABLED, it) } }
            ) { scope.launch { AppPreferences.set(AppPreferences.NOTIF_VIBRATION_PATTERN, it) } }

            InfoCard(Icons.Default.Info, "Tap to Preview",
                "Selecting a pattern will immediately trigger a test vibration so you can feel it.", isError = false)
            Spacer(Modifier.height(8.dp))
        }
    }
}

data class VibPatternData(val name: String, val emoji: String, val desc: String, val waveform: LongArray)

@Composable
private fun PatternSection2(
    title: String,
    current: String,
    patterns: List<VibPatternData>,
    onTest: (String) -> Unit,
    isEnabled: Boolean = true,
    onToggle: ((Boolean) -> Unit)? = null,
    onSelect: (String) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp, top = 12.dp))

        Card(
            Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(0.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                // Current selection display
                val selected = patterns.find { it.name == current }
                if (selected != null) {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        ) {
                            Text(selected.emoji,
                                Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                fontSize = 18.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Selected: ${selected.name}",
                                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary)
                            Text(selected.desc, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row {
                            FilledTonalIconButton(onClick = { onTest(current) }) {
                                Icon(Icons.Default.Vibration, null, modifier = Modifier.size(20.dp))
                            }
                            if (onToggle != null) {
                                Spacer(Modifier.width(4.dp))
                                Switch(checked = isEnabled, onCheckedChange = { onToggle(it) })
                            }
                        }
                    }
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))
                }

                // All pattern chips in wrapped rows
                val chunked = patterns.chunked(4)
                chunked.forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { p ->
                            FilterChip(
                                selected = current == p.name,
                                onClick = { onSelect(p.name); onTest(p.name) },
                                label = {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 2.dp)) {
                                        Text(p.emoji, fontSize = 14.sp)
                                        Text(p.name, style = MaterialTheme.typography.labelSmall,
                                            maxLines = 1)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // Fill remaining slots in last row
                        repeat(4 - row.size) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
    }
}

// ─── LOCK SCREEN WIDGETS ─────────────────────────────────────────────────────
@Composable
fun LockScreenWidgetsScreen(navController: NavController) {
    val context = LocalContext.current

    val widgets = listOf(
        Triple("Clock Widget", "Large or analog clock on lock screen", Icons.Default.AccessTime),
        Triple("Weather Widget", "Current weather and forecast", Icons.Default.Cloud),
        Triple("Music Controls", "Media playback controls", Icons.Default.MusicNote),
        Triple("Battery Status", "Detailed battery percentage", Icons.Default.BatteryFull),
        Triple("Step Counter", "Daily step count", Icons.Default.DirectionsWalk),
        Triple("Calendar Events", "Next upcoming event", Icons.Default.CalendarToday),
        Triple("Quick Shortcuts", "Launch apps from lock screen", Icons.Default.Apps),
    )
    val states = remember { mutableStateListOf(*Array(widgets.size) { false }) }

    Scaffold(topBar = { EverlastingTopBar("Lock Screen Widgets", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large) {
                Column(Modifier.padding(16.dp)) {
                    Text("🔒 Lock Screen Widgets", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Customize widgets displayed on your lock screen. Some options require system-level access.", style = MaterialTheme.typography.bodySmall)
                }
            }
            FeatureSection("Available Widgets") {
                widgets.forEachIndexed { i, (name, desc, icon) ->
                    ListItem(
                        headlineContent = { Text(name) },
                        supportingContent = { Text(desc) },
                        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp)) },
                        trailingContent = { Switch(checked = states[i], onCheckedChange = { states[i] = it }) }
                    )
                    if (i < widgets.lastIndex) HorizontalDivider()
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                try {
                    context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(6.dp)); Text("Open Lock Screen Settings")
            }
            InfoCard(Icons.Default.Info, "Android 12+",
                "Lock screen widget support varies by device manufacturer. Some options may require MIUI, One UI, or similar OEM customizations.", isError = false)
        }
    }
}

// ─── CUSTOM QS TILES ─────────────────────────────────────────────────────────
@Composable
fun CustomQSTilesScreen(navController: NavController) {
    val context = LocalContext.current

    val tiles = listOf(
        Triple("Keep Screen On", "Prevent screen from sleeping", Icons.Default.Lightbulb),
        Triple("Shake Torch", "Toggle shake-to-torch", Icons.Default.FlashOn),
        Triple("Flip to DND", "Toggle flip-to-DND mode", Icons.Default.DoNotDisturb),
        Triple("Volume Boost", "Toggle volume boost", Icons.Default.VolumeUp),
        Triple("Music Leveler", "Toggle equalizer overlay", Icons.Default.BarChart),
        Triple("Security Motion", "Toggle motion security alarm", Icons.Default.Security),
        Triple("Auto Rotate", "Toggle screen rotation", Icons.Default.ScreenRotation),
        Triple("Bluetooth", "Quick Bluetooth toggle", Icons.Default.Bluetooth),
    )
    val states = remember { mutableStateListOf(*Array(tiles.size) { i -> i < 2 }) }

    Scaffold(topBar = { EverlastingTopBar("Custom QS Tiles", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large) {
                Column(Modifier.padding(16.dp)) {
                    Text("⚡ Quick Settings Tiles", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Toggle which tiles appear in the Quick Settings panel. Drag tiles to reorder in your notification shade.", style = MaterialTheme.typography.bodySmall)
                }
            }
            FeatureSection("Available Tiles") {
                tiles.forEachIndexed { i, (name, desc, icon) ->
                    ListItem(
                        headlineContent = { Text(name) },
                        supportingContent = { Text(desc) },
                        leadingContent = {
                            Box(Modifier.size(36.dp).clip(MaterialTheme.shapes.small)
                                .background(if (states[i]) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center) {
                                Icon(icon, null, Modifier.size(20.dp),
                                    tint = if (states[i]) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        },
                        trailingContent = { Switch(checked = states[i], onCheckedChange = { states[i] = it }) }
                    )
                    if (i < tiles.lastIndex) HorizontalDivider()
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                try {
                    context.startActivity(
                        Intent("android.settings.ACTION_QS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                    try {
                        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {}
                }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Icon(Icons.Default.GridView, null); Spacer(Modifier.width(6.dp)); Text("Open Quick Settings Panel")
            }
            InfoCard(Icons.Default.Info, "How to Add Tiles",
                "Swipe down twice to open full Quick Settings → tap Edit/Pencil icon → drag Everlasting tiles into position.", isError = false)
        }
    }
}

// ─── CHARGE LIMIT ALARM ───────────────────────────────────────────────────────
@Composable
fun ChargeLimitScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled    by AppPreferences.get(AppPreferences.CHARGE_LIMIT_ENABLED, false).collectAsState(false)
    val limit      by AppPreferences.get(AppPreferences.CHARGE_LIMIT_PERCENT, 80).collectAsState(80)
    val ringtoneUri by AppPreferences.get(AppPreferences.CHARGE_RINGTONE_URI, "").collectAsState("")
    val repeat     by AppPreferences.get(AppPreferences.CHARGE_REPEAT_ENABLED, true).collectAsState(true)
    var sliderVal  by remember { mutableFloatStateOf(80f) }
    LaunchedEffect(limit) { sliderVal = limit.toFloat() }

    val batteryIntent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
    val battLevel = remember {
        val lev = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scl = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (lev >= 0) lev * 100 / scl else 0
    }

    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.toString()?.let { scope.launch { AppPreferences.set(AppPreferences.CHARGE_RINGTONE_URI, it) } }
    }

    Scaffold(topBar = { EverlastingTopBar("Charge Limit Alarm", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            // Hero card
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⚡", style = MaterialTheme.typography.displayMedium)
                    Text("Battery Health Guard", style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Now: $battLevel%  •  Limit: ${sliderVal.toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { battLevel / 100f },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape),
                        color = when {
                            battLevel >= sliderVal.toInt() -> MaterialTheme.colorScheme.error
                            battLevel >= sliderVal.toInt() - 10 -> MaterialTheme.colorScheme.tertiary
                            else -> MaterialTheme.colorScheme.primary
                        },
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                    )
                    if (battLevel >= sliderVal.toInt()) {
                        Spacer(Modifier.height(8.dp))
                        Text("🔴 UNPLUG NOW!", style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Settings
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Enable Charge Limit Alarm", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Alarm + notification at set %", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = enabled, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.CHARGE_LIMIT_ENABLED, it) }
                        })
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    Column(Modifier.padding(16.dp)) {
                        Text("Charge Limit: ${sliderVal.toInt()}%", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        Slider(value = sliderVal, onValueChange = {
                            sliderVal = it
                            scope.launch { AppPreferences.set(AppPreferences.CHARGE_LIMIT_PERCENT, it.toInt()) }
                        }, valueRange = 50f..100f, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("50%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("80% ideal", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text("100%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Repeat Alarm", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text("Keep playing until phone is unplugged", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = repeat, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.CHARGE_REPEAT_ENABLED, it) }
                        })
                    }
                }
            }

            // Ringtone selection
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Alarm Sound", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (ringtoneUri.isEmpty()) "Default alarm ringtone"
                                else android.net.Uri.parse(ringtoneUri).lastPathSegment ?: "Custom file",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (ringtoneUri.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                                        else MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (ringtoneUri.isNotEmpty()) {
                                OutlinedButton(onClick = {
                                    scope.launch { AppPreferences.set(AppPreferences.CHARGE_RINGTONE_URI, "") }
                                }) { Text("Reset") }
                            }
                            FilledTonalButton(onClick = { ringtonePicker.launch("audio/*") }) {
                                Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Browse")
                            }
                        }
                    }
                }
            }

            // Preview alarm button
            OutlinedButton(onClick = {
                scope.launch {
                    val nm = context.getSystemService(android.app.NotificationManager::class.java)
                    nm?.notify(3001,
                        androidx.core.app.NotificationCompat.Builder(context, com.coolappstore.everlastingandroidtweak.EverlastingApp.CHANNEL_ALERTS)
                            .setContentTitle("⚡ Charge Limit TEST")
                            .setContentText("This is how the alarm looks when battery hits the limit.")
                            .setSmallIcon(android.R.drawable.ic_dialog_alert)
                            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                            .setAutoCancel(true).build()
                    )
                    // Test vibration
                    try {
                        val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                        vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0,300,150,300), -1))
                    } catch (_: Exception) {}
                }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Icon(Icons.Default.Notifications, null); Spacer(Modifier.width(6.dp)); Text("Preview Alarm")
            }
            InfoCard(Icons.Default.BatteryFull, "Battery Health Tip",
                "Keeping battery between 20-80% can almost double total battery lifespan. Charging to 100% regularly degrades capacity faster.", isError = false)
        }
    }
}

// ─── APP FREEZER ─────────────────────────────────────────────────────────────
@Composable
fun AppFreezerScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var shizukuReady by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(listOf<android.content.pm.ApplicationInfo>()) }
    var frozenApps by remember { mutableStateOf(setOf<String>()) }
    var loading by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                shizukuReady = com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.isShizukuReady()
                if (shizukuReady && apps.isEmpty()) {
                    scope.launch(Dispatchers.IO) {
                        apps = com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.getUserApps(context)
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("App Freezer", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("❄️ App Freezer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(4.dp))
                    Text("Freeze apps to completely stop all background activity. Frozen apps are disabled until you unfreeze them. Uses Shizuku for root-free operation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }

            if (!shizukuReady) {
                InfoCard(Icons.Default.Warning, "Shizuku Required",
                    "Start Shizuku first: adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                    isError = true, actionLabel = "Get Shizuku",
                    onAction = {
                        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("market://details?id=moe.shizuku.privileged.api"))
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
            } else if (apps.isEmpty()) {
                Card(Modifier.fillMaxWidth().padding(16.dp), shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            } else {
                // Bulk action buttons
                var freezingAll by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        freezingAll = true
                        scope.launch(Dispatchers.IO) {
                            apps.forEach { com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.freezeApp(it.packageName) }
                            frozenApps = apps.map { it.packageName }.toSet()
                            freezingAll = false
                        }
                    }, modifier = Modifier.weight(1f), enabled = !freezingAll) {
                        if (freezingAll) { CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp); Spacer(Modifier.width(4.dp)) }
                        Icon(Icons.Default.AcUnit, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Freeze All")
                    }
                    OutlinedButton(onClick = {
                        scope.launch(Dispatchers.IO) {
                            frozenApps.forEach { com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.unfreezeApp(it) }
                            frozenApps = emptySet()
                        }
                    }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.PlayArrow, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Unfreeze All")
                    }
                }
                FeatureSection("Installed Apps (${apps.size})") {
                    apps.take(50).forEachIndexed { i, app ->
                        val name = context.packageManager.getApplicationLabel(app).toString()
                        val frozen = frozenApps.contains(app.packageName)
                        ListItem(
                            headlineContent = { Text(name, style = MaterialTheme.typography.bodyMedium) },
                            supportingContent = { Text(app.packageName, style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            trailingContent = {
                                FilledTonalButton(
                                    onClick = {
                                        scope.launch(Dispatchers.IO) {
                                            if (frozen) {
                                                com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.unfreezeApp(app.packageName)
                                                frozenApps = frozenApps - app.packageName
                                            } else {
                                                com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.freezeApp(app.packageName)
                                                frozenApps = frozenApps + app.packageName
                                            }
                                        }
                                    },
                                    colors = if (frozen) ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer)
                                    else ButtonDefaults.filledTonalButtonColors()
                                ) {
                                    Text(if (frozen) "Unfreeze" else "Freeze",
                                        style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        )
                        if (i < minOf(apps.size, 50) - 1) HorizontalDivider()
                    }
                }
            }
        }
    }
}

// ─── APP UPDATER ─────────────────────────────────────────────────────────────
@Composable
fun AppUpdaterScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var selfUpdate by remember { mutableStateOf<com.coolappstore.everlastingandroidtweak.features.appupdater.UpdateResult?>(null) }
    var customRepo by remember { mutableStateOf("") }
    var customPkg  by remember { mutableStateOf("") }
    var customResult by remember { mutableStateOf<com.coolappstore.everlastingandroidtweak.features.appupdater.UpdateResult?>(null) }

    Scaffold(topBar = { EverlastingTopBar("App Updater", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("🔄 Sideloaded App Updater", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Check for updates of apps installed from GitHub releases. Compares installed version against the latest GitHub release tag.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }

            // Self-update check
            FeatureSection("Everlasting Tweak") {
                ListItem(
                    headlineContent = { Text("Check for Updates") },
                    supportingContent = { Text("github.com/hari161008/Everlasting-Android-Tweak") },
                    leadingContent = { Icon(Icons.Default.SystemUpdateAlt, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = {
                        if (checking) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        else FilledTonalButton(onClick = {
                            checking = true
                            scope.launch {
                                selfUpdate = com.coolappstore.everlastingandroidtweak.features.appupdater.AppUpdaterHelper.checkSelfUpdate(context)
                                checking = false
                            }
                        }) { Text("Check") }
                    }
                )
                selfUpdate?.let { result ->
                    HorizontalDivider()
                    Card(Modifier.fillMaxWidth().padding(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (result.hasUpdate) MaterialTheme.colorScheme.errorContainer
                                             else MaterialTheme.colorScheme.primaryContainer),
                        shape = MaterialTheme.shapes.large) {
                        Column(Modifier.padding(12.dp)) {
                            Text(if (result.hasUpdate) "Update Available!" else "Up to date",
                                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("Installed: v${result.installedVersion}  •  Latest: v${result.latestVersion}",
                                style = MaterialTheme.typography.bodySmall)
                            if (result.hasUpdate) {
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                                        android.net.Uri.parse(result.downloadUrl)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                                }, modifier = Modifier.fillMaxWidth()) { Text("Download Update") }
                            }
                        }
                    }
                }
            }

            // Custom repo check
            FeatureSection("Check Any GitHub App") {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = customRepo, onValueChange = { customRepo = it },
                        label = { Text("GitHub repo (e.g. user/repo)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Code, null) })
                    OutlinedTextField(value = customPkg, onValueChange = { customPkg = it },
                        label = { Text("Package name (e.g. com.example.app)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Android, null) })
                    Button(onClick = {
                        if (customRepo.isNotBlank() && customPkg.isNotBlank()) {
                            checking = true
                            scope.launch {
                                customResult = com.coolappstore.everlastingandroidtweak.features.appupdater.AppUpdaterHelper.checkGitHubApk(customRepo, customPkg, context)
                                checking = false
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = customRepo.isNotBlank() && customPkg.isNotBlank()) {
                        Text("Check for Updates")
                    }
                    customResult?.let { result ->
                        Card(Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (result.hasUpdate) MaterialTheme.colorScheme.errorContainer
                                                 else MaterialTheme.colorScheme.primaryContainer),
                            shape = MaterialTheme.shapes.large) {
                            Column(Modifier.padding(12.dp)) {
                                Text(result.appName, fontWeight = FontWeight.Bold)
                                Text(if (result.hasUpdate) "Update available: v${result.latestVersion}" else "Up to date (v${result.installedVersion})")
                                if (result.hasUpdate) {
                                    Spacer(Modifier.height(8.dp))
                                    Button(onClick = {
                                        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(result.downloadUrl)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Download") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ─── EYE DROPPER ─────────────────────────────────────────────────────────────
@Composable
fun EyeDropperScreen(navController: NavController) {
    val context = LocalContext.current
    var pickedColor by remember { mutableStateOf<androidx.compose.ui.graphics.Color?>(null) }
    var hexValue by remember { mutableStateOf("") }
    var showLauncher by remember { mutableStateOf(false) }

    // Android 14+ supports ACTION_GET_CONTENT with pixel picker
    val canUseNative = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE // API 34

    Scaffold(topBar = { EverlastingTopBar("Eye Dropper", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("💧 Eye Dropper / Color Picker", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Pick any color from your screen using Android's built-in color picker (Android 14+), or use the manual color wheel below.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }

            // Color preview
            pickedColor?.let { color ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Box(Modifier.size(64.dp).clip(MaterialTheme.shapes.large)
                            .background(color))
                        Column(Modifier.weight(1f)) {
                            Text("Picked Color", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(hexValue, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        FilledTonalButton(onClick = {
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Color", hexValue))
                            android.widget.Toast.makeText(context, "Copied $hexValue", android.widget.Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            FeatureSection("Presets & Manual Pick") {
                // Color palette
                val presets = listOf(
                    "#F44336" to "Red",   "#E91E63" to "Pink",   "#9C27B0" to "Purple",
                    "#3F51B5" to "Indigo","#2196F3" to "Blue",   "#00BCD4" to "Cyan",
                    "#4CAF50" to "Green", "#8BC34A" to "L.Green","#FFEB3B" to "Yellow",
                    "#FF9800" to "Orange","#795548" to "Brown",  "#607D8B" to "Blue Grey",
                    "#FFFFFF" to "White", "#000000" to "Black",  "#9E9E9E" to "Grey"
                )
                Column(Modifier.padding(16.dp)) {
                    Text("Color Palette", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    presets.chunked(5).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { (hex, name) ->
                                val color = try { androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(hex)) }
                                    catch (_: Exception) { androidx.compose.ui.graphics.Color.White }
                                androidx.compose.foundation.layout.Column(
                                    Modifier.weight(1f),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(Modifier.size(44.dp).clip(MaterialTheme.shapes.medium)
                                        .background(color)
                                        .clickable { pickedColor = color; hexValue = hex },
                                        contentAlignment = Alignment.Center) {
                                        if (pickedColor == color) {
                                            Icon(Icons.Default.Check, null,
                                                tint = if (hex == "#FFFFFF") androidx.compose.ui.graphics.Color.Black
                                                       else androidx.compose.ui.graphics.Color.White,
                                                modifier = Modifier.size(20.dp))
                                        }
                                    }
                                    Text(name, style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                HorizontalDivider()
                // Manual hex input
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = hexValue, onValueChange = { hexValue = it
                            if (it.matches(Regex("#[0-9A-Fa-f]{6}"))) {
                                pickedColor = try {
                                    androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(it))
                                } catch (_: Exception) { null }
                            }
                        },
                        label = { Text("Hex Code (e.g. #FF5722)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Colorize, null) }
                    )
                }
            }

            if (canUseNative) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    try {
                        // Android 14+ system color picker
                        val intent = android.content.Intent("android.intent.action.PICK_COLOR")
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        android.widget.Toast.makeText(context, "System color picker not available", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Icon(Icons.Default.Colorize, null); Spacer(Modifier.width(8.dp))
                    Text("Open System Color Picker (Android 14+)")
                }
            }

            InfoCard(Icons.Default.Info, "Android 14+ Required",
                "The system eye dropper that samples pixels anywhere on screen requires Android 14 (API 34) or higher.", isError = false)
        }
    }
}

// ─── NOTIFICATION LIGHTING ───────────────────────────────────────────────────
@Composable
fun NotifLightScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val flashEnabled by AppPreferences.get(AppPreferences.FLASH_NOTIF_ENABLED, false).collectAsState(false)
    val edgeEnabled  by AppPreferences.get(AppPreferences.EDGE_LIGHT_ENABLED, false).collectAsState(false)
    val edgeColor    by AppPreferences.get(AppPreferences.EDGE_LIGHT_COLOR, "#8BCAFF").collectAsState("#8BCAFF")
    var hasNotifListener by remember { mutableStateOf(PermissionManager.isNotificationListenerEnabled(context)) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasNotifListener = PermissionManager.isNotificationListenerEnabled(context)
        }
        lifecycleOwner.lifecycle.addObserver(obs); onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(topBar = { EverlastingTopBar("Notification Lighting", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("💡 Notification Lighting", style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(4.dp))
                    Text("Two modes: Edge lighting draws a glowing border around your screen for notifications. Flashlight pulse blinks the torch — works great on Moto, Pixel, and most Android devices.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }

            if (!hasNotifListener) {
                InfoCard(Icons.Default.Notifications, "Notification Access Required",
                    "Grant Notification Access so this app can detect incoming notifications.",
                    isError = true, actionLabel = "Grant",
                    onAction = { PermissionManager.openNotificationListenerSettings(context) })
            }

            // Flashlight Pulse
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(44.dp).clip(MaterialTheme.shapes.medium)
                            .background(Color(0xFFFF9800).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center) {
                            Text("🔦", style = MaterialTheme.typography.titleLarge)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Flashlight Pulse", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                            Text("Blinks torch 3× per notification", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = flashEnabled, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.FLASH_NOTIF_ENABLED, it) }
                        })
                    }
                    if (flashEnabled) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Card(Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                                shape = MaterialTheme.shapes.large) {
                                Text("✓ Active — will flash on next notification",
                                    Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        val camMgr = remember { context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager }
                        OutlinedButton(onClick = {
                            scope.launch(Dispatchers.IO) {
                                try {
                                    val camId = camMgr.cameraIdList.firstOrNull { id ->
                                        camMgr.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                                    } ?: return@launch
                                    val pattern = listOf(true, false, true, false, true, false)
                                    pattern.forEach { on -> camMgr.setTorchMode(camId, on); delay(150L) }
                                    camMgr.setTorchMode(camId, false)
                                } catch (_: Exception) {}
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.FlashOn, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Preview Flash")
                        }
                    }
                }
            }

            // Edge Lighting
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(44.dp).clip(MaterialTheme.shapes.medium)
                            .background(Color(0xFF9C27B0).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center) {
                            Text("✨", style = MaterialTheme.typography.titleLarge)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Edge Lighting", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                            Text("Glowing border around screen on notification", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = edgeEnabled, onCheckedChange = {
                            scope.launch { AppPreferences.set(AppPreferences.EDGE_LIGHT_ENABLED, it) }
                        })
                    }

                    if (edgeEnabled) {
                        Spacer(Modifier.height(12.dp))
                        Text("Glow Color", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        val colors = listOf("#8BCAFF","#FF5722","#4CAF50","#FFC107","#9C27B0","#00BCD4","#FF4081","#FFFFFF")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            colors.forEach { hex ->
                                val col = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.White }
                                Box(Modifier.size(36.dp).clip(CircleShape).background(col)
                                    .clickable { scope.launch { AppPreferences.set(AppPreferences.EDGE_LIGHT_COLOR, hex) } },
                                    contentAlignment = Alignment.Center) {
                                    if (edgeColor.equals(hex, true))
                                        Icon(Icons.Default.Check, null,
                                            tint = if (hex == "#FFFFFF") Color.Black else Color.White,
                                            modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            InfoCard(Icons.Default.Info, "Works Best When Screen is Off",
                "Flashlight pulse is most effective when the screen is off. Edge lighting uses an overlay and requires Display Over Other Apps.", isError = false)
        }
    }
}

// ─── BATTERY HEALTH ──────────────────────────────────────────────────────────
@Composable
fun BatteryHealthScreen(navController: NavController) {
    val context = LocalContext.current
    val batteryIntent = remember {
        context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
    }

    val level    = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale    = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
    val pct      = if (level >= 0) level * 100 / scale else 0
    val status   = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
    val plugged  = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) ?: 0
    val temp     = (batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val voltage  = (batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, 0) ?: 0)
    val techStr  = batteryIntent?.getStringExtra(android.os.BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown"
    val health   = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH,
        android.os.BatteryManager.BATTERY_HEALTH_UNKNOWN) ?: android.os.BatteryManager.BATTERY_HEALTH_UNKNOWN

    val healthStr = when (health) {
        android.os.BatteryManager.BATTERY_HEALTH_GOOD          -> "Good ✅"
        android.os.BatteryManager.BATTERY_HEALTH_OVERHEAT      -> "Overheating 🔥"
        android.os.BatteryManager.BATTERY_HEALTH_DEAD          -> "Dead 💀"
        android.os.BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE  -> "Over Voltage ⚡"
        android.os.BatteryManager.BATTERY_HEALTH_COLD          -> "Cold 🧊"
        else                                                    -> "Unknown ❓"
    }
    val statusStr = when (status) {
        android.os.BatteryManager.BATTERY_STATUS_CHARGING    -> "Charging 🔌"
        android.os.BatteryManager.BATTERY_STATUS_FULL        -> "Full ✅"
        android.os.BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        android.os.BatteryManager.BATTERY_STATUS_NOT_CHARGING-> "Not Charging"
        else -> "Unknown"
    }
    val plugStr = when (plugged) {
        android.os.BatteryManager.BATTERY_PLUGGED_AC    -> "AC Adapter"
        android.os.BatteryManager.BATTERY_PLUGGED_USB   -> "USB"
        android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Unplugged"
    }

    var capacityInfo by remember { mutableStateOf<String?>(null) }
    var shizukuCapacity by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        // Standard Android 14+ battery info
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                val cap = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
                val capacity = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                if (cap > 0) capacityInfo = "${cap / 1000} mAh remaining"
            } catch (_: Exception) {}
        }
        // Shizuku - read OEM battery health (dumpsys batterystats)
        try {
            if (com.coolappstore.everlastingandroidtweak.features.appfreezer.AppFreezerHelper.isShizukuReady()) {
                val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c", "dumpsys battery | grep -E 'level|health|temperature|voltage|status'"))
                val output = proc.inputStream.bufferedReader().readText()
                if (output.isNotBlank()) shizukuCapacity = output.trim()
                proc.waitFor()
            }
        } catch (_: Exception) {}
    }

    val tempColor = when {
        temp > 45f -> Color(0xFFF44336)
        temp > 35f -> Color(0xFFFF9800)
        else       -> Color(0xFF4CAF50)
    }

    Scaffold(topBar = { EverlastingTopBar("Battery Health", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            // Big battery indicator card
            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$pct%", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Black,
                        color = when {
                            pct <= 15 -> MaterialTheme.colorScheme.error
                            pct <= 30 -> MaterialTheme.colorScheme.tertiary
                            else      -> MaterialTheme.colorScheme.primary
                        })
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(12.dp).clip(CircleShape),
                        color = when {
                            pct <= 15 -> MaterialTheme.colorScheme.error
                            pct <= 30 -> MaterialTheme.colorScheme.tertiary
                            else      -> MaterialTheme.colorScheme.primary
                        },
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(statusStr, style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }

            // Stats grid
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Battery Details", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    listOf(
                        "Health" to healthStr,
                        "Temperature" to "${temp}°C",
                        "Voltage" to "${voltage} mV",
                        "Technology" to techStr,
                        "Power Source" to plugStr,
                        "Remaining Capacity" to (capacityInfo ?: "Requires Android 14+"),
                    "Shizuku Battery Data" to (shizukuCapacity?.take(80) ?: "Grant Shizuku for OEM health data")
                    ).forEach { (label, value) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(label, style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(value, style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (label == "Temperature") tempColor else MaterialTheme.colorScheme.onSurface)
                        }
                        if (label != "Remaining Capacity") HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    }
                }
            }

            InfoCard(Icons.Default.BatteryFull, "Keep Battery Healthy",
                "Stay between 20–80% charge, avoid overnight charging, and keep temperature below 35°C for maximum battery lifespan.", isError = false)
        }
    }
}

// ─── DEVICE INFO ─────────────────────────────────────────────────────────────
@Composable
fun DeviceInfoScreen(navController: NavController) {
    val context = LocalContext.current
    data class InfoItem(val label: String, val value: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

    val items = remember {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val memInfo = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val dm = context.resources.displayMetrics
        val battIntent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val battLevel = ((battIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100f /
                         (battIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100)).toInt()
        listOf(
            // Device
            InfoItem("Brand",           android.os.Build.BRAND.replaceFirstChar { it.uppercase() }, Icons.Default.PhoneAndroid),
            InfoItem("Model",           android.os.Build.MODEL, Icons.Default.PhoneAndroid),
            InfoItem("Manufacturer",    android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() }, Icons.Default.Business),
            InfoItem("Device",          android.os.Build.DEVICE, Icons.Default.Devices),
            InfoItem("Product",         android.os.Build.PRODUCT, Icons.Default.Label),
            InfoItem("Hardware",        android.os.Build.HARDWARE, Icons.Default.Memory),
            // Android
            InfoItem("Android Version", android.os.Build.VERSION.RELEASE, Icons.Default.Android),
            InfoItem("API Level",       android.os.Build.VERSION.SDK_INT.toString(), Icons.Default.Code),
            InfoItem("Security Patch",  android.os.Build.VERSION.SECURITY_PATCH, Icons.Default.Security),
            InfoItem("Build ID",        android.os.Build.ID, Icons.Default.Tag),
            InfoItem("Build Type",      android.os.Build.TYPE, Icons.Default.Build),
            InfoItem("Fingerprint",     android.os.Build.FINGERPRINT.take(50), Icons.Default.Fingerprint),
            // CPU
            InfoItem("CPU ABI",         android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown", Icons.Default.Memory),
            InfoItem("CPU Cores",       Runtime.getRuntime().availableProcessors().toString(), Icons.Default.Memory),
            InfoItem("Processor",       try { java.io.File("/proc/cpuinfo").readLines().firstOrNull { it.startsWith("Hardware") }?.substringAfter(":") ?.trim() ?: "Unknown" } catch (_: Exception) { "Unknown" }, Icons.Default.Memory),
            // RAM
            InfoItem("Total RAM",       "${memInfo.totalMem / 1024 / 1024} MB", Icons.Default.Storage),
            InfoItem("Available RAM",   "${memInfo.availMem / 1024 / 1024} MB", Icons.Default.Storage),
            InfoItem("Low RAM Device",  if (memInfo.lowMemory) "Yes" else "No", Icons.Default.Warning),
            // Display
            InfoItem("Resolution",      "${dm.widthPixels} × ${dm.heightPixels}", Icons.Default.AspectRatio),
            InfoItem("Density",         "${dm.densityDpi} dpi (${dm.density}x)", Icons.Default.BlurOn),
            InfoItem("Screen Size",     "${String.format("%.1f", kotlin.math.sqrt((dm.widthPixels.toDouble() / dm.xdpi).let { it * it } + (dm.heightPixels.toDouble() / dm.ydpi).let { it * it }))}\"", Icons.Default.AspectRatio),
            InfoItem("Refresh Rate",    try { "${context.display?.refreshRate?.toInt() ?: 60} Hz" } catch (_: Exception) { "60 Hz" }, Icons.Default.Speed),
            // Battery
            InfoItem("Battery Level",   "$battLevel%", Icons.Default.BatteryFull),
            InfoItem("Battery Voltage", "${(battIntent?.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, 0) ?: 0)} mV", Icons.Default.ElectricBolt),
            InfoItem("Battery Temp",    "${((battIntent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f)}°C", Icons.Default.Thermostat),
            InfoItem("Battery Tech",    battIntent?.getStringExtra(android.os.BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown", Icons.Default.BatteryFull),
            // Network
            InfoItem("Bootloader",      android.os.Build.BOOTLOADER, Icons.Default.Settings),
            InfoItem("Kernel",          try { java.io.File("/proc/version").readText().take(60) } catch (_: Exception) { "Unknown" }, Icons.Default.Terminal),
        )
    }

    val clipService = context.getSystemService(android.content.ClipboardManager::class.java)

    Scaffold(topBar = {
        EverlastingTopBar("Device Info", navController, actions = {
            IconButton(onClick = {
                val text = items.joinToString("\n") { "${it.label}: ${it.value}" }
                clipService?.setPrimaryClip(android.content.ClipData.newPlainText("Device Info", text))
                android.widget.Toast.makeText(context, "Copied!", android.widget.Toast.LENGTH_SHORT).show()
            }) { Icon(Icons.Default.ContentCopy, "Copy all") }
        })
    }) { padding ->
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val groups = items.chunked(1)
            // Group into cards of related items
            val sections = listOf(
                "Device" to items.take(6),
                "Android" to items.drop(6).take(6),
                "CPU" to items.drop(12).take(3),
                "Memory" to items.drop(15).take(3),
                "Display" to items.drop(18).take(4),
                "Battery" to items.drop(22).take(4),
                "System" to items.drop(26)
            )
            items(sections.size) { si ->
                val (title, sectionItems) = sections[si]
                Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column {
                        sectionItems.forEachIndexed { idx, item ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(item.icon, null, tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.label, style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(item.value, style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium)
                                }
                            }
                            if (idx < sectionItems.lastIndex)
                                HorizontalDivider(Modifier.padding(horizontal = 16.dp),
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        }
                    }
                }
            }
        }
    }
}

// ─── FLASH ISO (USB) ─────────────────────────────────────────────────────────
@Composable
fun FlashIsoScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var usbDevices by remember { mutableStateOf<List<String>>(emptyList()) }
    var statusMsg by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf("") }
    var isFlashing by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { selectedFile = it.toString() }
    }

    // Detect USB OTG devices
    LaunchedEffect(Unit) {
        try {
            val usbManager = context.getSystemService(android.hardware.usb.UsbManager::class.java)
            val devices = usbManager?.deviceList?.values?.map {
                "USB: ${it.manufacturerName ?: "Unknown"} — ${it.productName ?: "Device ${it.deviceId}"}"
            } ?: emptyList()
            usbDevices = devices.ifEmpty { listOf("No USB devices detected") }
        } catch (_: Exception) {
            usbDevices = listOf("No USB devices detected")
        }
    }

    Scaffold(topBar = { EverlastingTopBar("Flash ISO / USB", navController) }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            Card(Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("💾", style = MaterialTheme.typography.displaySmall)
                        Column {
                            Text("Flash ISO to USB", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Flash bootable images (ISO/IMG) to USB drives via OTG",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                        }
                    }
                }
            }

            // USB devices
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Connected USB Devices", style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(onClick = {
                            scope.launch {
                                try {
                                    val usbManager = context.getSystemService(android.hardware.usb.UsbManager::class.java)
                                    val devices = usbManager?.deviceList?.values?.map {
                                        "USB: ${it.manufacturerName ?: "Unknown"} — ${it.productName ?: "Device ${it.deviceId}"}"
                                    } ?: emptyList()
                                    usbDevices = devices.ifEmpty { listOf("No USB devices detected") }
                                } catch (_: Exception) {}
                            }
                        }) { Icon(Icons.Default.Refresh, null) }
                    }
                    usbDevices.forEach { dev ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Usb, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(dev, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            // File selection
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select ISO / IMG File", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    if (selectedFile.isNotEmpty()) {
                        Text(android.net.Uri.parse(selectedFile).lastPathSegment ?: "Selected",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    FilledTonalButton(onClick = { filePicker.launch(arrayOf("application/octet-stream", "application/x-iso9660-image", "*/*")) },
                        modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Browse Files")
                    }
                }
            }

            // Flash button
            if (selectedFile.isNotEmpty() && usbDevices.any { !it.contains("No USB") }) {
                Button(onClick = {
                    isFlashing = true
                    statusMsg = "Flashing requires root or ADB. Use with Shizuku: dd if=<iso> of=/dev/block/sdX"
                    isFlashing = false
                }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    enabled = !isFlashing) {
                    Icon(Icons.Default.FlashOn, null); Spacer(Modifier.width(6.dp))
                    Text("Flash to USB")
                }
            }

            if (statusMsg.isNotEmpty()) {
                InfoCard(Icons.Default.Info, "Status", statusMsg, isError = false)
            }

            InfoCard(Icons.Default.Warning, "Requirements",
                "Flashing ISO files requires either root access or ADB. Connect a USB OTG drive, select your ISO file, then flash. This writes directly to the USB block device.",
                isError = true)

            // dd command helper
            if (selectedFile.isNotEmpty()) {
                val ddCmd = "dd if=/sdcard/your.iso of=/dev/block/sda bs=4M status=progress"
                val clipSvc = context.getSystemService(android.content.ClipboardManager::class.java)
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clickable {
                    clipSvc?.setPrimaryClip(android.content.ClipData.newPlainText("dd", ddCmd))
                    android.widget.Toast.makeText(context, "Copied!", android.widget.Toast.LENGTH_SHORT).show()
                }, shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("ADB/Root command (tap to copy):", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(ddCmd, style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
