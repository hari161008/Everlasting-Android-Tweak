package com.coolappstore.everlastingandroidtweak.features.appfreezer

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

class AppFreezerHelper {
    companion object {
        fun isShizukuReady(): Boolean = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }

        fun freezeApp(packageName: String): Boolean = try {
            // Use adb shell via Runtime — works with Shizuku-granted shell access
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "pm disable-user --user 0 $packageName"))
            p.waitFor() == 0
        } catch (_: Exception) { false }

        fun unfreezeApp(packageName: String): Boolean = try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "pm enable $packageName"))
            p.waitFor() == 0
        } catch (_: Exception) { false }

        fun getUserApps(context: Context): List<ApplicationInfo> =
            context.packageManager
                .getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
                .sortedBy { context.packageManager.getApplicationLabel(it).toString() }
    }
}
