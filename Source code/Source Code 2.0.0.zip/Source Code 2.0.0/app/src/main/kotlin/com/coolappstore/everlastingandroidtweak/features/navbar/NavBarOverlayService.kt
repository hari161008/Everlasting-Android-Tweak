package com.coolappstore.everlastingandroidtweak.features.navbar

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class NavBarOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        const val ACTION_STOP = "action_stop_navbar"

        fun start(context: android.content.Context) {
            if (!Settings.canDrawOverlays(context)) return
            context.startService(Intent(context, NavBarOverlayService::class.java))
        }

        fun stop(context: android.content.Context) {
            // Send stop action first so overlay is removed immediately
            context.startService(Intent(context, NavBarOverlayService::class.java).apply {
                action = ACTION_STOP
            })
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            removeOverlay()
            stopSelf()
            return START_NOT_STICKY
        }
        scope.launch { showOverlay() }
        return START_STICKY
    }

    private suspend fun showOverlay() {
        removeOverlay()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        val style        = AppPreferences.get(AppPreferences.NAVBAR_STYLE, "Minimal Pill").first()
        val pillColorHex = AppPreferences.get(AppPreferences.NAVBAR_PILL_COLOR, "#FFFFFF").first()
        val pillOpacity  = AppPreferences.get(AppPreferences.NAVBAR_PILL_OPACITY, 0.8f).first()
        val thicknessDp  = AppPreferences.get(AppPreferences.NAVBAR_HEIGHT, 48f).first()
        val xPos         = AppPreferences.get(AppPreferences.NAVBAR_X_POSITION, 0f).first()
        val yPos         = AppPreferences.get(AppPreferences.NAVBAR_Y_POSITION, 0f).first()

        val pillColor   = parsePillColor(pillColorHex, pillOpacity)
        val thicknessPx = dpToPx(thicknessDp.coerceIn(8f, 200f))
        val view        = buildNavView(style, pillColor, thicknessPx)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            thicknessPx,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            x = xPos.toInt()
            y = yPos.toInt()
        }

        // Full-width styles
        if (style == "Colored" || style == "Gradient" || style == "Neon Glow") {
            params.width = WindowManager.LayoutParams.MATCH_PARENT
        }

        overlayView = view
        try { windowManager?.addView(view, params) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun buildNavView(style: String, pillColor: Int, thicknessPx: Int): View = when (style) {
        "Minimal Pill"    -> buildMinimalPill(pillColor, thicknessPx)
        "Blurred Pill"    -> buildBlurredPill(pillColor, thicknessPx)
        "Colored"         -> buildColoredBar(pillColor)
        "Classic Buttons" -> buildClassicButtons(pillColor, thicknessPx)
        "Gradient"        -> buildGradientBar(pillColor)
        "Neon Glow"       -> buildNeonGlow(pillColor, thicknessPx)
        "Dot Indicators"  -> buildDotIndicators(pillColor, thicknessPx)
        else              -> buildMinimalPill(pillColor, thicknessPx)
    }

    private fun buildColoredBar(color: Int): View = View(this).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; setColor(color); cornerRadius = dpToPx(8f).toFloat() }
    }

    private fun buildMinimalPill(pillColor: Int, thicknessPx: Int): View {
        val container = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val pillH = (thicknessPx * 0.35f).toInt().coerceAtLeast(dpToPx(4f))
        container.addView(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = 100f; setColor(pillColor) }
            layoutParams = LinearLayout.LayoutParams(dpToPx(134f), pillH)
        })
        return container
    }

    private fun buildBlurredPill(pillColor: Int, thicknessPx: Int): View {
        val container = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val pillH = (thicknessPx * 0.35f).toInt().coerceAtLeast(dpToPx(4f))
        container.addView(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = 100f; setColor(pillColor) }
            layoutParams = LinearLayout.LayoutParams(dpToPx(134f), pillH)
            elevation = 8f
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                setRenderEffect(android.graphics.RenderEffect.createBlurEffect(6f, 6f, android.graphics.Shader.TileMode.CLAMP))
            }
        })
        return container
    }

    private fun buildClassicButtons(pillColor: Int, thicknessPx: Int): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; setColor(Color.argb(60, 0, 0, 0)); cornerRadius = dpToPx(12f).toFloat() }
        }
        val btnW = dpToPx(56f)
        listOf("◀" to "Back", "●" to "Home", "■" to "Recent").forEach { (sym, _) ->
            container.addView(TextView(this).apply {
                text = sym; textSize = 20f; setTextColor(pillColor); gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(btnW, thicknessPx)
            })
        }
        return container
    }

    private fun buildGradientBar(pillColor: Int): View = View(this).apply {
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.TRANSPARENT, pillColor, Color.TRANSPARENT))
    }

    private fun buildNeonGlow(pillColor: Int, thicknessPx: Int): View {
        val container = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        container.addView(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = 100f; setColor(pillColor) }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                (thicknessPx * 0.2f).toInt().coerceAtLeast(dpToPx(3f)))
            elevation = 12f
        })
        return container
    }

    private fun buildDotIndicators(pillColor: Int, thicknessPx: Int): View {
        val container = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val dotSize = (thicknessPx * 0.45f).toInt().coerceIn(dpToPx(6f), dpToPx(18f))
        repeat(3) { i ->
            container.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(if (i == 1) 255 else 130, Color.red(pillColor), Color.green(pillColor), Color.blue(pillColor))) }
                layoutParams = LinearLayout.LayoutParams(dotSize, dotSize).apply { if (i > 0) leftMargin = dpToPx(16f) }
            })
        }
        return container
    }

    private fun parsePillColor(hex: String, opacity: Float): Int = try {
        val base = Color.parseColor(hex); val alpha = (opacity * 255).toInt().coerceIn(0, 255)
        Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base))
    } catch (_: Exception) { Color.argb(204, 255, 255, 255) }

    private fun dpToPx(dp: Float): Int = (dp * resources.displayMetrics.density).toInt()

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    override fun onDestroy() { super.onDestroy(); scope.cancel(); removeOverlay() }
    override fun onBind(intent: Intent?): IBinder? = null
}
