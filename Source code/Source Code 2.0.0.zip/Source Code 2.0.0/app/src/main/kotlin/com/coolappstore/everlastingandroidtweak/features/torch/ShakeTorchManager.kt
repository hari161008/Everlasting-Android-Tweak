package com.coolappstore.everlastingandroidtweak.features.torch

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.VibratorManager
import kotlin.math.sqrt

class ShakeTorchManager(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val vibrator = (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    private val accelerometer  = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private val handler = Handler(Looper.getMainLooper())

    private var lastX = 0f; private var lastY = 0f; private var lastZ = 0f
    private var lastShakeTime = 0L
    private var torchOn = false
    private var sensitivity = 12f
    private var _proximityEnabled = false
    private var proximityRegistered = false
    private var proximityBlocked = false

    var isRunning = false; private set

    private val proximityListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_PROXIMITY)
                proximityBlocked = event.values[0] >= event.sensor.maximumRange
        }
        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    }

    private fun checkProximityThenTorch() {
        if (!_proximityEnabled || proximitySensor == null) { toggleTorch(); return }
        proximityBlocked = false
        sensorManager.registerListener(proximityListener, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
        proximityRegistered = true
        handler.postDelayed({
            if (proximityRegistered) { sensorManager.unregisterListener(proximityListener); proximityRegistered = false }
            if (!proximityBlocked) toggleTorch()
            proximityBlocked = false
        }, 200L)
    }

    fun setSensitivity(value: Float) { sensitivity = value }
    fun setProximityEnabled(enabled: Boolean) { _proximityEnabled = enabled }

    fun start() {
        if (isRunning) return
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        isRunning = true
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        if (proximityRegistered) { sensorManager.unregisterListener(proximityListener); proximityRegistered = false }
        handler.removeCallbacksAndMessages(null)
        isRunning = false
        if (torchOn) toggleTorch()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
        val delta = sqrt((x-lastX)*(x-lastX) + (y-lastY)*(y-lastY) + (z-lastZ)*(z-lastZ))
        lastX = x; lastY = y; lastZ = z
        val now = System.currentTimeMillis()
        if (delta > sensitivity && now - lastShakeTime > 800L) {
            lastShakeTime = now
            // Vibrate on shake detection (short feedback)
            runCatching {
                vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            }
            checkProximityThenTorch()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}

    private fun toggleTorch() {
        try {
            val id = cameraManager.cameraIdList.firstOrNull {
                cameraManager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cameraManager.setTorchMode(id, torchOn)
            // Double vibration = torch ON, single = torch OFF
            runCatching {
                val pattern = if (torchOn) longArrayOf(0, 40, 60, 40) else longArrayOf(0, 80)
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    fun isTorchOn() = torchOn
}
