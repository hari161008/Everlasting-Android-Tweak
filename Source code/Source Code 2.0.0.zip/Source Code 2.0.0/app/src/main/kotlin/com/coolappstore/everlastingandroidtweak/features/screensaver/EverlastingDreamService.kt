package com.coolappstore.everlastingandroidtweak.features.screensaver

import android.animation.*
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.service.dreams.DreamService
import android.view.*
import android.widget.FrameLayout
import android.widget.TextClock
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import kotlin.math.*
import kotlin.random.Random

class EverlastingDreamService : DreamService() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())
    private var moveRunnable: Runnable? = null
    private var animators = mutableListOf<Animator>()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        scope.launch { setup() }
    }

    private suspend fun setup() {
        val theme       = AppPreferences.get(AppPreferences.SCREENSAVER_THEME, "Clock").first()
        val colorHex    = AppPreferences.get(AppPreferences.SCREENSAVER_COLOR, "#FFFFFF").first()
        val size        = AppPreferences.get(AppPreferences.SCREENSAVER_SIZE, 1.0f).first()
        val fadeDuration= AppPreferences.get(AppPreferences.SCREENSAVER_FADE_DURATION, 0).first()
        val moveEnabled = AppPreferences.get(AppPreferences.SCREENSAVER_MOVE_ENABLED, false).first()
        val moveSpeed   = AppPreferences.get(AppPreferences.SCREENSAVER_MOVE_SPEED, 3).first()

        val primaryColor = try { Color.parseColor(colorHex) } catch (_: Exception) { Color.WHITE }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val contentView: View = when (theme) {
            "Floating Clock" -> buildFloatingClock(primaryColor, size)
            "Digital Rain"   -> buildDigitalRainView(primaryColor, size)
            "Bubbles"        -> buildBubblesView(primaryColor, size)
            "Starfield"      -> buildStarfieldView(primaryColor)
            "Color Wave"     -> buildColorWaveView(primaryColor)
            "Minimal Clock"  -> buildMinimalClock(primaryColor, size)
            else             -> buildClock(primaryColor, size)  // "Clock"
        }

        // Fade in
        if (fadeDuration > 0) {
            contentView.alpha = 0f
            contentView.animate().alpha(1f).setDuration(fadeDuration.toLong()).start()
        }

        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER }

        root.addView(contentView, lp)
        setContentView(root)

        // Burn-in protection: slowly drift content around screen
        if (moveEnabled) {
            startBurnInProtection(contentView, moveSpeed)
        }
    }

    // ─── Screensaver themes ───────────────────────────────────────────────────

    private fun buildClock(color: Int, size: Float): View {
        return TextClock(this).apply {
            format12Hour = "hh:mm\naa"
            format24Hour = "HH:mm"
            textSize = (80 * size).coerceIn(24f, 200f)
            setTextColor(color)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
    }

    private fun buildMinimalClock(color: Int, size: Float): View {
        val container = FrameLayout(this)
        val clock = TextClock(this).apply {
            format12Hour = "hh:mm"
            format24Hour = "HH:mm"
            textSize = (72 * size).coerceIn(24f, 180f)
            setTextColor(color)
            gravity = Gravity.CENTER
            paint.apply {
                isAntiAlias = true
                letterSpacing = 0.1f
            }
        }
        val date = TextClock(this).apply {
            format12Hour = "EEE, MMM d"
            format24Hour = "EEE, MMM d"
            textSize = (18 * size).coerceIn(10f, 48f)
            setTextColor(Color.argb(180, Color.red(color), Color.green(color), Color.blue(color)))
            gravity = Gravity.CENTER
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (100 * size).toInt(); gravity = Gravity.CENTER }
            layoutParams = lp
        }
        container.addView(clock)
        container.addView(date)
        return container
    }

    private fun buildFloatingClock(color: Int, size: Float): View {
        return TextClock(this).apply {
            format12Hour = "hh:mm"
            format24Hour = "HH:mm"
            textSize = (64 * size).coerceIn(24f, 160f)
            setTextColor(color)
            gravity = Gravity.CENTER
        }
    }

    private fun buildDigitalRainView(color: Int, size: Float): View {
        val baseColor = color
        return object : View(this) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
            private val cols = mutableListOf<DigitalRainColumn>()
            private val charset = "アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEF"
            private var initialized = false
            private val rnd = Random.Default
            private val frameRunnable = object : Runnable {
                override fun run() { invalidate(); handler.postDelayed(this, (80 / size.coerceIn(0.5f, 3f)).toLong().coerceIn(30L, 150L)) }
            }

            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                val charSize = (16 * size).coerceIn(8f, 40f)
                paint.textSize = charSize
                val colCount = (w / charSize).toInt().coerceAtLeast(1)
                cols.clear()
                repeat(colCount) { i ->
                    cols.add(DigitalRainColumn(i * charSize, h.toFloat(), charSize, charset, rnd))
                }
                initialized = true
                handler.post(frameRunnable)
            }

            override fun onDraw(canvas: Canvas) {
                canvas.drawColor(Color.argb(40, 0, 0, 0))
                if (!initialized) return
                cols.forEach { col ->
                    col.update()
                    col.draw(canvas, paint, baseColor)
                }
            }

            override fun onDetachedFromWindow() {
                super.onDetachedFromWindow()
                handler.removeCallbacks(frameRunnable)
            }
        }.apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
    }

    private fun buildBubblesView(color: Int, size: Float): View {
        return object : View(this) {
            private val bubbles = mutableListOf<Bubble>()
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            private val rnd = Random.Default
            private val frameRunnable = object : Runnable {
                override fun run() { invalidate(); handler.postDelayed(this, 32) }
            }

            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                bubbles.clear()
                repeat(18) { bubbles.add(Bubble.random(w.toFloat(), h.toFloat(), color, size, rnd)) }
                handler.post(frameRunnable)
            }

            override fun onDraw(canvas: Canvas) {
                canvas.drawColor(Color.BLACK)
                bubbles.forEach { b ->
                    b.update(width.toFloat(), height.toFloat())
                    paint.color = b.currentColor
                    paint.alpha = b.alpha
                    canvas.drawCircle(b.x, b.y, b.r, paint)
                    // Outline
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2f
                    paint.alpha = (b.alpha * 0.4f).toInt()
                    canvas.drawCircle(b.x, b.y, b.r, paint)
                    paint.style = Paint.Style.FILL
                }
            }

            override fun onDetachedFromWindow() {
                super.onDetachedFromWindow()
                handler.removeCallbacks(frameRunnable)
            }
        }.apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
    }

    private fun buildStarfieldView(color: Int): View {
        return object : View(this) {
            private val stars = mutableListOf<Star>()
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            private var cx = 0f; private var cy = 0f
            private val rnd = Random.Default
            private val frameRunnable = object : Runnable {
                override fun run() { invalidate(); handler.postDelayed(this, 16) }
            }

            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                cx = w / 2f; cy = h / 2f
                stars.clear()
                repeat(150) { stars.add(Star.random(cx, cy, color, rnd)) }
                handler.post(frameRunnable)
            }

            override fun onDraw(canvas: Canvas) {
                canvas.drawColor(Color.BLACK)
                stars.forEach { s ->
                    s.update(cx, cy)
                    paint.color = s.color
                    paint.alpha = s.alpha
                    canvas.drawCircle(s.sx, s.sy, s.size, paint)
                }
            }

            override fun onDetachedFromWindow() {
                super.onDetachedFromWindow()
                handler.removeCallbacks(frameRunnable)
            }
        }.apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
    }

    private fun buildColorWaveView(baseColor: Int): View {
        return object : View(this) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            private var phase = 0f
            private val frameRunnable = object : Runnable {
                override fun run() { phase += 0.03f; invalidate(); handler.postDelayed(this, 32) }
            }

            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                handler.post(frameRunnable)
            }

            override fun onDraw(canvas: Canvas) {
                canvas.drawColor(Color.BLACK)
                val w = width.toFloat(); val h = height.toFloat()
                val waveCount = 3
                for (waveIdx in 0 until waveCount) {
                    val alpha = (160 - waveIdx * 40).coerceAtLeast(40)
                    val amp = h * (0.15f - waveIdx * 0.03f)
                    val freq = 2f + waveIdx * 0.5f
                    val offset = phase + waveIdx * 1.2f

                    val baseHsv = FloatArray(3)
                    Color.RGBToHSV(Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor), baseHsv)
                    val hue = (baseHsv[0] + waveIdx * 30f) % 360f
                    paint.color = Color.HSVToColor(alpha, floatArrayOf(hue, 0.7f, 0.9f))

                    val path = Path()
                    val steps = 80
                    for (i in 0..steps) {
                        val x = w * i / steps
                        val y = h / 2 + amp * sin(freq * Math.PI.toFloat() * x / w + offset)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.lineTo(w, h); path.lineTo(0f, h); path.close()
                    canvas.drawPath(path, paint)
                }
            }

            override fun onDetachedFromWindow() {
                super.onDetachedFromWindow()
                handler.removeCallbacks(frameRunnable)
            }
        }.apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
    }

    // ─── Burn-in protection: move content slowly ──────────────────────────────

    private fun startBurnInProtection(view: View, speed: Int) {
        val maxOffset = 80
        val stepMs = (3000L / speed.coerceIn(1, 10))
        var targetX = 0f; var targetY = 0f

        moveRunnable = object : Runnable {
            override fun run() {
                val rnd = Random.Default
                targetX = (rnd.nextFloat() * 2 - 1) * maxOffset
                targetY = (rnd.nextFloat() * 2 - 1) * maxOffset
                view.animate()
                    .translationX(targetX)
                    .translationY(targetY)
                    .setDuration(stepMs)
                    .setInterpolator(android.view.animation.AccelerateDecelerateInterpolator())
                    .withEndAction { handler.postDelayed(this, stepMs) }
                    .start()
            }
        }
        handler.postDelayed(moveRunnable!!, stepMs)
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        scope.cancel()
        moveRunnable?.let { handler.removeCallbacks(it) }
        animators.forEach { it.cancel() }
    }

    // ─── Data classes for animation ───────────────────────────────────────────

    private class DigitalRainColumn(
        val x: Float, val height: Float, val charSize: Float,
        val charset: String, val rnd: Random
    ) {
        private var y = rnd.nextFloat() * -height
        private val speed = charSize * (0.5f + rnd.nextFloat() * 1.5f)
        private val length = (5 + rnd.nextInt(20))
        private val chars = Array(length) { charset[rnd.nextInt(charset.length)] }

        fun update() {
            y += speed * 0.5f
            if (y > height + charSize * length) y = rnd.nextFloat() * -height
            if (rnd.nextInt(8) == 0) chars[rnd.nextInt(chars.size)] = charset[rnd.nextInt(charset.length)]
        }

        fun draw(canvas: Canvas, paint: Paint, baseColor: Int) {
            chars.forEachIndexed { i, char ->
                val cy = y + i * charSize
                if (cy < 0 || cy > height) return@forEachIndexed
                val brightness = 1f - i.toFloat() / length
                paint.color = Color.argb(
                    (brightness * 255).toInt(),
                    Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor)
                )
                canvas.drawText(char.toString(), x, cy, paint)
            }
        }
    }

    private class Bubble(
        var x: Float, var y: Float, var r: Float,
        var speedX: Float, var speedY: Float,
        val baseColor: Int, var alpha: Int, val rnd: Random
    ) {
        var currentColor: Int = baseColor
        private var colorPhase = rnd.nextFloat() * Math.PI.toFloat() * 2

        fun update(w: Float, h: Float) {
            x += speedX; y += speedY
            colorPhase += 0.03f
            val a = ((sin(colorPhase) * 0.5f + 0.5f) * 200 + 40).toInt()
            val hsv = FloatArray(3)
            Color.RGBToHSV(Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor), hsv)
            hsv[0] = (hsv[0] + 0.5f) % 360f
            currentColor = Color.HSVToColor(hsv)
            alpha = a
            if (x - r < 0 || x + r > w) speedX = -speedX
            if (y - r < 0 || y + r > h) speedY = -speedY
        }

        companion object {
            fun random(w: Float, h: Float, color: Int, size: Float, rnd: Random): Bubble {
                val r = (20 + rnd.nextFloat() * 60) * size.coerceIn(0.5f, 3f)
                return Bubble(
                    x = r + rnd.nextFloat() * (w - 2 * r),
                    y = r + rnd.nextFloat() * (h - 2 * r),
                    r = r,
                    speedX = (rnd.nextFloat() * 2 - 1) * 2f,
                    speedY = (rnd.nextFloat() * 2 - 1) * 2f,
                    baseColor = color, alpha = 180, rnd = rnd
                )
            }
        }
    }

    private class Star(
        var x: Float, var y: Float, val cx: Float, val cy: Float,
        val speed: Float, val color: Int, val rnd: Random
    ) {
        var sx = 0f; var sy = 0f; var size = 1f; var alpha = 0
        private val angle = atan2(y - cy, x - cx)
        private var dist = sqrt((x - cx).pow(2) + (y - cy).pow(2))

        fun update(cx: Float, cy: Float) {
            dist += speed
            val nx = cx + cos(angle) * dist
            val ny = cy + sin(angle) * dist
            sx = nx; sy = ny
            size = (dist / 500f * 4f).coerceIn(0.5f, 5f)
            alpha = ((dist / 400f) * 255).toInt().coerceIn(0, 255)
        }

        fun isOffScreen(w: Float, h: Float) = sx < 0 || sx > w || sy < 0 || sy > h

        companion object {
            fun random(cx: Float, cy: Float, color: Int, rnd: Random): Star {
                val angle = rnd.nextFloat() * 2 * Math.PI.toFloat()
                val dist = rnd.nextFloat() * 50f
                return Star(
                    x = cx + cos(angle) * dist,
                    y = cy + sin(angle) * dist,
                    cx = cx, cy = cy,
                    speed = 0.5f + rnd.nextFloat() * 2f,
                    color = color, rnd = rnd
                )
            }
        }
    }
}
