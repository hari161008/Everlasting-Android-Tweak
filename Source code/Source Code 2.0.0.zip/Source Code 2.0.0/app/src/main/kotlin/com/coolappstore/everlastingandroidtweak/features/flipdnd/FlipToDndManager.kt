package com.coolappstore.everlastingandroidtweak.features.flipdnd

import android.app.NotificationManager
import android.content.Context
import android.hardware.*

class FlipToDndManager(private val context: Context) : SensorEventListener {
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private var running = false; private var wasFaceDown = false
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val faceDown = event.values[2] < -7f
            if (faceDown && !wasFaceDown && nm.isNotificationPolicyAccessGranted)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            else if (!faceDown && wasFaceDown && nm.isNotificationPolicyAccessGranted)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            wasFaceDown = faceDown
        }
    }
    fun start() { if (running) return; sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }; running = true }
    fun stop()  { if (!running) return; sm.unregisterListener(this); running = false }
    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
}
