package com.coolappstore.everlastingandroidtweak.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.ui.components.EverlastingTopBar
import com.coolappstore.everlastingandroidtweak.utils.PermissionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val dynamicColor   by AppPreferences.get(AppPreferences.DYNAMIC_COLOR, true).collectAsState(true)
    val darkTheme      by AppPreferences.get(AppPreferences.DARK_THEME, 0).collectAsState(0)
    val uiBlur         by AppPreferences.get(AppPreferences.UI_BLUR_ENABLED, false).collectAsState(false)
    val uiBlurAmount   by AppPreferences.get(AppPreferences.UI_BLUR_AMOUNT, 16f).collectAsState(16f)
    val customPrimary  by AppPreferences.get(AppPreferences.CUSTOM_PRIMARY_COLOR, "").collectAsState("")
    val bgUri          by AppPreferences.get(AppPreferences.BG_WALLPAPER_URI, "").collectAsState("")
    val bgDim          by AppPreferences.get(AppPreferences.BG_DIM_AMOUNT, 0f).collectAsState(0f)
    val bgBlur         by AppPreferences.get(AppPreferences.BG_BLUR_ENABLED, false).collectAsState(false)
    val bgBlurAmount   by AppPreferences.get(AppPreferences.BG_BLUR_AMOUNT, 16f).collectAsState(16f)
    val useDeviceWp    by AppPreferences.get(AppPreferences.USE_DEVICE_WALLPAPER, false).collectAsState(false)
    val useEmojiIcons  by AppPreferences.get(AppPreferences.USE_EMOJI_ICONS, true).collectAsState(true)
    val autoUpdate     by AppPreferences.get(AppPreferences.AUTO_UPDATE_ENABLED, false).collectAsState(false)
    val updateInterval by AppPreferences.get(AppPreferences.AUTO_UPDATE_INTERVAL_HOURS, 24).collectAsState(24)
    var bgDimVal       by remember { mutableFloatStateOf(0f) }
    var bgBlurVal      by remember { mutableFloatStateOf(16f) }
    var uiBlurVal      by remember { mutableFloatStateOf(16f) }
    LaunchedEffect(bgDim)      { bgDimVal = bgDim }
    LaunchedEffect(bgBlurAmount) { bgBlurVal = bgBlurAmount }
    LaunchedEffect(uiBlurAmount) { uiBlurVal = uiBlurAmount }

    var grantedCamera        by remember { mutableStateOf(PermissionManager.hasCamera(context)) }
    var grantedAudio         by remember { mutableStateOf(PermissionManager.hasRecordAudio(context)) }
    var grantedNotifications by remember { mutableStateOf(PermissionManager.hasPostNotifications(context)) }
    var grantedMedia         by remember { mutableStateOf(PermissionManager.hasReadMediaImages(context)) }
    var grantedAccessibility by remember { mutableStateOf(PermissionManager.isAccessibilityEnabled(context)) }
    var grantedOverlay       by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    var grantedNotifListener by remember { mutableStateOf(PermissionManager.isNotificationListenerEnabled(context)) }
    var grantedUsageStats    by remember { mutableStateOf(PermissionManager.hasUsageStatsPermission(context)) }
    var grantedAlarm         by remember { mutableStateOf(PermissionManager.hasExactAlarmPermission(context)) }
    var checkingUpdate       by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                grantedCamera        = PermissionManager.hasCamera(context)
                grantedAudio         = PermissionManager.hasRecordAudio(context)
                grantedNotifications = PermissionManager.hasPostNotifications(context)
                grantedMedia         = PermissionManager.hasReadMediaImages(context)
                grantedAccessibility = PermissionManager.isAccessibilityEnabled(context)
                grantedOverlay       = PermissionManager.hasOverlayPermission(context)
                grantedNotifListener = PermissionManager.isNotificationListenerEnabled(context)
                grantedUsageStats    = PermissionManager.hasUsageStatsPermission(context)
                grantedAlarm         = PermissionManager.hasExactAlarmPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        grantedCamera        = PermissionManager.hasCamera(context)
        grantedAudio         = PermissionManager.hasRecordAudio(context)
        grantedNotifications = PermissionManager.hasPostNotifications(context)
        grantedMedia         = PermissionManager.hasReadMediaImages(context)
    }

    val grantedCount = listOf(grantedCamera, grantedAudio, grantedNotifications, grantedMedia,
        grantedAccessibility, grantedOverlay).count { it }

    // Background picker
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { selectedUri ->
            try { context.contentResolver.takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            scope.launch(Dispatchers.IO) {
                try {
                    val inp = context.contentResolver.openInputStream(selectedUri)
                    val dest = java.io.File(context.filesDir, "bg_wallpaper.jpg")
                    inp?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                    val fileUri = androidx.core.content.FileProvider.getUriForFile(context, context.packageName + ".provider", dest)
                    AppPreferences.set(AppPreferences.BG_WALLPAPER_URI, fileUri.toString())
                    AppPreferences.set(AppPreferences.USE_DEVICE_WALLPAPER, false)
                } catch (_: Exception) {
                    AppPreferences.set(AppPreferences.BG_WALLPAPER_URI, selectedUri.toString())
                }
            }
        }
    }

    // Backup
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let {
            scope.launch(Dispatchers.IO) {
                try {
                    val backup = buildString {
                        append("{\"app\":\"EverlastingTweak\",\"version\":\"2.0.0\",\"date\":\"${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())}\"}")
                    }
                    context.contentResolver.openOutputStream(it)?.use { out -> out.write(backup.toByteArray()) }
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "Backup saved!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Exception) {}
            }
        }
    }

    Scaffold { innerPadding ->
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(top = innerPadding.calculateTopPadding())) {

        // ── HERO HEADER ──────────────────────────────────────────────────────
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            shape = MaterialTheme.shapes.extraLarge,
            elevation = CardDefaults.cardElevation(0.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.size(50.dp).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center) {
                        Text("✨", fontSize = 26.sp)
                    }
                    Column {
                        Text("Everlasting Tweak", fontWeight = FontWeight.Black, fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface)
                        Text("Android Enhancement Suite", fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("v2.0.0 · Made By Hari ❤️", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/hariprabhu1008")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            })
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("$grantedCount / 6 permissions", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (grantedCount == 6) "All granted ✓" else "Tap to fix", fontSize = 12.sp,
                        color = if (grantedCount == 6) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { grantedCount / 6f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                )
            }
        }

        // ── CHECK FOR UPDATES (outside container) ────────────────────────────
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable {
                checkingUpdate = true
                scope.launch {
                    try {
                        val result = com.coolappstore.everlastingandroidtweak.features.appupdater.AppUpdaterHelper.checkSelfUpdate(context)
                        if (result?.hasUpdate == true) {
                            android.widget.Toast.makeText(context, "Update v${result.latestVersion} available!", android.widget.Toast.LENGTH_LONG).show()
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/hari161008/Everlasting-Android-Tweak/releases/latest")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } else android.widget.Toast.makeText(context, "You're up to date ✓", android.widget.Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) { android.widget.Toast.makeText(context, "Check failed", android.widget.Toast.LENGTH_SHORT).show() }
                    checkingUpdate = false
                }
            }, shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(Color(0xFF4CAF50).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center) {
                    if (checkingUpdate) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.SystemUpdateAlt, null, tint = Color(0xFF4CAF50), modifier = Modifier.size(22.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("Check for Updates", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text("Tap to check · Goes to releases page if update found", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SettingsSectionLabel("Appearance")
        SettingsCard {
            // Theme chips - Column layout avoids LazyRow height bug
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium)
                        .background(Color(0xFF9C27B0).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Palette, null, tint = Color(0xFF9C27B0), modifier = Modifier.size(22.dp))
                    }
                    Text("Theme Mode", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(10.dp))
                val opts = listOf("System","Light","Dark","Black","White")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    opts.forEachIndexed { i, label ->
                        FilterChip(
                            selected = darkTheme == i,
                            onClick = { scope.launch { AppPreferences.set(AppPreferences.DARK_THEME, i) } },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            HDivider()
            // Dynamic Color
            SettingsToggleRow(Icons.Default.AutoAwesome, Color(0xFF2196F3), "Dynamic Color",
                "Wallpaper-based Material You colors", dynamicColor) {
                scope.launch { AppPreferences.set(AppPreferences.DYNAMIC_COLOR, it) }
            }
            // Custom colors when dynamic is OFF
            if (!dynamicColor) {
                HDivider()
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(20.dp).clip(CircleShape).background(Color(0xFFE91E63)))
                        Text("Custom Primary Color", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(10.dp))
                    val presets = listOf("#006397","#E91E63","#9C27B0","#FF5722","#4CAF50","#FF9800","#00BCD4","#3F51B5","#F44336","#009688")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.take(5).forEach { hex ->
                            val col = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.Gray }
                            Box(Modifier.size(36.dp).clip(CircleShape).background(col)
                                .then(if (customPrimary == hex) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                .clickable { scope.launch { AppPreferences.set(AppPreferences.CUSTOM_PRIMARY_COLOR, hex) } })
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.drop(5).forEach { hex ->
                            val col = try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color.Gray }
                            Box(Modifier.size(36.dp).clip(CircleShape).background(col)
                                .then(if (customPrimary == hex) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                .clickable { scope.launch { AppPreferences.set(AppPreferences.CUSTOM_PRIMARY_COLOR, hex) } })
                        }
                    }
                    if (customPrimary.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        TextButton(onClick = { scope.launch { AppPreferences.set(AppPreferences.CUSTOM_PRIMARY_COLOR, "") } }) {
                            Text("Reset to default")
                        }
                    }
                }
            }
            HDivider()
            // Emoji icons toggle
            SettingsToggleRow(Icons.Default.EmojiEmotions, Color(0xFFFF9800), "Emoji Feature Icons",
                "Use emoji icons in home screen feature list", useEmojiIcons) {
                scope.launch { AppPreferences.set(AppPreferences.USE_EMOJI_ICONS, it) }
            }
        }

        // ── BACKGROUND ───────────────────────────────────────────────────────
        SettingsSectionLabel("Background")
        SettingsCard {
            // Device wallpaper option
            SettingsToggleRow(Icons.Default.Wallpaper, Color(0xFF673AB7), "Use Device Wallpaper",
                "Use your current home screen wallpaper as app background", useDeviceWp) {
                scope.launch {
                    AppPreferences.set(AppPreferences.USE_DEVICE_WALLPAPER, it)
                    if (it) AppPreferences.set(AppPreferences.BG_WALLPAPER_URI, "")
                }
            }
            HDivider()
            // Custom image
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(Color(0xFF9C27B0).copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Image, null, tint = Color(0xFF9C27B0), modifier = Modifier.size(22.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("Custom Background Image", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text(if (bgUri.isEmpty()) "No image selected" else android.net.Uri.parse(bgUri).lastPathSegment?.take(30) ?: "Image set",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (bgUri.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (bgUri.isNotEmpty()) {
                        OutlinedButton(onClick = { scope.launch { AppPreferences.set(AppPreferences.BG_WALLPAPER_URI, "") } },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) { Text("Clear") }
                    }
                    FilledTonalButton(onClick = { bgPicker.launch(arrayOf("image/jpeg","image/png","image/webp")) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) { Text("Pick") }
                }
            }
            if (bgUri.isNotEmpty()) {
                HDivider()
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Dim slider
                    Text("Dim: ${(bgDimVal * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = bgDimVal, onValueChange = { bgDimVal = it
                        scope.launch { AppPreferences.set(AppPreferences.BG_DIM_AMOUNT, it) }
                    }, valueRange = 0f..0.9f, modifier = Modifier.fillMaxWidth())
                    // Blur toggle + slider
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Blur Background", style = MaterialTheme.typography.bodyMedium)
                        }
                        Switch(checked = bgBlur, onCheckedChange = { scope.launch { AppPreferences.set(AppPreferences.BG_BLUR_ENABLED, it) } })
                    }
                    if (bgBlur) {
                        Text("Blur Amount: ${bgBlurVal.toInt()}dp", style = MaterialTheme.typography.bodySmall)
                        Slider(value = bgBlurVal, onValueChange = { bgBlurVal = it
                            scope.launch { AppPreferences.set(AppPreferences.BG_BLUR_AMOUNT, it) }
                        }, valueRange = 4f..40f, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }

        // ── UI BLUR ───────────────────────────────────────────────────────────
        SettingsSectionLabel("UI Style")
        SettingsCard {
            SettingsToggleRow(Icons.Default.BlurOn, Color(0xFF00BCD4), "Blur UI Containers",
                "Frosted glass effect on cards and surfaces", uiBlur) {
                scope.launch { AppPreferences.set(AppPreferences.UI_BLUR_ENABLED, it) }
            }
            if (uiBlur) {
                HDivider()
                Column(Modifier.padding(16.dp)) {
                    Text("Blur Strength: ${uiBlurVal.toInt()}dp", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Slider(value = uiBlurVal, onValueChange = { uiBlurVal = it
                        scope.launch { AppPreferences.set(AppPreferences.UI_BLUR_AMOUNT, it) }
                    }, valueRange = 4f..32f, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        // ── PERMISSIONS ───────────────────────────────────────────────────────
        SettingsSectionLabel("Permissions")
        SettingsCard {
            val perms = listOf(
                Triple("Camera", grantedCamera, Icons.Default.CameraAlt),
                Triple("Microphone", grantedAudio, Icons.Default.Mic),
                Triple("Notifications", grantedNotifications, Icons.Default.Notifications),
                Triple("Media", grantedMedia, Icons.Default.Photo),
                Triple("Accessibility", grantedAccessibility, Icons.Default.Accessibility),
                Triple("Overlay", grantedOverlay, Icons.Default.Layers),
                Triple("Notif Listener", grantedNotifListener, Icons.Default.NotificationsActive),
                Triple("Usage Stats", grantedUsageStats, Icons.Default.BarChart),
            )
            perms.forEachIndexed { idx, (name, granted, icon) ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(icon, null, tint = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(20.dp))
                    Text(name, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    if (granted) {
                        Text("✓ OK", color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    } else {
                        FilledTonalButton(onClick = {
                            when (name) {
                                "Camera" -> permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                                "Microphone" -> permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                                "Notifications" -> if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                                "Media" -> permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                                "Accessibility" -> PermissionManager.openAccessibilitySettings(context)
                                "Overlay" -> PermissionManager.openOverlaySettings(context)
                                "Notif Listener" -> PermissionManager.openNotificationListenerSettings(context)
                                "Usage Stats" -> PermissionManager.openUsageAccessSettings(context)
                            }
                        }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text("Grant") }
                    }
                }
                if (idx < perms.lastIndex) HDivider()
            }
        }

        // ── ABOUT ─────────────────────────────────────────────────────────────
        SettingsSectionLabel("About")
        SettingsCard {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center) { Text("✨", fontSize = 24.sp) }
                Column(Modifier.weight(1f)) {
                    Text("Everlasting Tweak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Version 2.0.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Made By Hari ❤️", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/hariprabhu1008")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        })
                }
            }
            HDivider()
            AboutRow(Icons.Default.Code, Color(0xFF6E40C9), "Source Code | Contributions",
                "github.com/hari161008") {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/hari161008/Everlasting-Android-Tweak")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            HDivider()
            AboutRow(Icons.Default.Send, Color(0xFF2CA5E0), "Updates | Discover | Community",
                "t.me/CoolAppStore") {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/CoolAppStore")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            HDivider()
            // ADB command
            var adbCopied by remember { mutableStateOf(false) }
            val adbCmd = "adb shell pm grant com.coolappstore.everlastingandroidtweak android.permission.WRITE_SECURE_SETTINGS"
            Row(Modifier.fillMaxWidth().clickable {
                val cb = context.getSystemService(android.content.ClipboardManager::class.java)
                cb?.setPrimaryClip(android.content.ClipData.newPlainText("ADB", adbCmd))
                adbCopied = true
            }.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(Color(0xFF4CAF50).copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center) { Icon(Icons.Default.Terminal, null, tint = Color(0xFF4CAF50), modifier = Modifier.size(22.dp)) }
                Column(Modifier.weight(1f)) {
                    Text("ADB: Write Secure Settings", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text("Tap to copy command", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(if (adbCopied) Icons.Default.CheckCircle else Icons.Default.ContentCopy, null,
                    tint = if (adbCopied) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
            }
        }

        // ── AUTO UPDATE ───────────────────────────────────────────────────────
        SettingsSectionLabel("Auto Update")
        SettingsCard {
            SettingsToggleRow(Icons.Default.Update, Color(0xFF4CAF50), "Background Update Check",
                "Periodically check GitHub for new releases", autoUpdate) {
                scope.launch { AppPreferences.set(AppPreferences.AUTO_UPDATE_ENABLED, it) }
            }
            if (autoUpdate) {
                HDivider()
                Column(Modifier.padding(16.dp)) {
                    Text("Check Interval", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(6 to "6h", 12 to "12h", 24 to "Daily", 72 to "3d", 168 to "Weekly").forEach { (hrs, lbl) ->
                            FilterChip(selected = updateInterval == hrs,
                                onClick = { scope.launch { AppPreferences.set(AppPreferences.AUTO_UPDATE_INTERVAL_HOURS, hrs) } },
                                label = { Text(lbl, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // ── ADVANCED ─────────────────────────────────────────────────────────
        SettingsSectionLabel("Advanced")
        SettingsCard {
            // Backup
            Row(Modifier.fillMaxWidth().clickable { backupLauncher.launch("everlasting_backup_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}.json") }
                .padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(Color(0xFF2196F3).copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center) { Icon(Icons.Default.Backup, null, tint = Color(0xFF2196F3), modifier = Modifier.size(22.dp)) }
                Column(Modifier.weight(1f)) {
                    Text("Backup Settings", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text("Export all app data to a JSON file", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HDivider()
            // Reset
            var showResetDialog by remember { mutableStateOf(false) }
            if (showResetDialog) {
                AlertDialog(onDismissRequest = { showResetDialog = false },
                    icon = { Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error) },
                    title = { Text("Reset All Settings?") },
                    text = { Text("This clears ALL preferences and returns to defaults.") },
                    confirmButton = {
                        Button(onClick = {
                            scope.launch {
                                listOf(AppPreferences.SHAKE_TORCH_ENABLED, AppPreferences.TWIST_CAMERA_ENABLED,
                                    AppPreferences.CUSTOM_HAPTICS_ENABLED, AppPreferences.TAP_SOUND_ENABLED,
                                    AppPreferences.LOCK_SOUND_ENABLED, AppPreferences.UNLOCK_SOUND_ENABLED,
                                    AppPreferences.MUSIC_LIGHT_ENABLED, AppPreferences.MUSIC_LEVELER_ENABLED,
                                    AppPreferences.NAVBAR_OVERLAY_ENABLED, AppPreferences.FLIP_DND_ENABLED,
                                    AppPreferences.VOLUME_BOOST_ENABLED, AppPreferences.SECURITY_MOTION_ENABLED,
                                    AppPreferences.CHARGE_LIMIT_ENABLED, AppPreferences.FLASH_NOTIF_ENABLED,
                                    AppPreferences.EDGE_LIGHT_ENABLED, AppPreferences.AUTO_UPDATE_ENABLED,
                                    AppPreferences.UI_BLUR_ENABLED, AppPreferences.BG_BLUR_ENABLED
                                ).forEach { AppPreferences.set(it, false) }
                                AppPreferences.set(AppPreferences.DARK_THEME, 0)
                                AppPreferences.set(AppPreferences.CUSTOM_PRIMARY_COLOR, "")
                                AppPreferences.set(AppPreferences.BG_WALLPAPER_URI, "")
                            }
                            showResetDialog = false
                        }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                            Text("Reset Everything")
                        }
                    },
                    dismissButton = { TextButton(onClick = { showResetDialog = false }) { Text("Cancel") } }
                )
            }
            Row(Modifier.fillMaxWidth().clickable { showResetDialog = true }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center) { Icon(Icons.Default.RestartAlt, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(22.dp)) }
                Column(Modifier.weight(1f)) {
                    Text("Reset All Settings", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text("Clear all preferences and return to defaults", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(Modifier.height(32.dp))
    }
    } // end Scaffold
}

// ── HELPERS ──────────────────────────────────────────────────────────────────
@Composable private fun SettingsSectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp))
}

@Composable private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(0.dp)) {
        Column(content = content)
    }
}

@Composable private fun HDivider() = HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

@Composable private fun SettingsRow(icon: ImageVector, tint: Color, title: String, subtitle: String?, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(tint.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable private fun SettingsToggleRow(icon: ImageVector, tint: Color, title: String, subtitle: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(tint.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

@Composable private fun AboutRow(icon: ImageVector, tint: Color, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(40.dp).clip(MaterialTheme.shapes.medium).background(tint.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.OpenInNew, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}
