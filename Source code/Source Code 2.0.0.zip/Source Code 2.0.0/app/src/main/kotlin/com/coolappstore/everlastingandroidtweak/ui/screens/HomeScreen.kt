package com.coolappstore.everlastingandroidtweak.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.ui.navigation.Screen

data class FeatureItem(val title: String, val subtitle: String, val icon: ImageVector, val route: String, val category: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    val allFeatures = listOf(
        FeatureItem("Shake for Torch",        "Shake phone to toggle flashlight",              Icons.Default.FlashOn,              Screen.ShakeTorch.route,       "Gestures"),
        FeatureItem("Twist for Camera",        "Twist wrist to open camera",                   Icons.Default.CameraAlt,            Screen.TwistCamera.route,      "Gestures"),
        FeatureItem("Double Tap Back",         "Double-tap back for torch or app",             Icons.Default.TouchApp,             Screen.DoubleTapBack.route,    "Gestures"),
        FeatureItem("Flip to DND",             "Flip face-down to enable Do Not Disturb",      Icons.Default.DoNotDisturb,         Screen.FlipToDnd.route,        "Gestures"),
        FeatureItem("Custom Nav Bar",          "Overlay a custom navigation bar",              Icons.Default.Navigation,           Screen.NavBarOverlay.route,    "Gestures"),
        FeatureItem("Built-in Equalizer",      "Tune audio with 5-band EQ",                    Icons.Default.Equalizer,            Screen.Equalizer.route,        "Audio & Haptics"),
        FeatureItem("Volume Booster",          "Amplify audio beyond system limits",           Icons.Default.VolumeUp,             Screen.VolumeBooster.route,    "Audio & Haptics"),
        FeatureItem("Custom Haptics",          "Customize tap & scroll vibration",             Icons.Default.Vibration,            Screen.Haptics.route,          "Audio & Haptics"),
        FeatureItem("Custom Sounds",           "Lock, unlock, tap & charging sounds",          Icons.Default.VolumeUp,             Screen.CustomSounds.route,     "Audio & Haptics"),
        FeatureItem("Call/Alarm Vibrations",   "Custom vibration patterns",                    Icons.Default.Vibration,            Screen.VibrationPatterns.route,"Audio & Haptics"),
        FeatureItem("Volume Styles",           "Custom volume panel styles",                   Icons.Default.Tune,                 Screen.VolumeStyles.route,     "Audio & Haptics"),
        FeatureItem("Music Reactive Light",    "Flash & vibrate to music beats",               Icons.Default.MusicNote,            Screen.MusicLight.route,       "Music & Light"),
        FeatureItem("Music Leveler",           "Animated equalizer bar across screen",         Icons.Default.BarChart,             Screen.MusicLeveler.route,     "Music & Light"),
        FeatureItem("Charge Limit Alarm",      "Alert when battery hits your set limit",       Icons.Default.BatteryAlert,         Screen.ChargeLimit.route,      "Productivity"),
        FeatureItem("App Freezer",             "Freeze apps via Shizuku",                      Icons.Default.AcUnit,               Screen.AppFreezer.route,       "Productivity"),
        FeatureItem("App Updater",             "Check GitHub for sideloaded app updates",      Icons.Default.SystemUpdateAlt,      Screen.AppUpdater.route,       "Productivity"),
        FeatureItem("Walkie Talkie",           "Push-to-talk over Wi-Fi Direct",               Icons.Default.SettingsVoice,        Screen.WalkieTalkie.route,     "Communication"),
        FeatureItem("Fake Call",               "Simulate an incoming call",                    Icons.Default.Call,                 Screen.FakeCall.route,         "Communication"),
        FeatureItem("Security Motion Alert",   "Alert when device is moved",                   Icons.Default.Security,             Screen.SecurityMotion.route,   "Security"),
        FeatureItem("Screenshot Blocker",      "Block screenshots & screen recording",         Icons.Default.Screenshot,           Screen.ScreenshotBlocker.route,"Security"),
        FeatureItem("Keep Screen On",          "Prevent screen sleep + QS tile",               Icons.Default.Lightbulb,            Screen.KeepScreenOn.route,     "Device & System"),
        FeatureItem("Task Manager",            "View & kill running processes",                Icons.Default.Memory,               Screen.TaskManager.route,      "Device & System"),
        FeatureItem("Terminal",                "Run shell commands on device",                 Icons.Default.Terminal,             Screen.Terminal.route,         "Device & System"),
        FeatureItem("Cache Cleaner",           "Clear app caches via Shizuku",                 Icons.Default.CleaningServices,     Screen.CacheCleaner.route,     "Device & System"),
        FeatureItem("Auto Reboot",             "Schedule automatic reboots",                   Icons.Default.RestartAlt,           Screen.AutoReboot.route,       "Device & System"),
        FeatureItem("Hidden Features",         "Unlock hidden Android settings",               Icons.Default.Lock,                 Screen.HiddenFeatures.route,   "Device & System"),
        FeatureItem("Eye Dropper",             "Pick any color from your screen",              Icons.Default.Colorize,             Screen.EyeDropper.route,       "Customization"),
        FeatureItem("Compass",                 "Live compass with animated UI",                Icons.Default.Explore,              Screen.Compass.route,          "Customization"),
        FeatureItem("Lock Screen Widgets",     "Add widgets to your lock screen",              Icons.Default.Widgets,              Screen.LockScreenWidgets.route,"Customization"),
        FeatureItem("Custom QS Tiles",         "Add 15+ custom quick settings tiles",          Icons.Default.GridView,             Screen.CustomQSTiles.route,    "Customization"),
        FeatureItem("Notification Lighting",   "Edge light & flashlight pulse",                Icons.Default.NotificationsActive,  Screen.NotifLight.route,       "Notifications"),
        FeatureItem("Battery Health",          "Battery stats (Android 14+)",                  Icons.Default.BatteryFull,          Screen.BatteryHealth.route,    "Notifications"),
        FeatureItem("Screensaver",             "Beautiful screensaver themes",                 Icons.Default.Slideshow,            Screen.Screensaver.route,      "Visuals"),
        FeatureItem("Wallpaper Effects",       "Pixel-style wallpaper effects",                Icons.Default.Wallpaper,            Screen.WallpaperEffects.route, "Visuals"),
        FeatureItem("Auto Watermark",          "Watermark photos automatically",               Icons.Default.WaterDrop,            Screen.Watermark.route,        "Visuals"),
    )

    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    val filteredFeatures = remember(searchQuery) {
        if (searchQuery.isBlank()) allFeatures
        else allFeatures.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.subtitle.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    val categories = allFeatures.map { it.category }.distinct()

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        if (isSearching) {
                            val focusRequester = remember { androidx.compose.ui.focus.FocusRequester() }
                            LaunchedEffect(isSearching) {
                                if (isSearching) {
                                    delay(100)
                                    try { focusRequester.requestFocus() } catch (_: Exception) {}
                                }
                            }
                            TextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search features…") },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth().then(
                                    if (isSearching) Modifier.focusRequester(focusRequester) else Modifier
                                ),
                                leadingIcon = { Icon(Icons.Default.Search, null) }
                            )
                        } else {
                            Column {
                                Text("Everlasting Tweak", fontWeight = FontWeight.Bold)
                                Text("Android Enhancement Suite",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            isSearching = !isSearching
                            if (!isSearching) searchQuery = ""
                        }) {
                            Icon(if (isSearching) Icons.Default.Close else Icons.Default.Search,
                                if (isSearching) "Close Search" else "Search")
                        }
                        if (!isSearching) {
                            IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                                Icon(Icons.Default.Settings, "Settings")
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 24.dp
            )
        ) {
            if (searchQuery.isNotBlank()) {
                // Flat search results
                if (filteredFeatures.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("🔍", style = MaterialTheme.typography.displaySmall)
                                Text("No results for \"$searchQuery\"",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    item {
                        Text("${filteredFeatures.size} result${if (filteredFeatures.size != 1) "s" else ""}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                        Card(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            shape = MaterialTheme.shapes.extraLarge,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            filteredFeatures.forEachIndexed { idx, feature ->
                                FeatureListItem(feature, navController)
                                if (idx < filteredFeatures.lastIndex)
                                    HorizontalDivider(Modifier.padding(horizontal = 56.dp),
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            }
                        }
                    }
                }
            } else {
                // Grouped categories
                categories.forEach { category ->
                    item(key = category) {
                        Text(category,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp))
                        Card(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            shape = MaterialTheme.shapes.extraLarge,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            elevation = CardDefaults.cardElevation(0.dp)
                        ) {
                            val group = allFeatures.filter { it.category == category }
                            group.forEachIndexed { idx, feature ->
                                FeatureListItem(feature, navController)
                                if (idx < group.lastIndex)
                                    HorizontalDivider(Modifier.padding(horizontal = 56.dp),
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureListItem(feature: FeatureItem, navController: NavController) {
    ListItem(
        headlineContent = { Text(feature.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium) },
        supportingContent = { Text(feature.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        leadingContent = { Icon(feature.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp)) },
        trailingContent = { Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
        modifier = Modifier.clickable { navController.navigate(feature.route) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}
