package com.coolappstore.everlastingandroidtweak.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val LocalBlurEnabled     = compositionLocalOf { false }
val LocalBlurAmount      = compositionLocalOf { 0f }
val LocalWallpaperActive = compositionLocalOf { false }

private val DarkCS = darkColorScheme(
    primary = Color(0xFF8BCAFF), onPrimary = Color(0xFF003352),
    primaryContainer = Color(0xFF004A74), onPrimaryContainer = Color(0xFFCDE5FF),
    secondary = Color(0xFFB3C9E0), onSecondary = Color(0xFF1D3447),
    secondaryContainer = Color(0xFF344B5E), onSecondaryContainer = Color(0xFFCFE5FC),
    background = Color(0xFF0F1417), onBackground = Color(0xFFDDE3EA),
    surface = Color(0xFF0F1417), onSurface = Color(0xFFDDE3EA),
    surfaceVariant = Color(0xFF40484F), onSurfaceVariant = Color(0xFFC0C7D0),
    outline = Color(0xFF8A9199),
)
private val LightCS = lightColorScheme(
    primary = Color(0xFF006397), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFCDE5FF), onPrimaryContainer = Color(0xFF001D31),
    secondary = Color(0xFF4D6678), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCFE5FC), onSecondaryContainer = Color(0xFF081E2D),
    background = Color(0xFFF7F9FC), onBackground = Color(0xFF181C1F),
    surface = Color(0xFFF7F9FC), onSurface = Color(0xFF181C1F),
    surfaceVariant = Color(0xFFDDE3EA), onSurfaceVariant = Color(0xFF40484F),
    outline = Color(0xFF71787F),
)

@Composable
fun EverlastingTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    themeMode: Int = 0,
    blurEnabled: Boolean = false,
    blurAmount: Float = 16f,
    wallpaperActive: Boolean = false,
    customPrimaryColor: String = "",
    content: @Composable () -> Unit
) {
    val isPureBlack = themeMode == 3
    val isPureWhite = themeMode == 4
    val isDark = isPureBlack || (themeMode == 0 && darkTheme) || themeMode == 2

    var base: ColorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (isDark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        isDark -> DarkCS
        else   -> LightCS
    }

    // Pure black / white overrides
    base = when {
        isPureBlack -> base.copy(background = Color(0xFF000000), surface = Color(0xFF000000), surfaceVariant = Color(0xFF111111))
        isPureWhite -> base.copy(background = Color(0xFFFFFFFF), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFF2F2F2))
        else -> base
    }

    // Custom primary color (only when dynamic color is OFF)
    if (!dynamicColor && customPrimaryColor.isNotBlank()) {
        val col = try { Color(android.graphics.Color.parseColor(customPrimaryColor)) } catch (_: Exception) { null }
        if (col != null) {
            base = base.copy(
                primary = col,
                primaryContainer = col.copy(alpha = 0.25f),
                onPrimary = if (isDark) Color.Black else Color.White
            )
        }
    }

    // Blur UI — make surfaces semi-transparent when blur is on
    val finalScheme = when {
        blurEnabled && wallpaperActive -> base.copy(
            background    = Color.Transparent,
            surface       = if (isDark) Color(0xBB0F1417) else Color(0xBBF7F9FC),
            surfaceVariant = if (isDark) Color(0xAA40484F) else Color(0xAADDE3EA),
        )
        blurEnabled -> base.copy(
            surfaceVariant = if (isDark) Color(0xCC40484F) else Color(0xCCDDE3EA),
            surface = if (isDark) Color(0xCC0F1417) else Color(0xCCF7F9FC),
        )
        wallpaperActive -> base.copy(
            background    = Color.Transparent,
            surface       = if (isDark) Color(0xCC0F1417) else Color(0xCCF7F9FC),
            surfaceVariant = if (isDark) Color(0xBB40484F) else Color(0xBBDDE3EA),
        )
        else -> base
    }

    val isLightBar = isPureWhite || (!isPureBlack && !darkTheme && themeMode != 2)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val win = (view.context as Activity).window
            win.statusBarColor = Color.Transparent.toArgb()
            win.navigationBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(win, view).isAppearanceLightStatusBars = isLightBar
        }
    }

    CompositionLocalProvider(
        LocalBlurEnabled provides blurEnabled,
        LocalBlurAmount  provides blurAmount,
        LocalWallpaperActive provides wallpaperActive
    ) {
        MaterialTheme(colorScheme = finalScheme, typography = Typography, content = content)
    }
}
