package com.coolappstore.everlastingandroidtweak.features.fakecall

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.coolappstore.everlastingandroidtweak.EverlastingApp

/**
 * Draws a full-screen fake incoming call UI using WindowManager overlay.
 * No TelecomManager needed — just Display Over Other Apps permission.
 */
class FakeCallOverlayService : Service() {

    private var wm: WindowManager? = null
    private var overlayView: View? = null
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val ACTION_STOP    = "action_stop_fake_call"
        const val EXTRA_NAME     = "caller_name"
        const val EXTRA_NUMBER   = "caller_number"
        const val EXTRA_AVATAR   = "caller_avatar"
        const val EXTRA_RINGTONE = "ringtone_type"
        const val NOTIF_ID       = 9001

        fun start(ctx: Context, name: String, number: String, avatar: String, ringtone: String) {
            if (!Settings.canDrawOverlays(ctx)) return
            ctx.startService(Intent(ctx, FakeCallOverlayService::class.java).apply {
                putExtra(EXTRA_NAME, name)
                putExtra(EXTRA_NUMBER, number)
                putExtra(EXTRA_AVATAR, avatar)
                putExtra(EXTRA_RINGTONE, ringtone)
            })
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FakeCallOverlayService::class.java).apply {
                action = ACTION_STOP
            })
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            cleanup(); stopSelf(); return START_NOT_STICKY
        }
        val name    = intent?.getStringExtra(EXTRA_NAME) ?: "Unknown"
        val number  = intent?.getStringExtra(EXTRA_NUMBER) ?: ""
        val avatar  = intent?.getStringExtra(EXTRA_AVATAR) ?: "📞"
        val ringtone = intent?.getStringExtra(EXTRA_RINGTONE) ?: "Default"

        startForeground(NOTIF_ID, buildNotif(name, number))
        showCallScreen(name, number, avatar, ringtone)
        return START_NOT_STICKY
    }

    private fun buildNotif(name: String, number: String): Notification =
        NotificationCompat.Builder(this, EverlastingApp.CHANNEL_ALERTS)
            .setContentTitle("Incoming call from $name")
            .setContentText(number)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .build()

    private fun showCallScreen(name: String, number: String, avatar: String, ringtone: String) {
        removeView()
        startRinging(ringtone)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val view = buildCallView(name, number, avatar)
        overlayView = view

        try { wm?.addView(view, params) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun buildCallView(name: String, number: String, avatar: String): View {
        val ctx = this
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#1A1A2E"))
            setPadding(dp(24), dp(60), dp(24), dp(48))
        }

        // Incoming call label
        val labelView = TextView(ctx).apply {
            text = "Incoming Call"
            textSize = 14f
            setTextColor(Color.argb(180, 255, 255, 255))
            gravity = Gravity.CENTER
        }
        root.addView(labelView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(32)
        ))

        root.addView(View(ctx), LinearLayout.LayoutParams(0, dp(24)))

        // Avatar circle
        val avatarBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#2D2D5E"))
        }
        val avatarView = TextView(ctx).apply {
            text = avatar
            textSize = 48f
            gravity = Gravity.CENTER
            background = avatarBg
        }
        val avatarParams = LinearLayout.LayoutParams(dp(120), dp(120)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(avatarView, avatarParams)
        root.addView(View(ctx), LinearLayout.LayoutParams(0, dp(20)))

        // Name
        val nameView = TextView(ctx).apply {
            text = name
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(nameView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // Number
        val numView = TextView(ctx).apply {
            text = number
            textSize = 16f
            setTextColor(Color.argb(180, 255, 255, 255))
            gravity = Gravity.CENTER
        }
        root.addView(numView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        // Push action buttons to bottom
        val spacer = LinearLayout(ctx)
        root.addView(spacer, LinearLayout.LayoutParams(0, 0, 1f))

        // Action buttons row
        val btnRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 2f
        }

        // Decline button
        val declineBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(Color.RED)
        }
        val declineBtn = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = declineBg
            val pad = dp(20); setPadding(pad, pad, pad, pad)
            setOnClickListener { cleanup(); stopSelf() }
        }
        val declineIcon = TextView(ctx).apply { text = "✕"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        declineBtn.addView(declineIcon)
        val declineLabel = TextView(ctx).apply { text = "Decline"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }

        val declineCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        }
        declineCol.addView(declineBtn, LinearLayout.LayoutParams(dp(72), dp(72)))
        declineCol.addView(View(ctx), LinearLayout.LayoutParams(0, dp(8)))
        declineCol.addView(declineLabel)
        btnRow.addView(declineCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        // Accept button
        val acceptBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(Color.parseColor("#4CAF50"))
        }
        val acceptBtn = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = acceptBg
            val pad = dp(20); setPadding(pad, pad, pad, pad)
            setOnClickListener {
                stopRinging()
                showActiveCallScreen(name, number)
            }
        }
        val acceptIcon = TextView(ctx).apply { text = "📞"; textSize = 28f; gravity = Gravity.CENTER }
        acceptBtn.addView(acceptIcon)
        val acceptLabel = TextView(ctx).apply { text = "Accept"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }

        val acceptCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        }
        acceptCol.addView(acceptBtn, LinearLayout.LayoutParams(dp(72), dp(72)))
        acceptCol.addView(View(ctx), LinearLayout.LayoutParams(0, dp(8)))
        acceptCol.addView(acceptLabel)
        btnRow.addView(acceptCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        root.addView(btnRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        return root
    }

    private fun showActiveCallScreen(name: String, number: String) {
        removeView()
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        var seconds = 0

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#1A1A2E"))
            setPadding(dp(24), dp(80), dp(24), dp(48))
        }

        val nameView = TextView(this).apply {
            text = name; textSize = 28f; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
        }
        root.addView(nameView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val timerView = TextView(this).apply {
            text = "00:00"; textSize = 18f; setTextColor(Color.parseColor("#4CAF50")); gravity = Gravity.CENTER
        }
        root.addView(timerView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        val spacer = LinearLayout(this)
        root.addView(spacer, LinearLayout.LayoutParams(0, 0, 1f))

        val endBg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.RED) }
        val endBtn = LinearLayout(this).apply {
            gravity = Gravity.CENTER; background = endBg
            val pad = dp(20); setPadding(pad, pad, pad, pad)
            setOnClickListener { cleanup(); stopSelf() }
        }
        endBtn.addView(TextView(this).apply { text = "✕"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        root.addView(endBtn, LinearLayout.LayoutParams(dp(72), dp(72)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        overlayView = root
        try { wm?.addView(root, params) } catch (e: Exception) { e.printStackTrace() }

        // Timer
        val timerRunnable = object : Runnable {
            override fun run() {
                seconds++
                timerView.text = "%02d:%02d".format(seconds / 60, seconds % 60)
                handler.postDelayed(this, 1000L)
            }
        }
        handler.postDelayed(timerRunnable, 1000L)
    }

    private fun startRinging(ringtoneType: String) {
        try {
            if (ringtoneType == "Vibrate Only") {
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 1000, 1000), 0))
                return
            }
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE) ?: return
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val vol = am.getStreamVolume(AudioManager.STREAM_RING).toFloat() /
                      am.getStreamMaxVolume(AudioManager.STREAM_RING)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@FakeCallOverlayService, uri)
                isLooping = true
                setVolume(vol, vol)
                prepare(); start()
            }
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 1000, 1000), 0))
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun stopRinging() {
        try { mediaPlayer?.stop(); mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
        vibrator?.cancel()
    }

    private fun removeView() {
        overlayView?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlayView = null
    }

    private fun cleanup() {
        stopRinging()
        handler.removeCallbacksAndMessages(null)
        removeView()
    }

    override fun onDestroy() { super.onDestroy(); cleanup() }
    override fun onBind(intent: Intent?): IBinder? = null
}
