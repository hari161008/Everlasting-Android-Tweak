package com.coolappstore.everlastingandroidtweak.features.walkietalkie

import android.content.Context
import android.media.*
import android.net.wifi.p2p.WifiP2pManager
import kotlinx.coroutines.*
import java.net.*

class WalkieTalkieManager(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var recording = false
    private var playing   = false
    private val SAMPLE_RATE = 16000
    private val PORT = 50005
    private var serverSocket: DatagramSocket? = null
    private var targetAddress: InetAddress? = null

    var isTalking = false
    var statusCallback: ((String) -> Unit)? = null

    private val wifiP2pManager by lazy { context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager }
    private var wifiChannel: WifiP2pManager.Channel? = null

    fun initWifiDirect() {
        wifiChannel = wifiP2pManager.initialize(context, android.os.Looper.getMainLooper(), null)
    }

    fun discoverPeers(onResult: (List<String>) -> Unit) {
        val channel = wifiChannel ?: return
        wifiP2pManager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                wifiP2pManager.requestPeers(channel) { peerList ->
                    onResult(peerList.deviceList.map { it.deviceName })
                }
            }
            override fun onFailure(reason: Int) { onResult(emptyList()) }
        })
    }

    fun setTarget(address: String) {
        targetAddress = InetAddress.getByName(address)
    }

    fun startTalking() {
        if (isTalking) return
        isTalking = true
        statusCallback?.invoke("Transmitting…")
        scope.launch {
            val bufSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val recorder = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)
            val socket = DatagramSocket()
            recorder.startRecording()
            val buf = ByteArray(bufSize)
            try {
                while (isTalking) {
                    val read = recorder.read(buf, 0, bufSize)
                    if (read > 0) {
                        val dest = targetAddress ?: InetAddress.getByName("255.255.255.255")
                        socket.send(DatagramPacket(buf, read, dest, PORT))
                    }
                }
            } finally { recorder.stop(); recorder.release(); socket.close() }
        }
    }

    fun stopTalking() {
        isTalking = false
        statusCallback?.invoke("Idle")
    }

    fun startListening() {
        if (playing) return
        playing = true
        scope.launch {
            val bufSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(bufSize).setTransferMode(AudioTrack.MODE_STREAM).build()
            serverSocket = DatagramSocket(PORT)
            val buf = ByteArray(bufSize)
            val packet = DatagramPacket(buf, buf.size)
            track.play()
            try {
                while (playing) {
                    serverSocket?.receive(packet)
                    track.write(packet.data, 0, packet.length)
                }
            } finally { track.stop(); track.release(); serverSocket?.close() }
        }
    }

    fun stopListening() {
        playing = false
        try { serverSocket?.close() } catch (_: Exception) {}
    }

    fun release() { stopTalking(); stopListening(); scope.cancel() }
}
