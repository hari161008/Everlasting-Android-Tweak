package com.coolappstore.everlastingandroidtweak

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.services.EverlastingForegroundService
import com.coolappstore.everlastingandroidtweak.ui.navigation.EverlastingNavHost
import com.coolappstore.everlastingandroidtweak.ui.theme.EverlastingTheme
import kotlinx.coroutines.delay

@Composable
private fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0f) }
    val alpha = remember { Animatable(1f) }
    val bg    = MaterialTheme.colorScheme.background
    val fg    = MaterialTheme.colorScheme.primary

    LaunchedEffect(Unit) {
        // Slowed down animation
        scale.animateTo(1f, animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness    = Spring.StiffnessVeryLow
        ))
        delay(1400)
        alpha.animateTo(0f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(Modifier.fillMaxSize().alpha(alpha.value).background(bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(":)", fontSize = 80.sp, color = fg, fontWeight = FontWeight.Black,
                modifier = Modifier.scale(scale.value))
            Spacer(Modifier.height(8.dp))
            Text("Everlasting Tweak", fontSize = 22.sp, color = fg,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(scale.value))
            Spacer(Modifier.height(4.dp))
            Text("Think Different !", fontSize = 13.sp,
                color = fg.copy(alpha = 0.6f), textAlign = TextAlign.Center,
                modifier = Modifier.alpha(scale.value))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        EverlastingForegroundService.start(this)

        setContent {
            val dynamicColor      by AppPreferences.get(AppPreferences.DYNAMIC_COLOR, true).collectAsState(true)
            val themeMode         by AppPreferences.get(AppPreferences.DARK_THEME, 0).collectAsState(0)
            val blurEnabled       by AppPreferences.get(AppPreferences.UI_BLUR_ENABLED, false).collectAsState(false)
            val blurAmount        by AppPreferences.get(AppPreferences.UI_BLUR_AMOUNT, 16f).collectAsState(16f)
            val bgUri             by AppPreferences.get(AppPreferences.BG_WALLPAPER_URI, "").collectAsState("")
            val bgDim             by AppPreferences.get(AppPreferences.BG_DIM_AMOUNT, 0f).collectAsState(0f)
            val bgBlur            by AppPreferences.get(AppPreferences.BG_BLUR_ENABLED, false).collectAsState(false)
            val bgBlurAmount      by AppPreferences.get(AppPreferences.BG_BLUR_AMOUNT, 16f).collectAsState(16f)
            val customPrimary     by AppPreferences.get(AppPreferences.CUSTOM_PRIMARY_COLOR, "").collectAsState("")
            val systemDark        = isSystemInDarkTheme()
            val isDark = when (themeMode) { 1->false; 2->true; 3->true; 4->false; else->systemDark }
            val wallpaperActive   = bgUri.isNotEmpty()
            val ctx               = LocalContext.current

            EverlastingTheme(
                darkTheme        = isDark,
                dynamicColor     = dynamicColor,
                themeMode        = themeMode,
                blurEnabled      = blurEnabled,
                blurAmount       = blurAmount,
                wallpaperActive  = wallpaperActive,
                customPrimaryColor = customPrimary
            ) {
                var showSplash by remember { mutableStateOf(true) }

                Box(Modifier.fillMaxSize()) {
                    // ── Wallpaper layer ──────────────────────────────────
                    if (wallpaperActive) {
                        key(bgUri) {
                            AsyncImage(
                                model = ImageRequest.Builder(ctx)
                                    .data(Uri.parse(bgUri))
                                    .crossfade(true)
                                    .allowHardware(false)
                                    .build(),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                                    .then(if (bgBlur) Modifier.blur(bgBlurAmount.dp) else Modifier)
                            )
                        }
                        if (bgDim > 0.01f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgDim)))
                    }

                    // ── App UI ───────────────────────────────────────────
                    AnimatedVisibility(visible = !showSplash, enter = fadeIn(tween(300))) {
                        EverlastingNavHost()
                    }

                    // ── Splash ───────────────────────────────────────────
                    if (showSplash) SplashScreen { showSplash = false }
                }
            }
        }
    }
}
