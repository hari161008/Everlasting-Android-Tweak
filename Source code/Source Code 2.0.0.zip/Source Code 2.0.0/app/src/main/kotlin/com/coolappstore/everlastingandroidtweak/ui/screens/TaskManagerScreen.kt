package com.coolappstore.everlastingandroidtweak.ui.screens

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import com.coolappstore.everlastingandroidtweak.ui.components.EverlastingTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppProcess(val name: String, val packageName: String, val memoryMb: Float)

@Composable
fun TaskManagerScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var processes by remember { mutableStateOf<List<AppProcess>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var totalMb by remember { mutableLongStateOf(0L) }
    var availMb by remember { mutableLongStateOf(0L) }
    val ramHistory = remember { mutableStateListOf<Float>() }
    var intervalSec by remember { mutableIntStateOf(5) }
    var showIntervalPicker by remember { mutableStateOf(false) }
    val intervalOptions = listOf(2 to "2s", 5 to "5s", 10 to "10s", 30 to "30s", 60 to "1 min")

    suspend fun refresh() {
        withContext(Dispatchers.IO) {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pm = context.packageManager
            val memInfo = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            totalMb = memInfo.totalMem / 1024 / 1024
            availMb = memInfo.availMem / 1024 / 1024
            val usedPct = 1f - availMb.toFloat() / totalMb.toFloat()
            withContext(Dispatchers.Main) {
                ramHistory.add(usedPct.coerceIn(0f, 1f))
                if (ramHistory.size > 30) ramHistory.removeAt(0)
            }
            val running = am.runningAppProcesses ?: emptyList()
            val result = running.mapNotNull { proc ->
                val memMb = am.getProcessMemoryInfo(intArrayOf(proc.pid))
                    .firstOrNull()?.totalPss?.div(1024f) ?: 0f
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(proc.processName.split(":")[0], 0)).toString()
                } catch (_: Exception) { proc.processName }
                AppProcess(label, proc.processName, memMb)
            }.sortedByDescending { it.memoryMb }
            withContext(Dispatchers.Main) { processes = result; loading = false }
        }
    }

    // Auto-refresh loop
    LaunchedEffect(intervalSec) {
        while (true) { refresh(); delay(intervalSec * 1000L) }
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceColor = MaterialTheme.colorScheme.surfaceVariant

    Scaffold(topBar = {
        EverlastingTopBar("Task Manager", navController, actions = {
            IconButton(onClick = { showIntervalPicker = true }) { Icon(Icons.Default.Timer, "Refresh interval") }
            IconButton(onClick = { scope.launch { refresh() } }) { Icon(Icons.Default.Refresh, "Refresh") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {

            // RAM graph card
            Card(Modifier.fillMaxWidth().padding(16.dp),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("RAM Usage", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("${totalMb - availMb} / ${totalMb} MB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                    }
                    Spacer(Modifier.height(8.dp))

                    // RAM bar
                    val usedFraction = if (totalMb > 0) (totalMb - availMb).toFloat() / totalMb else 0f
                    LinearProgressIndicator(
                        progress = { usedFraction },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape),
                        color = when {
                            usedFraction > 0.85f -> Color(0xFFF44336)
                            usedFraction > 0.65f -> Color(0xFFFF9800)
                            else -> MaterialTheme.colorScheme.primary
                        },
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    )
                    Spacer(Modifier.height(12.dp))

                    // History graph
                    if (ramHistory.size > 1) {
                        Canvas(Modifier.fillMaxWidth().height(72.dp)) {
                            val w = size.width; val h = size.height
                            val pts = ramHistory.size
                            val stepX = w / (pts - 1).coerceAtLeast(1)

                            // Fill path
                            val fillPath = Path().apply {
                                moveTo(0f, h)
                                ramHistory.forEachIndexed { i, v ->
                                    lineTo(i * stepX, h - v * h)
                                }
                                lineTo((pts - 1) * stepX, h); close()
                            }
                            drawPath(fillPath, primaryColor.copy(alpha = 0.15f))

                            // Line path
                            val linePath = Path().apply {
                                ramHistory.forEachIndexed { i, v ->
                                    if (i == 0) moveTo(0f, h - v * h)
                                    else lineTo(i * stepX, h - v * h)
                                }
                            }
                            drawPath(linePath, primaryColor, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))

                            // Latest dot
                            val lastX = (ramHistory.size - 1) * stepX
                            val lastY = h - ramHistory.last() * h
                            drawCircle(primaryColor, radius = 4.dp.toPx(), center = Offset(lastX, lastY))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${ramHistory.size * intervalSec}s ago", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Now", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text("Auto-refreshing every ${intervalSec}s",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f))
                }
            }

            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn {
                    items(processes) { proc ->
                        val maxMem = processes.firstOrNull()?.memoryMb ?: 1f
                        val fraction = proc.memoryMb / maxMem
                        ListItem(
                            headlineContent = { Text(proc.name, fontWeight = FontWeight.Medium) },
                            supportingContent = {
                                Column {
                                    Text(proc.packageName, style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { fraction },
                                        modifier = Modifier.fillMaxWidth(0.7f).height(4.dp).clip(CircleShape),
                                        color = when {
                                            fraction > 0.7f -> Color(0xFFF44336)
                                            fraction > 0.4f -> Color(0xFFFF9800)
                                            else -> primaryColor
                                        },
                                        trackColor = primaryColor.copy(alpha = 0.12f)
                                    )
                                }
                            },
                            trailingContent = {
                                Text("${String.format("%.1f", proc.memoryMb)} MB",
                                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    // Interval picker dialog
    if (showIntervalPicker) {
        AlertDialog(onDismissRequest = { showIntervalPicker = false },
            title = { Text("Refresh Interval") },
            text = {
                Column {
                    intervalOptions.forEach { (sec, label) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = intervalSec == sec, onClick = {
                                intervalSec = sec
                                scope.launch { AppPreferences.set(AppPreferences.TASK_UPDATE_INTERVAL, sec) }
                            })
                            Text(label, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showIntervalPicker = false }) { Text("Done") } }
        )
    }
}
