package com.coolappstore.everlastingandroidtweak.features.musicleveler

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.media.AudioManager
import android.media.audiofx.Visualizer
import android.os.*
import android.view.*
import com.coolappstore.everlastingandroidtweak.data.AppPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import kotlin.math.sqrt

class MusicLevelerOverlayService : Service() {
    private var wm: WindowManager? = null
    private var levelerView: LevelerView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var visualizer: Visualizer? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())
    private var viewAdded = false
    private var autoHide = true

    companion object {
        const val ACTION_STOP = "action_stop_leveler"
        fun start(ctx: android.content.Context) = ctx.startService(Intent(ctx, MusicLevelerOverlayService::class.java))
        fun stop(ctx: android.content.Context) {
            ctx.startService(Intent(ctx, MusicLevelerOverlayService::class.java).apply { action = ACTION_STOP })
        }
    }

    private val silenceRunnable = Runnable { if (autoHide) hideOverlay() }

    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            cleanup(); stopSelf(); return START_NOT_STICKY
        }
        scope.launch { startLeveler() }
        return START_STICKY
    }

    private suspend fun startLeveler() {
        cleanup()
        val colorHex = AppPreferences.get(AppPreferences.MUSIC_LEVELER_COLOR, "#8BCAFF").first()
        val position = AppPreferences.get(AppPreferences.MUSIC_LEVELER_POSITION, "Bottom").first()
        val height   = AppPreferences.get(AppPreferences.MUSIC_LEVELER_HEIGHT, 56f).first()
        val opacity  = AppPreferences.get(AppPreferences.MUSIC_LEVELER_OPACITY, 1f).first()
        autoHide     = AppPreferences.get(AppPreferences.MUSIC_LEVELER_AUTO_HIDE, true).first()
        val color    = try { Color.parseColor(colorHex) } catch (_: Exception) { Color.parseColor("#8BCAFF") }

        val view = LevelerView(this, color, opacity)
        levelerView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val gravity = if (position == "Top") Gravity.TOP or Gravity.CENTER_HORIZONTAL
                      else Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL

        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (height * resources.displayMetrics.density).toInt().coerceAtLeast(32),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

        if (!autoHide) showOverlay()

        // Try to attach Visualizer - requires RECORD_AUDIO permission
        // Use AudioManager to get current music session if possible
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            // Session 0 = output mix — works without session ID from a specific player
            visualizer = Visualizer(0).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(vis: Visualizer, wf: ByteArray, sr: Int) {
                        val chunk = (wf.size / 32).coerceAtLeast(1)
                        val bars = FloatArray(32) { i ->
                            var sum = 0.0
                            for (j in 0 until chunk) {
                                val v = (wf[(i * chunk + j).coerceIn(0, wf.size-1)].toInt() and 0xFF) - 128
                                sum += v * v
                            }
                            (sqrt(sum / chunk).toFloat() / 72f).coerceIn(0f, 1f)
                        }
                        view.updateBars(bars)
                        val hasSound = bars.any { it > 0.03f }
                        if (autoHide) {
                            handler.removeCallbacks(silenceRunnable)
                            if (hasSound) { if (!viewAdded) showOverlay() }
                            else handler.postDelayed(silenceRunnable, 1500L)
                        }
                    }
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, sr: Int) {}
                }, Visualizer.getMaxCaptureRate() / 2, true, false)
                enabled = true
            }
        } catch (e: Exception) {
            // RECORD_AUDIO not granted or Visualizer unavailable — show static bars
            e.printStackTrace()
            if (!autoHide) showOverlay()
            view.showStaticDemo()
        }
    }

    private fun showOverlay() {
        if (viewAdded || levelerView == null || overlayParams == null) return
        try { wm?.addView(levelerView, overlayParams); viewAdded = true } catch (_: Exception) {}
    }

    private fun hideOverlay() {
        if (!viewAdded || levelerView == null) return
        try { wm?.removeView(levelerView); viewAdded = false } catch (_: Exception) {}
    }

    private fun cleanup() {
        handler.removeCallbacks(silenceRunnable)
        hideOverlay()
        try { visualizer?.enabled = false; visualizer?.release() } catch (_: Exception) {}
        visualizer = null
    }

    override fun onDestroy() { super.onDestroy(); scope.cancel(); cleanup() }
    override fun onBind(intent: Intent?): IBinder? = null
}

class LevelerView(
    ctx: android.content.Context,
    barColor: Int,
    opacity: Float = 1f
) : android.view.View(ctx) {
    private var bars = FloatArray(32) { 0f }
    private val alpha255 = (opacity * 255f).toInt().coerceIn(0, 255)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = barColor; alpha = alpha255; style = Paint.Style.FILL
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = barColor; alpha = (alpha255 * 0.4f).toInt(); style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
    }

    fun updateBars(newBars: FloatArray) {
        for (i in bars.indices) {
            bars[i] = if (newBars[i] > bars[i]) bars[i] * 0.15f + newBars[i] * 0.85f
                      else bars[i] * 0.86f + newBars[i] * 0.14f
        }
        postInvalidateOnAnimation()
    }

    fun showStaticDemo() {
        // Show a demo wave when Visualizer isn't available
        val wave = FloatArray(32) { i -> (0.1f + 0.4f * kotlin.math.sin(i * 0.4f).toFloat()).coerceIn(0.05f, 0.9f) }
        updateBars(wave)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val barW = w / bars.size
        val cornerR = (barW * 0.42f).coerceAtLeast(2f)
        bars.forEachIndexed { i, level ->
            val barH = (level * h * 0.9f).coerceAtLeast(3f)
            val left  = i * barW + barW * 0.1f
            val right = left + barW * 0.8f
            val top   = h - barH
            val rect  = RectF(left, top, right, h)
            canvas.drawRoundRect(rect, cornerR, cornerR, glowPaint)
            canvas.drawRoundRect(rect, cornerR, cornerR, paint)
        }
    }
}
